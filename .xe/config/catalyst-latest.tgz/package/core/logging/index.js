"use strict";
/**
 * Logging module — leveled logging with contextual resolution across all Catalyst features.
 *
 * @example
 * ```typescript
 * import { LogManager, ConsoleLogger, LogLevel } from '../logging';
 *
 * // Configure the framework default at application startup
 * LogManager.setFramework(new ConsoleLogger(LogLevel.debug));
 *
 * // Any code calls current() to get the logger appropriate for its context
 * LogManager.current().info('Processing playbook', 'start', 'Starting');
 *
 * // Higher-level code can substitute the logger for an operation
 * await LogManager.scope(new ConsoleLogger(LogLevel.info), async () => {
 *   // Code here (sync or async) sees the substituted logger via current()
 * });
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLogPrefixWidth = exports.getMaxTextLength = exports.getColorCode = exports.buildLogPrefix = exports.ANSI_COLORS = exports.LOG_OUTPUT_CONFIG = exports.LOG_LEVEL_CONFIG = exports.ConsoleLogger = exports.LogManager = exports.LogLevel = void 0;
var types_1 = require("./types");
Object.defineProperty(exports, "LogLevel", { enumerable: true, get: function () { return types_1.LogLevel; } });
var log_manager_1 = require("./log-manager");
Object.defineProperty(exports, "LogManager", { enumerable: true, get: function () { return log_manager_1.LogManager; } });
var console_logger_1 = require("./console-logger");
Object.defineProperty(exports, "ConsoleLogger", { enumerable: true, get: function () { return console_logger_1.ConsoleLogger; } });
var config_1 = require("./config");
Object.defineProperty(exports, "LOG_LEVEL_CONFIG", { enumerable: true, get: function () { return config_1.LOG_LEVEL_CONFIG; } });
Object.defineProperty(exports, "LOG_OUTPUT_CONFIG", { enumerable: true, get: function () { return config_1.LOG_OUTPUT_CONFIG; } });
Object.defineProperty(exports, "ANSI_COLORS", { enumerable: true, get: function () { return config_1.ANSI_COLORS; } });
Object.defineProperty(exports, "buildLogPrefix", { enumerable: true, get: function () { return config_1.buildLogPrefix; } });
Object.defineProperty(exports, "getColorCode", { enumerable: true, get: function () { return config_1.getColorCode; } });
Object.defineProperty(exports, "getMaxTextLength", { enumerable: true, get: function () { return config_1.getMaxTextLength; } });
Object.defineProperty(exports, "getLogPrefixWidth", { enumerable: true, get: function () { return config_1.getLogPrefixWidth; } });
//# sourceMappingURL=index.js.map
"use strict";
/**
 * ConsoleLogger implementation providing color-formatted console output
 * with level filtering, configurable formatting, and secret masking.
 *
 * @req FR:console.interface
 * @req FR:console.level
 * @req FR:console.config
 * @req FR:console.colors
 * @req FR:console.streams
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConsoleLogger = void 0;
const types_1 = require("./types");
const config_1 = require("./config");
/**
 * Check if colors should be used in output.
 * Respects NO_COLOR environment variable and TTY detection.
 */
function shouldUseColors() {
    // NO_COLOR presence (even empty) disables colors
    if ('NO_COLOR' in process.env) {
        return false;
    }
    // Check if stdout is a TTY
    return process.stdout.isTTY === true;
}
/**
 * Map log levels to their numeric thresholds for filtering
 */
const LEVEL_THRESHOLDS = {
    error: types_1.LogLevel.error,
    warning: types_1.LogLevel.warning,
    info: types_1.LogLevel.info,
    verbose: types_1.LogLevel.verbose,
    debug: types_1.LogLevel.debug,
    trace: types_1.LogLevel.trace,
};
/**
 * ConsoleLogger implementation providing color-formatted console output
 * with level filtering and secret masking.
 *
 * @req FR:console.interface
 */
class ConsoleLogger {
    /**
     * Create a ConsoleLogger.
     *
     * @param level Maximum log level to output
     * @param secretManager Optional masker for sensitive values
     * @param outputConfig Optional output configuration overrides
     *
     * @req FR:console.level
     * @req FR:console.config
     */
    constructor(level, secretManager, outputConfig) {
        this.level = level;
        this.secretManager = secretManager;
        const terminalSupportsColors = shouldUseColors();
        this.outputConfig = {
            ...config_1.LOG_OUTPUT_CONFIG,
            ...outputConfig,
            // Override useColor if terminal doesn't support it
            useColor: terminalSupportsColors && (outputConfig?.useColor ?? config_1.LOG_OUTPUT_CONFIG.useColor),
        };
    }
    error(source, action, message, data) {
        this.log('error', LEVEL_THRESHOLDS.error, source, action, message, data, true);
    }
    warning(source, action, message, data) {
        this.log('warning', LEVEL_THRESHOLDS.warning, source, action, message, data, true);
    }
    info(source, action, message, data) {
        this.log('info', LEVEL_THRESHOLDS.info, source, action, message, data, false);
    }
    verbose(source, action, message, data) {
        this.log('verbose', LEVEL_THRESHOLDS.verbose, source, action, message, data, false);
    }
    debug(source, action, message, data) {
        this.log('debug', LEVEL_THRESHOLDS.debug, source, action, message, data, false);
    }
    trace(source, action, message, data) {
        this.log('trace', LEVEL_THRESHOLDS.trace, source, action, message, data, false);
    }
    /**
     * Internal log method handling filtering, formatting, masking, and output.
     *
     * @req FR:interface.filtering
     * @req FR:interface.format
     * @req FR:interface.serialization
     * @req FR:interface.masking
     */
    log(levelName, levelThreshold, source, action, message, data, useStderr) {
        // Level filtering - fast path for filtered messages
        // @req NFR:performance.filtered
        if (this.level < levelThreshold) {
            return;
        }
        // Build the prefix using configuration
        // @req FR:config.format
        const prefix = (0, config_1.buildLogPrefix)(levelName, this.outputConfig);
        // Format: {prefix}{source}.{action}: {message} {data}
        // @req FR:interface.format
        let output = `${prefix}${source}.${action}: ${message}`;
        // Serialize data if provided
        // @req FR:interface.serialization
        if (data !== undefined) {
            try {
                output += ' ' + JSON.stringify(data);
            }
            catch {
                output += ' [unserializable]';
            }
        }
        // Apply secret masking if available
        // @req FR:secrets.mask
        if (this.secretManager) {
            output = this.secretManager.mask(output);
        }
        // Apply color based on level and configuration
        // @req FR:console.colors
        if (this.outputConfig.useColor) {
            output = this.colorize(levelName, levelThreshold, prefix, output);
        }
        // Output to appropriate stream
        // @req FR:console.streams
        const stream = useStderr ? process.stderr : process.stdout;
        stream.write(output + '\n');
    }
    /**
     * Apply ANSI color based on log level and configuration.
     *
     * @param levelName - The log level name
     * @param levelThreshold - The numeric level threshold for this log level
     * @param prefix - The prefix portion of the output
     * @param fullOutput - The complete output string
     * @returns Colorized output string
     *
     * @req FR:console.colors
     * @req FR:config.options (fullColorThreshold, defaultColor)
     */
    colorize(levelName, levelThreshold, prefix, fullOutput) {
        const colorCode = (0, config_1.getColorCode)(levelName);
        if (!colorCode) {
            return fullOutput;
        }
        // Check if this level should get full-line color
        const { fullColorThreshold } = this.outputConfig;
        const useFullColor = fullColorThreshold !== null && levelThreshold <= fullColorThreshold;
        if (useFullColor) {
            // Color the entire line
            return `${colorCode}${fullOutput}${config_1.ANSI_COLORS.reset}`;
        }
        else {
            // Color prefix with level color, message with default color (if set)
            const messageStart = prefix.length;
            const coloredPrefix = `${colorCode}${prefix}${config_1.ANSI_COLORS.reset}`;
            const messageContent = fullOutput.substring(messageStart);
            if (this.outputConfig.defaultColor) {
                const defaultColorCode = config_1.ANSI_COLORS[this.outputConfig.defaultColor];
                return `${coloredPrefix}${defaultColorCode}${messageContent}${config_1.ANSI_COLORS.reset}`;
            }
            return coloredPrefix + messageContent;
        }
    }
}
exports.ConsoleLogger = ConsoleLogger;
//# sourceMappingURL=console-logger.js.map
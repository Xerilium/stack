"use strict";
/**
 * Logging configuration for console output formatting
 *
 * Provides customizable formatting options for log output including
 * icons, text labels, colors, and alignment settings.
 *
 * @req FR:config.levels
 * @req FR:config.options
 * @req FR:config.format
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOG_OUTPUT_CONFIG = exports.LOG_LEVEL_CONFIG = exports.ANSI_COLORS = void 0;
exports.getMaxTextLength = getMaxTextLength;
exports.buildLogPrefix = buildLogPrefix;
exports.getColorCode = getColorCode;
exports.getLogPrefixWidth = getLogPrefixWidth;
/**
 * ANSI color codes for log output
 * @req FR:console.colors
 */
exports.ANSI_COLORS = {
    reset: '\x1b[0m',
    default: '',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    gray: '\x1b[90m',
    dim: '\x1b[2m',
};
/**
 * Per-level format settings
 * @req FR:config.levels
 */
exports.LOG_LEVEL_CONFIG = {
    error: { icon: '❌', text: 'ERROR', color: 'red' },
    warning: { icon: '⚠️', text: 'WARN', color: 'yellow' },
    info: { icon: 'ℹ️ ', text: 'INFO', color: 'default' }, // Default terminal color — most readable for the most common level
    verbose: { icon: '🔍', text: 'VERB', color: 'dim' },
    debug: { icon: '🐛', text: 'DEBUG', color: 'magenta' },
    trace: { icon: '🧵', text: 'TRACE', color: 'cyan' },
};
/**
 * Default output configuration
 * @req FR:config.options
 */
exports.LOG_OUTPUT_CONFIG = {
    showIcon: false,
    showText: true,
    useColor: true,
    fullColorThreshold: 1, // LogLevel.warning - errors and warnings get full color
    defaultColor: 'gray', // Message text color when not using full-line color
    alignText: true,
};
/**
 * Calculate the maximum text label length for alignment padding
 * @req FR:config.format
 */
function getMaxTextLength() {
    return Math.max(...Object.values(exports.LOG_LEVEL_CONFIG).map((config) => config.text.length));
}
/**
 * Build the log prefix based on configuration
 *
 * Format: {icon}{space}{text}{pad}{separator}
 * - {icon} is the level icon (if showIcon is true)
 * - {space} is a single space (only if both showIcon and showText are true)
 * - {text} is the level text label (if showText is true)
 * - {pad} is padding spaces for alignment (if showText and alignText are true)
 * - {separator} is ": " (only if showText is true)
 *
 * @param levelName - The log level name (error, warning, info, verbose, debug, trace)
 * @param config - Output configuration options
 * @returns Formatted prefix string
 * @req FR:config.format
 */
function buildLogPrefix(levelName, config = exports.LOG_OUTPUT_CONFIG) {
    const levelConfig = exports.LOG_LEVEL_CONFIG[levelName];
    if (!levelConfig) {
        return '';
    }
    const parts = [];
    // Add icon if enabled
    if (config.showIcon) {
        parts.push(levelConfig.icon);
    }
    // Add space after icon (before text or message)
    if (config.showIcon) {
        parts.push(' ');
    }
    // Add text if enabled
    if (config.showText) {
        let text = levelConfig.text;
        // Add padding for alignment if enabled
        if (config.alignText) {
            const maxLen = getMaxTextLength();
            text = text.padEnd(maxLen);
        }
        parts.push(text);
        // Add separator (only if text is shown)
        parts.push(': ');
    }
    return parts.join('');
}
/**
 * Get the ANSI color code for a log level
 *
 * @param levelName - The log level name
 * @returns ANSI color escape code
 */
function getColorCode(levelName) {
    const levelConfig = exports.LOG_LEVEL_CONFIG[levelName];
    if (!levelConfig) {
        return '';
    }
    return exports.ANSI_COLORS[levelConfig.color];
}
/**
 * Calculate the display width of a log prefix for multiline alignment.
 *
 * This accounts for:
 * - Icon display width (2 columns for most emojis)
 * - Space after icon
 * - Text label with padding
 * - Separator (": ")
 * - Source.Action identifier
 *
 * @param sourceAction - The "Source.Action" identifier (e.g., "CLI.Main")
 * @param config - Output configuration options
 * @returns Number of display columns for the full prefix
 * @req FR:multiline.width
 */
function getLogPrefixWidth(sourceAction, config = exports.LOG_OUTPUT_CONFIG) {
    let width = 0;
    // Icon width (emojis typically render as 2 display columns)
    if (config.showIcon) {
        width += 2; // emoji display width
        width += 1; // space after icon
    }
    // Text label width
    if (config.showText) {
        if (config.alignText) {
            width += getMaxTextLength();
        }
        else {
            // Use longest label for consistent alignment even without padding
            width += getMaxTextLength();
        }
        width += 2; // ": " separator
    }
    // Source.Action identifier + ": "
    width += sourceAction.length + 2;
    return width;
}
//# sourceMappingURL=config.js.map
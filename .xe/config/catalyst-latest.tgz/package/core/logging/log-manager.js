"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogManager = void 0;
const node_async_hooks_1 = require("node:async_hooks");
const errors_1 = require("../errors");
class NoOpLogger {
    error() { }
    warning() { }
    info() { }
    verbose() { }
    debug() { }
    trace() { }
}
const noOpLogger = new NoOpLogger();
const loggerScope = new node_async_hooks_1.AsyncLocalStorage();
/**
 * Contextual logger resolution.
 *
 * - `current()` returns the active scoped logger, falling back to the framework default, then no-op.
 * - `setFramework()` installs the default logger once at application startup.
 * - `scope(logger, fn)` runs `fn` with `logger` as the active logger for its entire async call tree.
 *
 * @req FR:logging/access.current
 * @req FR:logging/access.default
 * @req FR:logging/access.contextual
 * @req FR:logging/access.isolation
 * @req FR:logging/access.fallback
 * @req FR:logging/access.reset
 */
class LogManager {
    /**
     * Return the logger appropriate for the current execution context.
     * Prefers the nearest enclosing scope established via {@link scope}; falls
     * back to the framework default, then to a no-op logger.
     */
    static current() {
        return loggerScope.getStore() ?? LogManager.frameworkLogger ?? noOpLogger;
    }
    /**
     * Return the framework default logger, bypassing any active scope.
     *
     * For framework-internal instrumentation (engine, template engine, action
     * internals) that should NOT route through playbook-scoped loggers. Playbook
     * author output (log-* actions, display) should use {@link current} instead.
     */
    static framework() {
        return LogManager.frameworkLogger ?? noOpLogger;
    }
    static setFramework(logger) {
        if (LogManager.frameworkLocked) {
            throw new errors_1.CatalystError('Logger has already been initialized', 'LoggerAlreadyInitialized', 'Framework logger can only be configured once at application startup. Use reset() first (testing only) to reconfigure.');
        }
        LogManager.frameworkLogger = logger;
        LogManager.frameworkLocked = true;
    }
    static scope(logger, fn) {
        return loggerScope.run(logger, fn);
    }
    static reset() {
        LogManager.frameworkLogger = null;
        LogManager.frameworkLocked = false;
    }
}
exports.LogManager = LogManager;
LogManager.frameworkLogger = null;
LogManager.frameworkLocked = false;
//# sourceMappingURL=log-manager.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogLevel = void 0;
/**
 * Log verbosity levels with numeric values for comparison.
 *
 * Higher numeric values include all lower level output.
 * Use with CLI -v flags: -v=info, -vv=verbose, -vvv=debug, -vvvv=trace
 */
var LogLevel;
(function (LogLevel) {
    /** No output at all */
    LogLevel[LogLevel["silent"] = -1] = "silent";
    /** Errors only */
    LogLevel[LogLevel["error"] = 0] = "error";
    /** Warnings and errors */
    LogLevel[LogLevel["warning"] = 1] = "warning";
    /** Info, warnings, and errors (same level as warning) */
    LogLevel[LogLevel["info"] = 1] = "info";
    /** Verbose output including step flow */
    LogLevel[LogLevel["verbose"] = 2] = "verbose";
    /** Debug output including interpolation details */
    LogLevel[LogLevel["debug"] = 3] = "debug";
    /** Maximum detail - everything including expression evaluation */
    LogLevel[LogLevel["trace"] = 4] = "trace";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
//# sourceMappingURL=types.js.map
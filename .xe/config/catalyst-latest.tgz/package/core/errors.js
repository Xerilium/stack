"use strict";
/**
 * Error handling utilities for Catalyst
 * Provides standardized error classes, enums, and policy interfaces
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorAction = exports.CatalystError = void 0;
/**
 * Base class for all Catalyst errors
 * Provides error code, user-facing message, actionable guidance, and cause chaining
 *
 * @req FR:error-handling/catalyst-error
 * @req FR:error-handling/catalyst-error.extends-error
 * @req FR:error-handling/catalyst-error.constructor
 * @req FR:error-handling/catalyst-error.stack-traces
 * @req FR:error-handling/catalyst-error.serialization
 */
class CatalystError extends Error {
    constructor(message, code, guidance, cause) {
        super(message);
        this.code = code;
        this.guidance = guidance;
        this.cause = cause;
        this.name = 'CatalystError';
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, CatalystError);
        }
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            code: this.code,
            guidance: this.guidance,
            cause: this.cause ? this.cause.message : null,
            stack: this.stack
        };
    }
}
exports.CatalystError = CatalystError;
/**
 * Error handling action enum
 * Specifies what action to take when an error occurs
 *
 * @req FR:error-handling/error-action
 * @req FR:error-handling/error-action.values
 */
var ErrorAction;
(function (ErrorAction) {
    ErrorAction["Stop"] = "Stop";
    ErrorAction["Suspend"] = "Suspend";
    ErrorAction["Break"] = "Break";
    ErrorAction["Inquire"] = "Inquire";
    ErrorAction["Continue"] = "Continue";
    ErrorAction["SilentlyContinue"] = "SilentlyContinue";
    ErrorAction["Ignore"] = "Ignore";
})(ErrorAction || (exports.ErrorAction = ErrorAction = {}));
//# sourceMappingURL=errors.js.map
"use strict";
/**
 * StepExecutor Implementation
 *
 * Provides isolated step execution capability to actions without exposing
 * the Engine or PlaybookContext. This prevents actions from casting to Engine
 * and accessing privileged context.
 *
 * Security: Actions receive only execution capability, not direct Engine access.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.StepExecutorImpl = void 0;
/**
 * Isolated StepExecutor implementation that delegates to Engine
 * without exposing Engine internals
 *
 * @req FR:playbook-engine/step-executor.interface - StepExecutor interface implementation
 */
class StepExecutorImpl {
    constructor(engine) {
        this.engine = engine;
    }
    /**
     * Execute steps with variable overrides
     *
     * Delegates to Engine's executeSteps method without exposing Engine instance.
     */
    async executeSteps(steps, variableOverrides) {
        return this.engine.executeSteps(steps, variableOverrides);
    }
    /**
     * Get current playbook call stack
     *
     * Delegates to Engine's getCallStack method for circular reference detection.
     */
    getCallStack() {
        return this.engine.getCallStack();
    }
    /**
     * Get a variable value by name
     *
     * Delegates to Engine's getVariable method for secure variable access.
     */
    getVariable(name) {
        return this.engine.getVariable(name);
    }
    /**
     * Set a variable value by name
     *
     * Delegates to Engine's setVariable method for variable mutation.
     *
     * @req FR:playbook-engine/step-executor.interface
     */
    setVariable(name, value) {
        this.engine.setVariable(name, value);
    }
}
exports.StepExecutorImpl = StepExecutorImpl;
//# sourceMappingURL=step-executor-impl.js.map
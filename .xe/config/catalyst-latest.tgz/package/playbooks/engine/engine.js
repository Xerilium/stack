"use strict";
// @req FR:playbook-engine/execution - Sequential step execution orchestration
// @req FR:playbook-engine/state - State persistence and resume capability
// @req FR:playbook-engine/step-executor - StepExecutor interface implementation
// @req FR:playbook-engine/actions.instantiation - Action instantiation via PlaybookProvider
// @req FR:playbook-engine/actions.instantiation.caching
// @req FR:playbook-engine/error - Error handling with policies and retry
// @req FR:playbook-engine/error.catch
// @req FR:playbook-engine/error.finally
// @req FR:playbook-engine/locking - Resource lock management
// @req NFR:playbook-engine/performance.overhead
// @req NFR:playbook-engine/performance.dispatch
// @req NFR:playbook-engine/performance.state-save
// @req NFR:playbook-engine/reliability.circular-detection
// @req NFR:playbook-engine/testability.mockable-state
// @req NFR:playbook-engine/testability.mockable-template
// @req NFR:playbook-engine/extensibility.action-plugins
// @req NFR:playbook-engine/extensibility.action-agnostic
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Engine = void 0;
const errors_1 = require("../../core/errors");
const logging_1 = require("../../core/logging");
const engine_1 = require("../template/engine");
const action_catalog_1 = require("../registry/action-catalog");
const state_persistence_1 = require("../persistence/state-persistence");
const error_handler_1 = require("./error-handler");
const lock_manager_1 = require("./lock-manager");
const validators_1 = require("./validators");
const var_action_1 = require("./actions/var-action");
const return_action_1 = require("./actions/return-action");
const checkpoint_action_1 = require("./actions/checkpoint-action");
const checkpoint_prompter_1 = require("./checkpoint-prompter");
const function_action_1 = require("./actions/function-action");
const function_invocation_action_1 = require("./actions/function-invocation-action");
const step_executor_impl_1 = require("./step-executor-impl");
const playbook_provider_1 = require("../registry/playbook-provider");
/**
 * Extract template variable references from a value.
 * Recognises both {{variable}} and ${{ get('variable') }} syntax.
 * Escaped forms (\{{variable}} and \{{variable\}}) are ignored — they represent
 * literal text that will not be interpolated at runtime.
 * Protocol paths (e.g. xe://product.md) are included as data references.
 * Recursively walks objects and arrays.
 */
function extractVarRefs(value) {
    if (typeof value === 'string') {
        const refs = [];
        // {{variable}} — simple template syntax (negative lookbehind excludes ${{ and \{{ )
        for (const m of value.matchAll(/(?<![\$\\])\{\{([^}]+)\}\}/g)) {
            refs.push(m[1].trim());
        }
        // ${{ get('variable') }} — expression syntax
        for (const m of value.matchAll(/get\(['"]([^'"]+)['"]\)/g)) {
            refs.push(m[1]);
        }
        // protocol://path — resource protocol references (e.g. xe://, temp://, catalyst://)
        for (const m of value.matchAll(/\b([a-z][\w-]*:\/\/[^\s"'{}]+)/g)) {
            refs.push(m[1]);
        }
        return refs;
    }
    if (Array.isArray(value)) {
        return value.flatMap(extractVarRefs);
    }
    if (value !== null && typeof value === 'object') {
        return Object.values(value).flatMap(extractVarRefs);
    }
    return [];
}
/**
 * Recursively walk playbook steps to build a what-if summary tree.
 * Descends into known control-flow actions (if, for-each) to show nested structure.
 */
function walkStepsForWhatIf(steps) {
    return steps.map((step, index) => {
        const config = step.config;
        // Collect variable references from non-nested config values
        const varRefs = [];
        if (config && typeof config === 'object' && !Array.isArray(config)) {
            for (const [key, val] of Object.entries(config)) {
                if (!isNestedStepKey(step.action, key)) {
                    varRefs.push(...extractVarRefs(val));
                }
            }
        }
        // For var actions, use the config name as the step name if no explicit name
        let stepName = step.name || `${step.action}-${index + 1}`;
        let hasExplicitName = !!step.name;
        if (step.action === 'var' && !step.name && config && typeof config.name === 'string') {
            stepName = config.name;
            hasExplicitName = true;
        }
        const entry = {
            stepName,
            actionType: step.action,
            inputVarRefs: [...new Set(varRefs)],
            hasExplicitName
        };
        // Recurse into control-flow nested steps
        const nested = extractNestedSteps(step.action, config);
        if (nested && Object.keys(nested).length > 0) {
            entry.children = {};
            for (const [label, childSteps] of Object.entries(nested)) {
                entry.children[label] = walkStepsForWhatIf(childSteps);
            }
        }
        return entry;
    });
}
/** Keys that contain nested step arrays (not input params) for each action type */
function isNestedStepKey(actionType, key) {
    if (actionType === 'if')
        return key === 'then' || key === 'else';
    if (actionType === 'for-each')
        return key === 'steps';
    return false;
}
/** Extract nested step arrays from known control-flow action configs */
function extractNestedSteps(actionType, config) {
    if (!config || typeof config !== 'object')
        return null;
    if (actionType === 'if') {
        const result = {};
        if (Array.isArray(config.then))
            result.then = config.then;
        if (Array.isArray(config.else))
            result.else = config.else;
        return Object.keys(result).length > 0 ? result : null;
    }
    if (actionType === 'for-each') {
        if (Array.isArray(config.steps)) {
            return { steps: config.steps };
        }
        return null;
    }
    return null;
}
/**
 * Playbook execution engine
 *
 * Orchestrates workflow execution by:
 * - Validating playbook structure and inputs
 * - Executing steps sequentially
 * - Delegating to registered actions
 * - Managing execution state
 * - Supporting pause/resume capability
 * - Implementing StepExecutor interface for nested step execution
 *
 * @example
 * ```typescript
 * const engine = new Engine();
 *
 * // Register actions
 * engine.registerAction('file-write', new FileWriteAction());
 *
 * // Execute playbook
 * const result = await engine.run(playbook, {
 *   'user-email': 'alice@example.com'
 * });
 *
 * console.log(result.status); // 'completed'
 * ```
 */
class Engine {
    constructor(templateEngine, statePersistence, errorHandler, lockManager, checkpointPrompter, logger) {
        /** Current playbook call stack for circular reference detection */
        this.currentCallStack = [];
        this.templateEngine = templateEngine ?? new engine_1.TemplateEngine();
        this.statePersistence = statePersistence ?? new state_persistence_1.StatePersistence();
        this.errorHandler = errorHandler ?? new error_handler_1.ErrorHandler();
        this.lockManager = lockManager ?? new lock_manager_1.LockManager();
        this.checkpointPrompter = checkpointPrompter ?? new checkpoint_prompter_1.TerminalCheckpointPrompter();
        this.logger = logger ?? new logging_1.ConsoleLogger(logging_1.LogLevel.error);
        // Create isolated StepExecutor that doesn't expose Engine
        this.stepExecutorImpl = new step_executor_impl_1.StepExecutorImpl(this);
    }
    /**
     * Execute steps with variable overrides (StepExecutor interface implementation)
     *
     * This method implements the StepExecutor interface, enabling actions to delegate
     * nested step execution to the engine while maintaining all execution rules.
     *
     * @req FR:playbook-engine/step-executor.interface - StepExecutor interface implementation
     * @req FR:playbook-engine/step-executor.semantics - Same semantics as top-level steps
     * @req FR:playbook-engine/step-executor.overrides - Variable override support for scoped execution
     * @req FR:playbook-engine/step-executor.results - Return array of step results
     *
     * @param steps - Array of steps to execute sequentially
     * @param variableOverrides - Optional variables to inject into execution scope
     * @returns Promise resolving to array of step results
     *
     * @example
     * ```typescript
     * // Execute nested steps with loop variables
     * const results = await engine.executeSteps(config.steps, {
     *   item: currentItem,
     *   index: i
     * });
     * ```
     */
    async executeSteps(steps, variableOverrides) {
        if (!this.currentContext) {
            throw new errors_1.CatalystError('Cannot execute steps without active execution context', 'NoExecutionContext', 'This method should only be called during playbook execution');
        }
        const results = [];
        let capturedEarlyReturn;
        // Determine effective isolation mode (FR-4.6)
        // Engine controls isolation - actions cannot bypass this security boundary
        const effectiveIsolation = this.getEffectiveIsolation();
        // Save parent variables for potential restoration (isolated mode)
        // or for identifying new variables (shared mode)
        const parentVariables = { ...this.currentContext.variables };
        // @req FR:playbook-engine/actions.builtin.function.scoping - Save function registry for isolation
        const parentFunctions = this.currentContext.functions
            ? { ...this.currentContext.functions }
            : undefined;
        // Track variable override keys so we can exclude them from propagation
        const overrideKeys = new Set(Object.keys(variableOverrides ?? {}));
        // Merge variable overrides (overrides shadow parent variables)
        if (variableOverrides) {
            for (const [key, value] of Object.entries(variableOverrides)) {
                this.currentContext.variables[key] = value;
            }
        }
        try {
            // Execute each step with full engine semantics
            for (let i = 0; i < steps.length; i++) {
                const step = steps[i];
                const stepName = step.name ?? `${step.action}-${i + 1}`;
                // Interpolate step config (inject __logs for logs() accessor)
                // @req FR:playbook-engine/execution.interpolation
                // @req FR:playbook-actions-ai/ai-prompt.interpolation
                // @req FR:playbook-actions-git/common.template-interpolation
                this.currentContext.variables['__logs'] = this.currentContext.logs ?? [];
                let interpolatedConfig;
                try {
                    interpolatedConfig = await this.interpolateStepConfig(step.config, this.currentContext.variables, step.action);
                }
                finally {
                    delete this.currentContext.variables['__logs'];
                }
                // Create fresh action instance with appropriate dependencies
                const action = this.createAction(step.action, this.currentContext);
                // Execute action under playbook logger scope
                // @req FR:playbook-engine/execution.playbook-output
                const result = await logging_1.LogManager.scope(this.logger, () => action.execute(interpolatedConfig));
                // Action instance will be garbage collected after this
                // Check for error
                if (result.error) {
                    throw result.error;
                }
                // Store result in variables for named steps (or all steps in debug mode)
                // @req FR:playbook-engine/execution.result-storage
                if (step.name || this.currentContext.executionOptions?.debug) {
                    this.currentContext.variables[stepName] = result.value;
                }
                // Capture log action results into structured log tracking
                // @req FR:playbook-engine/execution.log-capture
                if (step.action.startsWith('log-') && result.value && typeof result.value === 'object' && 'level' in result.value) {
                    const logValue = result.value;
                    if (!this.currentContext.logs)
                        this.currentContext.logs = [];
                    this.currentContext.logs.push({
                        step: stepName,
                        timestamp: new Date().toISOString(),
                        level: logValue.level,
                        source: logValue.source,
                        action: logValue.action,
                        message: logValue.message,
                        ...(logValue.data ? { data: logValue.data } : {}),
                    });
                }
                // Collect result
                results.push(result);
                // Check for early return (set by ReturnAction in nested steps)
                // If this is nested step execution (variableOverrides present), we should
                // stop executing remaining steps but NOT propagate the return to parent
                if ('earlyReturn' in this.currentContext && this.currentContext.earlyReturn) {
                    // Capture the early return data before breaking
                    capturedEarlyReturn = this.currentContext.earlyReturn;
                    // Early return in nested steps - break out of loop
                    break;
                }
            }
            // If early return was captured, append it as the final result
            // This allows PlaybookRunAction to extract the outputs properly
            if (capturedEarlyReturn) {
                results.push({
                    code: capturedEarlyReturn.code,
                    message: capturedEarlyReturn.message,
                    value: capturedEarlyReturn.outputs,
                    error: undefined
                });
            }
            return results;
        }
        finally {
            // Clear earlyReturn flag if set during nested execution
            // This prevents nested playbook returns from propagating to parent
            if ('earlyReturn' in this.currentContext && this.currentContext.earlyReturn) {
                delete this.currentContext.earlyReturn;
            }
            if (effectiveIsolation) {
                // Isolated mode: Restore parent variables (no propagation)
                this.currentContext.variables = parentVariables;
                // @req FR:playbook-engine/actions.builtin.function.scoping - Restore function registry
                this.currentContext.functions = parentFunctions;
            }
            else {
                // Shared mode: Propagate variables back to parent, excluding overrides
                // Overrides are always scoped regardless of isolation setting
                const newVariables = this.currentContext.variables;
                this.currentContext.variables = parentVariables;
                // Copy new/changed variables back to parent (excluding override keys)
                for (const [key, value] of Object.entries(newVariables)) {
                    if (!overrideKeys.has(key)) {
                        this.currentContext.variables[key] = value;
                    }
                }
                // @req FR:playbook-engine/actions.builtin.function.scoping - Propagate function definitions in shared mode
                // Functions defined in non-isolated scopes (if/for-each) propagate back to parent
                if (this.currentContext.functions) {
                    this.currentContext.functions = { ...this.currentContext.functions };
                }
            }
        }
    }
    /**
     * Get effective isolation mode for current step
     *
     * Determines isolation by checking:
     * 1. Step's explicit `isolated` override (if specified)
     * 2. Action's default `isolated` from PlaybookProvider
     *
     * @returns true for isolated execution, false for shared scope
     */
    getEffectiveIsolation() {
        if (!this.currentContext) {
            return true; // Default to isolated if no context
        }
        // Find the current step being executed
        const currentStepName = this.currentContext.currentStepName;
        const playbook = this.currentContext.playbook;
        // Find the step in the playbook
        const currentStep = playbook.steps.find((step, index) => {
            const stepName = step.name ?? `${step.action}-${index + 1}`;
            return stepName === currentStepName;
        });
        if (!currentStep) {
            return true; // Default to isolated if step not found
        }
        // Check for step-level override first
        if (currentStep.isolated !== undefined) {
            return currentStep.isolated;
        }
        // Fall back to action's default from PlaybookProvider
        const actionType = currentStep.action;
        const provider = playbook_provider_1.PlaybookProvider.getInstance();
        const actionMetadata = provider.getActionInfo(actionType);
        if (actionMetadata?.isolated !== undefined) {
            return actionMetadata.isolated;
        }
        // Default to isolated if not specified (security-first)
        return true;
    }
    /**
     * Get the current playbook call stack
     *
     * Returns the names of playbooks currently being executed, from root to current.
     * Used by playbook invocation actions for circular reference detection.
     *
     * @req FR:playbook-engine/step-executor.call-stack - Provide call stack for circular reference detection
     *
     * @returns Array of playbook names in execution order (root first, current last)
     */
    getCallStack() {
        return [...this.currentCallStack];
    }
    /**
     * Get a variable value by name
     *
     * Provides secure read-only access to playbook variables.
     *
     * @param name - Variable name (kebab-case)
     * @returns Variable value, or undefined if not found
     */
    getVariable(name) {
        return this.currentContext?.variables[name];
    }
    /**
     * Set a variable value by name
     *
     * Provides write access to playbook variables from actions (e.g., script set() function).
     *
     * @param name - Variable name (kebab-case)
     * @param value - Value to assign
     *
     * @req FR:playbook-engine/step-executor.interface
     */
    setVariable(name, value) {
        if (this.currentContext) {
            this.currentContext.variables[name] = value;
        }
    }
    /**
     * Create fresh action instance for step execution
     *
     * Creates a new action instance for each step to ensure:
     * - No state leakage between steps
     * - Correct context for privileged actions (concurrency-safe)
     * - Clean execution environment
     *
     * Privileged actions (var, return) receive context via property injection.
     *
     * @req FR:playbook-engine/actions.instantiation.provider - Use PlaybookProvider for action instantiation
     * @req FR:playbook-engine/actions.instantiation.privileged - Grant privileged access via instanceof validation
     * @req FR:playbook-engine/execution.action-dispatch - Action lookup and invocation
     *
     * @param actionType - Action type identifier (kebab-case)
     * @param context - Current execution context
     * @returns Fresh action instance
     * @throws {CatalystError} If action type not found
     *
     * @example
     * ```typescript
     * const action = this.createAction('var', context);
     * await action.execute({ name: 'user-count', value: 42 });
     * ```
     */
    createAction(actionType, context) {
        // @req FR:playbook-engine/actions.builtin.function.invocation - Check registered functions before catalog
        const functionDef = context.functions?.[actionType];
        if (functionDef) {
            return new function_invocation_action_1.FunctionInvocationAction(this.stepExecutorImpl, functionDef);
        }
        // Create fresh action via PlaybookProvider (no caching for concurrency safety)
        const provider = playbook_provider_1.PlaybookProvider.getInstance();
        const action = provider.createAction(actionType, this.stepExecutorImpl);
        // Grant privileged context access ONLY to hardcoded built-in action classes
        // Uses instanceof check - external actions cannot spoof this because
        // PRIVILEGED_ACTION_CLASSES contains internal constructor references
        if (Engine.PRIVILEGED_ACTION_CLASSES.some(PrivilegedClass => action instanceof PrivilegedClass)) {
            // Attach checkpoint prompter directly to context (must not copy — mutations must propagate)
            context.checkpointPrompter = this.checkpointPrompter;
            action.__context = context; // Direct property injection
        }
        return action;
    }
    /**
     * Abandon a failed or paused run
     *
     * Archives the run state to history, removing it from active runs.
     * Use this to explicitly mark a failed/paused run as no longer needed.
     *
     * @req FR:playbook-engine/state.lifecycle - Manage run state lifecycle
     *
     * @param runId - Run identifier to abandon
     * @throws {CatalystError} If run state cannot be found
     *
     * @example
     * ```typescript
     * // After diagnosing a failed run, abandon it
     * await engine.abandon('20251202-143000-001');
     * ```
     */
    async abandon(runId) {
        // Archive the state (moves from .xe/runs/ to .xe/runs/history/)
        await this.statePersistence.archive(runId);
    }
    /**
     * Clean up stale failed or paused runs
     *
     * Archives runs older than the specified threshold. Useful for scheduled
     * cleanup of abandoned runs to prevent .xe/runs/ from accumulating old failures.
     *
     * @req FR:playbook-engine/state.lifecycle - Provide cleanup mechanism for old runs
     *
     * @param options - Cleanup options
     * @param options.olderThanDays - Age threshold in days (default: 7)
     * @returns Number of runs cleaned up
     *
     * @example
     * ```typescript
     * // Archive failed/paused runs older than 7 days
     * const cleaned = await engine.cleanupStaleRuns({ olderThanDays: 7 });
     * console.log(`Cleaned up ${cleaned} stale runs`);
     * ```
     */
    async cleanupStaleRuns(options = {}) {
        const { olderThanDays = 7 } = options;
        const thresholdMs = olderThanDays * 24 * 60 * 60 * 1000;
        const now = Date.now();
        let cleaned = 0;
        try {
            // Load all state files from the configured runs directory
            const fs = await Promise.resolve().then(() => __importStar(require('fs/promises')));
            const path = await Promise.resolve().then(() => __importStar(require('path')));
            const runsDir = this.statePersistence.runsDir;
            const files = await fs.readdir(runsDir);
            for (const file of files) {
                if (!file.startsWith('run-') || !file.endsWith('.json')) {
                    continue;
                }
                const filePath = path.join(runsDir, file);
                const stat = await fs.stat(filePath);
                const age = now - stat.mtimeMs;
                // Only clean up if older than threshold
                if (age < thresholdMs) {
                    continue;
                }
                // Load state to check status
                try {
                    const content = await fs.readFile(filePath, 'utf-8');
                    const state = JSON.parse(content);
                    // Only archive failed/paused runs, not running ones
                    if (state.status === 'failed' || state.status === 'paused') {
                        await this.statePersistence.archive(state.runId);
                        cleaned++;
                    }
                }
                catch (error) {
                    console.error(`Failed to process ${file}:`, error);
                    // Skip corrupted files
                    continue;
                }
            }
            return cleaned;
        }
        catch (error) {
            // If runs directory doesn't exist, no runs to clean
            if (error.code === 'ENOENT') {
                return 0;
            }
            throw error;
        }
    }
    /**
     * Execute a playbook
     *
     * Runs all steps sequentially, validates inputs/outputs, persists state.
     *
     * @req FR:playbook-engine/execution.sequential - Execute steps sequentially
     * @req FR:playbook-engine/execution.no-skip - Never skip or reorder steps
     * @req FR:playbook-engine/execution.validation.structure - Validate playbook structure
     * @req FR:playbook-engine/execution.validation.inputs - Validate inputs
     * @req FR:playbook-engine/state.persistence - Persist state after each step
     *
     * @param playbook - Playbook definition to execute
     * @param inputs - Input parameter values (kebab-case keys)
     * @param options - Execution configuration
     * @returns Execution result with status, outputs, and metrics
     * @throws CatalystError if validation fails or execution errors occur
     */
    async run(playbook, inputs = {}, options = {}) {
        // Initialize call stack for root execution
        const callStack = [];
        const result = await this.executeInternal(playbook, inputs, options, callStack);
        // Release stdin resources that readline.emitKeypressEvents() may have
        // acquired during checkpoint prompts. Must happen at the top level only
        // (not in nested playbook runs) to avoid disrupting active checkpoints.
        if (this.checkpointPrompter instanceof checkpoint_prompter_1.TerminalCheckpointPrompter) {
            checkpoint_prompter_1.TerminalCheckpointPrompter.releaseStdin();
        }
        return result;
    }
    /**
     * Internal execution method with call stack tracking
     *
     * @param playbook - Playbook definition to execute
     * @param inputs - Input parameter values
     * @param options - Execution configuration
     * @param callStack - Call stack for circular reference detection
     * @returns Execution result
     */
    async executeInternal(playbook, inputs, options, callStack) {
        const startTime = new Date().toISOString();
        const startTimestamp = Date.now();
        const runId = this.generateRunId();
        // Check recursion depth
        const maxDepth = options.maxRecursionDepth ?? 10;
        if (callStack.length >= maxDepth) {
            const endTime = new Date().toISOString();
            return {
                runId,
                status: 'failed',
                outputs: {},
                error: new errors_1.CatalystError(`Maximum recursion depth of ${maxDepth} exceeded. Call stack: ${callStack.join(' -> ')}`, 'MaxRecursionDepthExceeded', 'Reduce playbook nesting or increase maxRecursionDepth option'),
                duration: Date.now() - startTimestamp,
                stepsExecuted: 0,
                startTime,
                endTime
            };
        }
        // Check for circular references
        if (callStack.includes(playbook.name)) {
            const endTime = new Date().toISOString();
            return {
                runId,
                status: 'failed',
                outputs: {},
                error: new errors_1.CatalystError(`Circular reference detected: ${[...callStack, playbook.name].join(' -> ')}`, 'CircularReferenceDetected', 'Remove circular playbook invocations from your workflow'),
                duration: Date.now() - startTimestamp,
                stepsExecuted: 0,
                startTime,
                endTime
            };
        }
        // Add current playbook to call stack
        const currentCallStack = [...callStack, playbook.name];
        // Update current call stack for StepExecutor.getCallStack()
        this.currentCallStack = currentCallStack;
        try {
            // Step 1: Validate playbook structure
            (0, validators_1.validatePlaybookStructure)(playbook);
            // Step 2: Coerce input types, apply defaults, and validate inputs
            const coercedInputs = (0, validators_1.coerceInputTypes)(inputs, playbook.inputs);
            const inputsWithDefaults = (0, validators_1.applyInputDefaults)(coercedInputs, playbook.inputs);
            (0, validators_1.validateInputs)(inputsWithDefaults, playbook.inputs);
            // Step 2.5: What-if mode — return step metadata without executing
            if (options.mode === 'what-if') {
                const summary = walkStepsForWhatIf(playbook.steps || []);
                const endTime = new Date().toISOString();
                return {
                    runId,
                    status: 'completed',
                    outputs: { inputs: playbook.inputs || [], summary },
                    duration: Date.now() - startTimestamp,
                    stepsExecuted: 0,
                    startTime,
                    endTime
                };
            }
            // Step 3: Acquire resource locks if specified
            if (playbook.resources && (playbook.resources.paths || playbook.resources.branches)) {
                await this.lockManager.acquire(runId, playbook.resources, options.actor || 'unknown', options.maxRecursionDepth // Use as TTL hint
                );
            }
            // Step 4: Create execution context
            // Step 4: Create execution context
            const context = {
                playbookName: playbook.name,
                executionOptions: options,
                runId,
                startTime,
                status: 'running',
                currentStepName: '',
                playbook,
                inputs: coercedInputs, // Only user-provided inputs (defaults are already in the playbook definition)
                variables: { ...inputsWithDefaults }, // Start with inputs (including defaults) in variables
                completedSteps: [],
                checkpointResponses: {},
                logs: [],
            };
            // Set current context for StepExecutor and built-in actions
            this.currentContext = context;
            // Step 5: Execute steps sequentially
            let stepsExecuted = 0;
            let executionError;
            try {
                stepsExecuted = await this.executeStepsInternal(context, options, currentCallStack);
            }
            catch (error) {
                executionError = error instanceof errors_1.CatalystError ? error : new errors_1.CatalystError(error instanceof Error ? error.message : String(error), 'ExecutionFailed', `Step execution failed: ${error instanceof Error ? error.message : String(error)}`);
                // Execute catch blocks if defined
                // @req FR-6.3: Catch section for error recovery with error chaining
                if (playbook.catch) {
                    try {
                        await this.executeCatchBlocks(context, playbook.catch, executionError);
                    }
                    catch (catchError) {
                        // Catch block re-threw - chain original error as cause
                        // Per FR-6.3: Re-thrown errors MUST chain the original caught error as cause
                        if (catchError instanceof errors_1.CatalystError) {
                            // If re-thrown error doesn't already have a cause, chain the original error
                            if (!catchError.cause) {
                                catchError.cause = executionError;
                            }
                            executionError = catchError;
                        }
                        else {
                            // Wrap non-CatalystError with original as cause
                            const catchMsg = catchError instanceof Error ? catchError.message : String(catchError);
                            executionError = new errors_1.CatalystError(catchMsg, 'CatchBlockFailed', `Catch block failed while handling error '${executionError.code}': ${catchMsg}`, executionError);
                        }
                    }
                }
            }
            finally {
                // Execute finally blocks if defined
                if (playbook.finally) {
                    try {
                        await this.executeFinallyBlocks(context, playbook.finally);
                    }
                    catch (finallyError) {
                        const logger = logging_1.LogManager.framework();
                        logger.warning('Engine', 'ExecuteFinally', 'Error in finally block', { error: finallyError instanceof Error ? finallyError.message : String(finallyError) });
                        // Don't fail if finally fails and main execution succeeded
                    }
                }
                // Release resource locks
                if (playbook.resources && (playbook.resources.paths || playbook.resources.branches)) {
                    await this.lockManager.release(runId);
                }
            }
            // If there was an execution error, handle it
            if (executionError) {
                const endTime = new Date().toISOString();
                const duration = Date.now() - startTimestamp;
                // Mark as failed but do NOT archive (keep in .xe/runs/ for retry)
                // @req FR:playbook-engine/state.error-capture
                context.status = 'failed';
                context.error = {
                    code: executionError.code,
                    message: executionError.message,
                    guidance: executionError.guidance,
                };
                await this.statePersistence.save(context);
                return {
                    runId,
                    status: 'failed',
                    outputs: {},
                    error: executionError,
                    duration,
                    stepsExecuted,
                    startTime,
                    endTime
                };
            }
            // Check for early return (set by ReturnAction)
            let outputs;
            if ('earlyReturn' in context && context.earlyReturn) {
                // Early return with explicit outputs
                outputs = context.earlyReturn.outputs;
            }
            else {
                // Normal completion - validate and extract outputs
                // Step 5: Validate outputs
                (0, validators_1.validateOutputs)(playbook.outputs, context.variables);
                // Step 6: Extract outputs
                outputs = this.extractOutputs(playbook.outputs, context.variables);
            }
            // Step 7: Mark as completed and archive
            context.status = 'completed';
            await this.statePersistence.save(context);
            await this.statePersistence.archive(runId);
            // Step 8: Return success result
            const endTime = new Date().toISOString();
            const duration = Date.now() - startTimestamp;
            return {
                runId,
                status: 'completed',
                outputs,
                duration,
                stepsExecuted,
                startTime,
                endTime
            };
        }
        catch (error) {
            // Return error result
            const endTime = new Date().toISOString();
            const duration = Date.now() - startTimestamp;
            return {
                runId,
                status: 'failed',
                outputs: {},
                error: error instanceof errors_1.CatalystError ? error : new errors_1.CatalystError(error instanceof Error ? error.message : String(error), 'ExecutionFailed', `Playbook execution failed: ${error instanceof Error ? error.message : String(error)}`),
                duration,
                stepsExecuted: 0,
                startTime,
                endTime
            };
        }
    }
    /**
     * Resume a paused playbook execution
     *
     * Loads state from disk and continues execution from the last completed step.
     * NOTE: For Phase 2, resume requires the playbook to be re-provided since
     * we don't yet have a playbook registry. Phase 3 will add full resume support.
     *
     * @req FR:playbook-engine/state.resume - Load state and skip completed steps
     * @req NFR:playbook-engine/reliability.state-validation - Detect state corruption with clear recovery instructions
     *
     * @param runId - Run identifier to resume
     * @param playbook - Playbook definition (temporary requirement for Phase 2)
     * @param options - Execution configuration (can override original options)
     * @returns Execution result with continuation status
     * @throws CatalystError if state cannot be loaded or is invalid
     */
    async resume(runId, playbook, options = {}) {
        const startTimestamp = Date.now();
        try {
            // Step 1: Load state from disk
            const state = await this.statePersistence.load(runId);
            // Step 2: Validate state structure
            if (!state.playbookName || !state.runId || !state.variables) {
                throw new errors_1.CatalystError(`State for run ${runId} is corrupted or incomplete`, 'StateCorrupted', 'The state file is missing required fields. Check the state file integrity.');
            }
            // Step 3: Validate playbook compatibility
            if (playbook.name !== state.playbookName) {
                throw new errors_1.CatalystError(`Playbook name mismatch: state has "${state.playbookName}", provided "${playbook.name}"`, 'PlaybookIncompatible', 'Ensure you are resuming with the same playbook that was originally executed');
            }
            // Step 4: Reconstruct execution context
            const context = {
                ...state,
                executionOptions: options, // Override with current options (user may change between resumes)
                playbook,
                status: 'running',
                logs: state.logs ?? [], // Initialize if resuming from old state without logs
            };
            // Set current context for StepExecutor and built-in actions
            this.currentContext = context;
            // Step 5: Resume execution from next uncompleted step
            let stepsExecuted = 0;
            for (let i = 0; i < playbook.steps.length; i++) {
                const step = playbook.steps[i];
                const stepName = step.name ?? `${step.action}-${i + 1}`;
                // Skip already-completed steps
                if (context.completedSteps.includes(stepName)) {
                    continue;
                }
                // Execute this step
                context.currentStepName = stepName;
                await this.statePersistence.save(context);
                context.variables['__logs'] = context.logs ?? [];
                let interpolatedConfig;
                try {
                    interpolatedConfig = await this.interpolateStepConfig(step.config, context.variables, step.action);
                }
                finally {
                    delete context.variables['__logs'];
                }
                // Create fresh action instance with appropriate dependencies
                const action = this.createAction(step.action, context);
                // @req FR:playbook-engine/execution.playbook-output
                const result = await logging_1.LogManager.scope(this.logger, () => action.execute(interpolatedConfig));
                // Action instance will be garbage collected after this
                if (result.error) {
                    throw result.error;
                }
                // Store result in variables for named steps (or all steps in debug mode)
                // @req FR:playbook-engine/execution.result-storage
                if (step.name || context.executionOptions?.debug) {
                    context.variables[stepName] = result.value;
                }
                context.completedSteps.push(stepName);
                stepsExecuted++;
                // Save state after step completion
                await this.statePersistence.save(context);
            }
            // Step 6: Validate outputs
            (0, validators_1.validateOutputs)(playbook.outputs, context.variables);
            // Step 7: Extract outputs
            const outputs = this.extractOutputs(playbook.outputs, context.variables);
            // Step 8: Mark as completed and archive
            context.status = 'completed';
            await this.statePersistence.save(context);
            await this.statePersistence.archive(runId);
            // Step 9: Return success result
            const endTime = new Date().toISOString();
            const duration = Date.now() - startTimestamp;
            return {
                runId,
                status: 'completed',
                outputs,
                duration,
                stepsExecuted,
                startTime: state.startTime,
                endTime
            };
        }
        catch (error) {
            const endTime = new Date().toISOString();
            const duration = Date.now() - startTimestamp;
            const catalystError = error instanceof errors_1.CatalystError ? error : new errors_1.CatalystError(error instanceof Error ? error.message : String(error), 'ResumeFailed', (error instanceof Error && error.message.includes('ENOENT'))
                ? `Run state not found for run '${runId}'. Verify the runId is correct and the state file exists in .xe/runs/`
                : `Resume failed for run '${runId}': ${error instanceof Error ? error.message : String(error)}`);
            // @req FR:playbook-engine/state.error-capture
            // Try to persist error details to the run state file (best-effort)
            try {
                const failedState = await this.statePersistence.load(runId);
                failedState.status = 'failed';
                failedState.error = {
                    code: catalystError.code,
                    message: catalystError.message,
                    guidance: catalystError.guidance,
                };
                await this.statePersistence.save(failedState);
            }
            catch {
                // State file may not exist or be corrupted — skip persistence
            }
            return {
                runId,
                status: 'failed',
                outputs: {},
                error: catalystError,
                duration,
                stepsExecuted: 0,
                startTime: new Date().toISOString(),
                endTime
            };
        }
    }
    /**
     * Execute all steps in the playbook sequentially (internal)
     *
     * @param context - Execution context
     * @param options - Execution options
     * @param callStack - Call stack for circular reference detection
     * @returns Number of steps executed
     */
    async executeStepsInternal(context, options, callStack) {
        const logger = logging_1.LogManager.framework();
        let stepsExecuted = 0;
        for (let i = 0; i < context.playbook.steps.length; i++) {
            const step = context.playbook.steps[i];
            // Generate step name if not specified
            const stepName = step.name ?? `${step.action}-${i + 1}`;
            context.currentStepName = stepName;
            logger.verbose('Engine', 'ExecuteStep', `Step ${i + 1}/${context.playbook.steps.length}: ${stepName}`, { action: step.action });
            // Save state before executing step
            await this.statePersistence.save(context);
            // Interpolate step config (inject __logs for logs() accessor, clean up after)
            let interpolatedConfig;
            context.variables['__logs'] = context.logs ?? [];
            try {
                interpolatedConfig = await this.interpolateStepConfig(step.config, context.variables, step.action);
            }
            catch (error) {
                // Add step context to interpolation errors
                if (error instanceof errors_1.CatalystError) {
                    throw new errors_1.CatalystError(`Step "${stepName}" (${step.action}): ${error.message}`, error.code, error.guidance, error);
                }
                throw new errors_1.CatalystError(`Step "${stepName}" (${step.action}): ${error instanceof Error ? error.message : String(error)}`, 'TemplateError', 'Check the step configuration for template syntax errors', error instanceof Error ? error : undefined);
            }
            finally {
                delete context.variables['__logs'];
            }
            logger.debug('Engine', 'ExecuteStep', 'Step config interpolated', { stepName, config: interpolatedConfig });
            // Create fresh action instance with appropriate dependencies
            const action = this.createAction(step.action, context);
            // Execute action with error handling
            const result = await this.executeStepWithRetry(action, interpolatedConfig, step.errorPolicy);
            // Check for error
            if (result.error) {
                logger.debug('Engine', 'ExecuteStep', 'Step failed', { stepName, error: result.error.message });
                throw result.error;
            }
            // Store result in variables for named steps (or all steps in debug mode)
            // @req FR:playbook-engine/execution.result-storage
            if (step.name || options.debug) {
                context.variables[stepName] = result.value;
            }
            logger.trace('Engine', 'ExecuteStep', 'Step result stored', { stepName, value: result.value });
            // Capture log action results into structured log tracking
            // @req FR:playbook-engine/execution.log-capture
            // @req FR:playbook-actions-io/display.log-capture
            if ((step.action.startsWith('log-') || step.action === 'display') && result.value && typeof result.value === 'object' && 'level' in result.value) {
                const logValue = result.value;
                if (!context.logs)
                    context.logs = [];
                context.logs.push({
                    step: stepName,
                    timestamp: new Date().toISOString(),
                    level: logValue.level,
                    source: logValue.source,
                    action: logValue.action,
                    message: logValue.message,
                    ...(logValue.data ? { data: logValue.data } : {}),
                });
            }
            // Mark step as completed
            context.completedSteps.push(stepName);
            stepsExecuted++;
            // Save state after step completion
            await this.statePersistence.save(context);
            // Check for early return (set by ReturnAction)
            if ('earlyReturn' in context && context.earlyReturn) {
                // Early return requested - halt execution
                logger.verbose('Engine', 'ExecuteStep', 'Early return requested', { stepName });
                break;
            }
        }
        return stepsExecuted;
    }
    /**
     * Execute a step with retry logic based on error policy
     *
     * @param action - Action to execute
     * @param config - Interpolated configuration
     * @param errorPolicy - Error policy for this step
     * @returns Action result
     */
    async executeStepWithRetry(action, config, errorPolicy) {
        // @req FR:playbook-engine/execution.playbook-output
        // Wrap each action invocation in the playbook logger scope so log-* actions
        // and display actions route through it. Engine-internal instrumentation
        // (before/after this call) keeps using the framework logger.
        const invoke = () => logging_1.LogManager.scope(this.logger, () => action.execute(config));
        // If no error policy or no retry count, execute once
        if (!errorPolicy) {
            return await invoke();
        }
        // For simple ErrorAction string, no retry
        if (typeof errorPolicy === 'string') {
            return await invoke();
        }
        // Try to get retry count from policy
        // Note: We can't determine which error will occur, so we use default retry count
        const retryCount = errorPolicy.default?.retryCount || 0;
        if (retryCount === 0) {
            return await invoke();
        }
        // Execute with retry
        return await this.errorHandler.retryWithBackoff(async () => {
            const result = await invoke();
            if (result.error) {
                throw result.error;
            }
            return result;
        }, retryCount);
    }
    /**
     * Execute catch blocks for error recovery
     * @req FR-6.3: Catch section for error recovery with error chaining
     *
     * @param context - Execution context
     * @param catchBlocks - Array of catch block definitions
     * @param error - The error that occurred
     */
    async executeCatchBlocks(context, catchBlocks, error) {
        // Find matching catch block for this error code
        const matchingBlock = catchBlocks.find(block => block.code === error.code);
        if (!matchingBlock) {
            // No specific catch block for this error code
            return;
        }
        // Per FR-6.3: Caught error MUST be accessible via $error variable
        // Store original variables to restore after catch block
        const originalErrorVar = context.variables['$error'];
        context.variables['$error'] = {
            code: error.code,
            message: error.message,
            guidance: error.guidance
        };
        try {
            // Execute recovery steps
            for (const step of matchingBlock.steps) {
                const stepName = step.name ?? `catch-${step.action}`;
                context.variables['__logs'] = context.logs ?? [];
                let interpolatedConfig;
                try {
                    interpolatedConfig = await this.interpolateStepConfig(step.config, context.variables, step.action);
                }
                finally {
                    delete context.variables['__logs'];
                }
                // Create fresh action instance
                const action = this.createAction(step.action, context);
                // @req FR:playbook-engine/execution.playbook-output
                const result = await logging_1.LogManager.scope(this.logger, () => action.execute(interpolatedConfig));
                // @req FR:playbook-engine/execution.result-storage
                if (result.value !== undefined && (step.name || context.executionOptions?.debug)) {
                    context.variables[stepName] = result.value;
                }
            }
        }
        finally {
            // Restore original $error variable (or remove if it didn't exist)
            if (originalErrorVar === undefined) {
                delete context.variables['$error'];
            }
            else {
                context.variables['$error'] = originalErrorVar;
            }
        }
    }
    /**
     * Execute finally blocks for cleanup
     *
     * @param context - Execution context
     * @param finallySteps - Array of finally step definitions
     */
    async executeFinallyBlocks(context, finallySteps) {
        // Execute cleanup steps
        for (const step of finallySteps) {
            const stepName = step.name ?? `finally-${step.action}`;
            context.variables['__logs'] = context.logs ?? [];
            let interpolatedConfig;
            try {
                interpolatedConfig = await this.interpolateStepConfig(step.config, context.variables, step.action);
            }
            finally {
                delete context.variables['__logs'];
            }
            // Create fresh action instance
            const action = this.createAction(step.action, context);
            // @req FR:playbook-engine/execution.playbook-output
            const result = await logging_1.LogManager.scope(this.logger, () => action.execute(interpolatedConfig));
            // @req FR:playbook-engine/execution.result-storage
            if (result.value !== undefined && (step.name || context.executionOptions?.debug)) {
                context.variables[stepName] = result.value;
            }
        }
    }
    /**
     * Interpolate step configuration using template engine
     *
     * @param config - Step configuration object
     * @param variables - Variables map for interpolation
     * @returns Interpolated configuration
     */
    async interpolateStepConfig(config, variables, actionType) {
        // Only interpolate objects and strings
        if (typeof config === 'string') {
            return await this.templateEngine.interpolate(config, variables);
        }
        if (config !== null && typeof config === 'object' && !Array.isArray(config)) {
            // Get nested step properties to skip from action metadata
            // Extract root property names from paths (e.g., "catch[].steps" → "catch")
            const nestedStepProperties = actionType
                ? (action_catalog_1.ACTION_CATALOG[actionType]?.nestedStepProperties || [])
                : [];
            const skipKeys = nestedStepProperties.map(p => p.split(/[.[]/)[0]);
            return await this.templateEngine.interpolateObject(config, variables, skipKeys);
        }
        // Return non-interpolatable values as-is
        return config;
    }
    /**
     * Extract output values from variables
     *
     * @param outputs - Output specification from playbook
     * @param variables - Variables map
     * @returns Output values
     */
    extractOutputs(outputs, variables) {
        if (!outputs) {
            return {};
        }
        const result = {};
        for (const outputName of Object.keys(outputs)) {
            result[outputName] = variables[outputName];
        }
        return result;
    }
    /**
     * Generate unique run identifier
     *
     * Format: YYYYMMDD-HHMMSS-nnn
     * Example: 20251201-143022-001
     *
     * @returns Run identifier
     */
    generateRunId() {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
        return `${year}${month}${day}-${hours}${minutes}${seconds}-${milliseconds}`;
    }
}
exports.Engine = Engine;
/**
 * Hardcoded list of action constructors that receive privileged context access.
 * External actions CANNOT spoof this - constructor references are internal to playbook-engine.
 * @req FR:playbook-engine/actions.instantiation.privileged - Constructor-based validation for privileged access
 */
Engine.PRIVILEGED_ACTION_CLASSES = [
    var_action_1.VarAction,
    return_action_1.ReturnAction,
    checkpoint_action_1.CheckpointAction,
    function_action_1.FunctionAction
];
//# sourceMappingURL=engine.js.map
"use strict";
/**
 * Checkpoint Action (Built-in)
 *
 * Privileged action that prompts users for interactive decisions at critical points
 * in playbook execution. Supports 1-9 options with optional text input,
 * accelerator keys (& prefix), optional expandable context, single/multi-select,
 * timeout with auto-default, and autonomous auto-selection.
 *
 * @example
 * ```yaml
 * steps:
 *   # Shorthand syntax (primary property) — simple Enter-to-continue
 *   - checkpoint: Review the research findings before proceeding
 *
 *   # Full syntax with options and accelerator keys
 *   - name: review-spec
 *     checkpoint:
 *       message: How should we proceed with the specification?
 *       context: |
 *         The spec covers 3 scenarios with 12 FRs.
 *         All dependencies are satisfied.
 *       options:
 *         - key: approve
 *           label: "&Approve and continue"
 *           emphasis: recommended
 *         - key: revise
 *           label: "&Revise"
 *           description: Describe what needs to change
 *           allowText: true
 *       default: approve
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckpointAction = void 0;
const errors_1 = require("../../../core/errors");
/**
 * Parse accelerator key from label. The & character marks the next character
 * as the accelerator (e.g., "&Continue" → accelerator "c", display "Continue").
 */
function parseAccelerator(label) {
    const idx = label.indexOf('&');
    if (idx < 0 || idx >= label.length - 1) {
        return { displayLabel: label };
    }
    const accelerator = label[idx + 1].toLowerCase();
    const displayLabel = label.slice(0, idx) + label.slice(idx + 1);
    return { displayLabel, accelerator };
}
/**
 * CheckpointAction - Built-in action for interactive user prompts
 *
 * This action has privileged access to PlaybookContext and can:
 * - Display interactive prompts with options
 * - Collect user selections via a CheckpointPrompter
 * - Store responses for resume support
 * - Auto-select in autonomous mode
 *
 * Security: Context is injected via property after instantiation by Engine.
 * External actions cannot spoof this - Engine uses instanceof validation.
 *
 * @req FR:playbook-engine/actions.builtin.checkpoint.interface - Checkpoint config interface
 * @req FR:playbook-engine/actions.builtin.checkpoint.display - Render prompt to terminal
 * @req FR:playbook-engine/actions.builtin.checkpoint.interactive - Collect user input
 * @req FR:playbook-engine/actions.builtin.checkpoint.autonomous - Auto-select in autonomous mode
 * @req FR:playbook-engine/actions.builtin.checkpoint.timeout - Optional timeout
 * @req FR:playbook-engine/actions.builtin.checkpoint.result - Return selection as step result
 * @req FR:playbook-engine/actions.builtin.checkpoint.persistence - Persist responses
 * @req FR:playbook-engine/actions.builtin.checkpoint.resume - Respect previous responses
 */
class CheckpointAction {
    constructor() {
        // Engine injects context via __context property
    }
    /**
     * Execute checkpoint — prompt user or auto-select.
     */
    async execute(config) {
        if (!this.__context) {
            throw new errors_1.CatalystError('CheckpointAction requires privileged context access', 'MissingPrivilegedAccess', 'This action must be instantiated by Engine with context injection');
        }
        if (!config || typeof config !== 'object') {
            throw new errors_1.CatalystError('Checkpoint configuration must be an object', 'CheckpointConfigInvalid', 'Provide config with "message" property');
        }
        if (!config.message || typeof config.message !== 'string') {
            throw new errors_1.CatalystError('Checkpoint message is required and must be a string', 'CheckpointMessageRequired', 'Provide a human-readable message explaining what to review');
        }
        if (config.options && config.options.length > 9) {
            throw new errors_1.CatalystError('Checkpoint supports a maximum of 9 options', 'CheckpointConfigInvalid', 'Reduce the number of options to 9 or fewer');
        }
        const stepName = this.__context.currentStepName;
        const isAutonomous = this.__context.executionOptions?.autonomous ?? false;
        if (!this.__context.checkpointResponses) {
            this.__context.checkpointResponses = {};
        }
        // @req FR:playbook-engine/actions.builtin.checkpoint.resume
        const storedResponse = this.__context.checkpointResponses[stepName];
        if (storedResponse) {
            return {
                code: 'CheckpointRestored',
                message: `Checkpoint "${stepName}" restored from previous response`,
                value: storedResponse,
                error: undefined,
            };
        }
        let response;
        if (isAutonomous) {
            // @req FR:playbook-engine/actions.builtin.checkpoint.autonomous
            response = this.autoSelect(config);
        }
        else {
            // @req FR:playbook-engine/actions.builtin.checkpoint.interactive
            response = await this.promptUser(config);
        }
        // @req FR:playbook-engine/actions.builtin.checkpoint.persistence
        this.__context.checkpointResponses[stepName] = response;
        return {
            code: isAutonomous ? 'CheckpointAutoSelected' : 'CheckpointAnswered',
            message: `Checkpoint "${stepName}": selected "${response.selected}"`,
            value: response,
            error: undefined,
        };
    }
    autoSelect(config) {
        if (config.default && config.options) {
            const defaultOpt = config.options.find(o => o.key === config.default);
            if (defaultOpt) {
                return {
                    selected: defaultOpt.key,
                    value: defaultOpt.value ?? defaultOpt.key,
                    hasTextInput: false,
                };
            }
        }
        if (config.options && config.options.length > 0) {
            const first = config.options[0];
            return {
                selected: first.key,
                value: first.value ?? first.key,
                hasTextInput: false,
            };
        }
        return { selected: 'continue', value: true, hasTextInput: false };
    }
    async promptUser(config) {
        if (!this.__context?.checkpointPrompter) {
            throw new errors_1.CatalystError('No checkpoint prompter available for interactive mode', 'CheckpointPrompterMissing', 'Ensure the engine is configured with a CheckpointPrompter for manual execution');
        }
        const displayOptions = [];
        if (config.options) {
            for (let i = 0; i < config.options.length; i++) {
                const opt = config.options[i];
                const { displayLabel, accelerator } = parseAccelerator(opt.label);
                displayOptions.push({
                    key: opt.key,
                    label: displayLabel,
                    description: opt.description,
                    emphasis: opt.emphasis,
                    number: i + 1,
                    accelerator,
                    allowText: opt.allowText,
                });
            }
        }
        const promptResponse = await this.__context.checkpointPrompter.prompt({
            message: config.message,
            context: config.context,
            options: displayOptions,
            multiSelect: config.multiSelect ?? false,
            timeout: config.timeout,
            defaultKey: config.default,
            header: config.header,
            headerColor: config.headerColor,
        });
        // Map back to option values if not text input
        if (!promptResponse.hasTextInput && config.options) {
            const selectedKeys = Array.isArray(promptResponse.selected)
                ? promptResponse.selected
                : [promptResponse.selected];
            const values = selectedKeys.map(key => {
                const opt = config.options.find(o => o.key === key);
                return opt?.value ?? key;
            });
            return {
                selected: promptResponse.selected,
                value: Array.isArray(promptResponse.selected) ? values : values[0],
                hasTextInput: false,
            };
        }
        return promptResponse;
    }
}
exports.CheckpointAction = CheckpointAction;
CheckpointAction.actionType = 'checkpoint';
CheckpointAction.primaryProperty = 'message';
//# sourceMappingURL=checkpoint-action.js.map
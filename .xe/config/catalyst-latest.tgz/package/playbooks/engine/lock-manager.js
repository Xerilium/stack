"use strict";
// @req FR:playbook-engine/locking - Resource lock management for playbook execution
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LockManager = void 0;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const errors_1 = require("../../core/errors");
/**
 * Lock manager for playbook resource coordination
 *
 * Prevents concurrent execution conflicts by acquiring locks on resources
 * before playbook execution. Uses atomic file operations to ensure
 * consistency.
 *
 * @example
 * ```typescript
 * const lockManager = new LockManager();
 *
 * // Acquire lock
 * await lockManager.acquire('run-123', {
 *   paths: ['src/api'],
 *   branches: ['main']
 * }, 'user@example.com');
 *
 * // Release lock
 * await lockManager.release('run-123');
 * ```
 */
class LockManager {
    constructor(baseDir = '.xe/runs/locks') {
        this.locksDir = baseDir;
    }
    /**
     * Acquire locks on resources
     *
     * @req FR:playbook-engine/locking.acquisition - Support resource locks to prevent conflicts
     * @req FR:playbook-engine/locking.conflict-detection - Detect conflicts on branch names and file paths
     * @req FR:playbook-engine/locking.conflict-prevention - Prevent conflicting runs with clear error message
     * @req NFR:playbook-engine/reliability.atomic-writes - Atomic writes to prevent corruption
     *
     * @param runId - Unique run identifier
     * @param resources - Resources to lock
     * @param owner - Actor acquiring the lock
     * @param ttl - Time to live in milliseconds (default: 1 hour)
     * @throws {CatalystError} If resources are already locked
     */
    async acquire(runId, resources, owner, ttl = 3600000 // 1 hour default
    ) {
        // Ensure locks directory exists
        await fs.mkdir(this.locksDir, { recursive: true });
        // Check if resources are already locked
        const conflictingLock = await this.findConflictingLock(resources);
        if (conflictingLock) {
            throw new errors_1.CatalystError(`Resources are locked by run ${conflictingLock.runId} (owner: ${conflictingLock.owner})`, 'ResourceLocked', `Wait for the conflicting run to complete or release locks manually. Lock acquired at ${conflictingLock.acquiredAt}, expires at ${conflictingLock.expiresAt}`);
        }
        // Create lock object
        const now = new Date();
        const expiresAt = new Date(now.getTime() + ttl);
        const lock = {
            runId,
            owner,
            paths: resources.paths,
            branches: resources.branches,
            acquiredAt: now.toISOString(),
            expiresAt: expiresAt.toISOString()
        };
        // Write lock file atomically (temp file + rename)
        const lockFilePath = path.join(this.locksDir, `run-${runId}.lock`);
        const tempFilePath = `${lockFilePath}.tmp`;
        try {
            await fs.writeFile(tempFilePath, JSON.stringify(lock, null, 2), 'utf-8');
            await fs.rename(tempFilePath, lockFilePath);
        }
        catch (error) {
            // Cleanup temp file if it exists
            try {
                await fs.unlink(tempFilePath);
            }
            catch {
                // Ignore cleanup errors
            }
            throw new errors_1.CatalystError(`Failed to acquire lock: ${error instanceof Error ? error.message : String(error)}`, 'LockAcquisitionFailed', 'Check file system permissions and disk space');
        }
    }
    /**
     * Release locks for a run
     *
     * @req FR:playbook-engine/locking.release - Release locks on playbook completion
     *
     * @param runId - Unique run identifier
     */
    async release(runId) {
        const lockFilePath = path.join(this.locksDir, `run-${runId}.lock`);
        try {
            await fs.unlink(lockFilePath);
        }
        catch (error) {
            // Ignore if file doesn't exist (already released)
            if (error.code !== 'ENOENT') {
                console.error(`Failed to release lock for run ${runId}:`, error);
            }
        }
    }
    /**
     * Check if resources are currently locked
     *
     * @param resources - Resources to check
     * @returns True if any resource is locked
     */
    async isLocked(resources) {
        const conflictingLock = await this.findConflictingLock(resources);
        return conflictingLock !== null;
    }
    /**
     * Clean up stale locks
     *
     * Removes lock files that have exceeded their TTL.
     *
     * @req FR:playbook-engine/locking.cleanup - Automatically clean up stale locks
     * @req NFR:playbook-engine/reliability.lock-ttl - Lock cleanup via TTL expiration
     *
     * @returns Number of stale locks cleaned up
     */
    async cleanupStale() {
        try {
            const files = await fs.readdir(this.locksDir);
            const now = new Date();
            let cleaned = 0;
            for (const file of files) {
                if (!file.endsWith('.lock')) {
                    continue;
                }
                const lockFilePath = path.join(this.locksDir, file);
                try {
                    const content = await fs.readFile(lockFilePath, 'utf-8');
                    const lock = JSON.parse(content);
                    // Check if lock has expired
                    const expiresAt = new Date(lock.expiresAt);
                    if (expiresAt < now) {
                        await fs.unlink(lockFilePath);
                        cleaned++;
                    }
                }
                catch (error) {
                    // If we can't read/parse the lock file, it's corrupted - delete it
                    console.error(`Removing corrupted lock file ${file}:`, error);
                    await fs.unlink(lockFilePath);
                    cleaned++;
                }
            }
            return cleaned;
        }
        catch (error) {
            // If locks directory doesn't exist, no locks to clean
            if (error.code === 'ENOENT') {
                return 0;
            }
            throw error;
        }
    }
    /**
     * Find a lock that conflicts with the requested resources
     *
     * @param resources - Resources to check
     * @returns Conflicting lock or null if no conflict
     */
    async findConflictingLock(resources) {
        try {
            const files = await fs.readdir(this.locksDir);
            const now = new Date();
            for (const file of files) {
                if (!file.endsWith('.lock')) {
                    continue;
                }
                const lockFilePath = path.join(this.locksDir, file);
                try {
                    const content = await fs.readFile(lockFilePath, 'utf-8');
                    const lock = JSON.parse(content);
                    // Skip expired locks
                    const expiresAt = new Date(lock.expiresAt);
                    if (expiresAt < now) {
                        continue;
                    }
                    // Check for path conflicts
                    if (resources.paths && lock.paths) {
                        for (const requestedPath of resources.paths) {
                            for (const lockedPath of lock.paths) {
                                // Check if paths overlap (exact match or one is parent of other)
                                if (requestedPath === lockedPath ||
                                    requestedPath.startsWith(lockedPath + '/') ||
                                    lockedPath.startsWith(requestedPath + '/')) {
                                    return lock;
                                }
                            }
                        }
                    }
                    // Check for branch conflicts
                    if (resources.branches && lock.branches) {
                        for (const requestedBranch of resources.branches) {
                            if (lock.branches.includes(requestedBranch)) {
                                return lock;
                            }
                        }
                    }
                }
                catch (error) {
                    // Skip corrupted lock files
                    console.error(`Skipping corrupted lock file ${file}:`, error);
                    continue;
                }
            }
            return null;
        }
        catch (error) {
            // If locks directory doesn't exist, no conflicts
            if (error.code === 'ENOENT') {
                return null;
            }
            throw error;
        }
    }
    /**
     * Get all active locks
     *
     * @returns Array of active locks
     */
    async getAllLocks() {
        try {
            const files = await fs.readdir(this.locksDir);
            const now = new Date();
            const locks = [];
            for (const file of files) {
                if (!file.endsWith('.lock')) {
                    continue;
                }
                const lockFilePath = path.join(this.locksDir, file);
                try {
                    const content = await fs.readFile(lockFilePath, 'utf-8');
                    const lock = JSON.parse(content);
                    // Only include non-expired locks
                    const expiresAt = new Date(lock.expiresAt);
                    if (expiresAt >= now) {
                        locks.push(lock);
                    }
                }
                catch (error) {
                    // Skip corrupted lock files
                    continue;
                }
            }
            return locks;
        }
        catch (error) {
            // If locks directory doesn't exist, no locks
            if (error.code === 'ENOENT') {
                return [];
            }
            throw error;
        }
    }
}
exports.LockManager = LockManager;
//# sourceMappingURL=lock-manager.js.map
"use strict";
/**
 * Script Action - JavaScript execution in isolated VM context
 *
 * Executes JavaScript code in an isolated VM context with controlled access to:
 * - fs module for file operations
 * - path module for path manipulation
 * - console for logging
 * - get() function for reading playbook variables (via StepExecutor)
 * - set() function for writing playbook variables (via StepExecutor)
 * - URL and URLSearchParams for URL parsing
 * - Buffer for encoding/decoding
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScriptAction = void 0;
const vm = __importStar(require("vm"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const action_1 = require("../../types/action");
const errors_1 = require("./errors");
/**
 * Default timeout for script execution (30 seconds)
 */
const DEFAULT_TIMEOUT = 30000;
/**
 * JavaScript execution action
 *
 * Executes JavaScript code in an isolated VM context with file system access
 * and playbook variable access via the get() function.
 *
 * @example
 * ```typescript
 * const action = new ScriptAction(stepExecutor);
 * const result = await action.execute({
 *   code: `
 *     const data = get('step-result');
 *     const files = fs.readdirSync('.');
 *     return { data, fileCount: files.length };
 *   `,
 *   timeout: 30000
 * });
 * ```
 *
 * @req FR:playbook-actions-scripts/script.interface
 */
class ScriptAction extends action_1.PlaybookActionWithSteps {
    /**
     * Execute JavaScript code in isolated VM context
     *
     * @param config - Script configuration
     * @returns Promise resolving to action result
     *
     * @req FR:playbook-actions-scripts/script.vm-execution
     * @req FR:playbook-actions-scripts/script.context-injection
     * @req FR:playbook-actions-scripts/script.error-handling
     * @req FR:playbook-actions-scripts/script.return-value
     * @req FR:playbook-actions-scripts/common.timeout
     * @req FR:playbook-actions-scripts/common.result-structure
     * @req FR:playbook-actions-scripts/security.script
     * @req NFR:playbook-actions-scripts/maintainability.single-responsibility
     * @req NFR:playbook-actions-scripts/performance.script-overhead
     * @req NFR:playbook-actions-scripts/reliability.memory-leaks
     */
    async execute(config) {
        try {
            // Validate configuration
            this.validateConfig(config);
            // Resolve working directory
            const cwd = this.resolveCwd(config.cwd);
            // Get timeout (with default)
            const timeout = config.timeout ?? DEFAULT_TIMEOUT;
            // Create get() function for variable access (via StepExecutor)
            const get = (key) => {
                return this.stepExecutor.getVariable(key);
            };
            // Create set() function for variable mutation (via StepExecutor)
            const set = (key, value) => {
                this.stepExecutor.setVariable(key, value);
            };
            // Create VM context with controlled injection
            const context = vm.createContext({
                console,
                get,
                set,
                fs,
                path,
                URL,
                URLSearchParams,
                Buffer,
                // Add working directory to context for reference
                __dirname: cwd,
                // Explicitly block dangerous globals
                require: undefined,
                import: undefined,
                process: undefined,
                global: undefined,
                __filename: undefined
            });
            // Wrap code in async function for await support
            const wrappedCode = `(async () => { ${config.code} })()`;
            // Compile script
            let script;
            try {
                script = new vm.Script(wrappedCode);
            }
            catch (err) {
                throw errors_1.ScriptErrors.syntaxError(err);
            }
            // Execute script with timeout
            let result;
            try {
                result = await script.runInContext(context, { timeout });
            }
            catch (err) {
                // Check if timeout error (VM throws Error with message containing 'timeout' or code ETIMEDOUT)
                if (err instanceof Error) {
                    const errorMessage = err.message.toLowerCase();
                    const errorCode = err.code;
                    if (errorMessage.includes('timeout') || errorCode === 'ETIMEDOUT' || errorMessage.includes('script execution timed out')) {
                        throw errors_1.ScriptErrors.timeout(timeout);
                    }
                }
                throw errors_1.ScriptErrors.runtimeError(err);
            }
            // Return success result
            return {
                code: 'Success',
                message: 'Script executed successfully',
                value: result,
                error: undefined
            };
        }
        catch (err) {
            // If it's already a CatalystError, return it
            if (err && typeof err === 'object' && 'code' in err && 'guidance' in err) {
                const catalystErr = err;
                return {
                    code: catalystErr.code,
                    message: catalystErr.message,
                    error: catalystErr
                };
            }
            // Otherwise, wrap in runtime error
            const runtimeError = errors_1.ScriptErrors.runtimeError(err);
            return {
                code: runtimeError.code,
                message: runtimeError.message,
                error: runtimeError
            };
        }
    }
    /**
     * Validate script configuration
     *
     * @param config - Script configuration to validate
     * @throws CatalystError if configuration is invalid
     *
     * @req FR:playbook-actions-scripts/common.validation
     */
    validateConfig(config) {
        if (!config.code) {
            throw errors_1.ScriptErrors.configInvalid('code property is required');
        }
        if (typeof config.code !== 'string') {
            throw errors_1.ScriptErrors.configInvalid('code must be a string');
        }
        if (config.timeout !== undefined && config.timeout < 0) {
            throw errors_1.ScriptErrors.configInvalid('timeout must be >= 0');
        }
    }
    /**
     * Resolve working directory to absolute path
     *
     * @param cwd - Working directory from config (optional)
     * @returns Absolute path to working directory
     * @throws CatalystError if directory does not exist
     *
     * @req FR:playbook-actions-scripts/common.working-directory
     */
    resolveCwd(cwd) {
        const repoRoot = process.cwd();
        // Default to repository root
        const resolvedCwd = cwd
            ? path.isAbsolute(cwd)
                ? cwd
                : path.join(repoRoot, cwd)
            : repoRoot;
        // Validate directory exists
        if (!fs.existsSync(resolvedCwd)) {
            throw errors_1.ScriptErrors.invalidCwd(resolvedCwd);
        }
        if (!fs.statSync(resolvedCwd).isDirectory()) {
            throw errors_1.ScriptErrors.invalidCwd(resolvedCwd);
        }
        return resolvedCwd;
    }
}
exports.ScriptAction = ScriptAction;
ScriptAction.actionType = 'script';
ScriptAction.primaryProperty = 'code';
//# sourceMappingURL=script-action.js.map
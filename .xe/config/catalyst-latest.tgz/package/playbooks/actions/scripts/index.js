"use strict";
/**
 * Script Execution Actions
 *
 * This module provides three script execution actions for Catalyst playbooks:
 *
 * - **script**: JavaScript execution in isolated VM context
 * - **bash**: Bash script execution (Unix/Linux/macOS)
 * - **powershell**: PowerShell script execution (cross-platform, requires pwsh)
 *
 * All actions support:
 * - Template interpolation ({{}} replacement before execution)
 * - Working directory configuration
 * - Timeout enforcement
 * - Comprehensive error handling with CatalystError codes
 *
 * @example
 * ```typescript
 * import { ScriptAction, BashAction, PowerShellAction } from './actions/scripts';
 *
 * // JavaScript execution
 * const scriptAction = new ScriptAction('/repo/root', { 'pr-number': 123 });
 * await scriptAction.execute({
 *   code: 'return get("pr-number") * 2;'
 * });
 *
 * // Bash execution
 * const bashAction = new BashAction('/repo/root');
 * await bashAction.execute({
 *   code: 'npm run build',
 *   env: { NODE_ENV: 'production' }
 * });
 *
 * // PowerShell execution
 * const pwshAction = new PowerShellAction('/repo/root');
 * await pwshAction.execute({
 *   code: 'npm test',
 *   env: { NODE_ENV: 'test' }
 * });
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PowerShellAction = exports.BashAction = exports.ScriptAction = exports.PowerShellErrorCodes = exports.BashErrorCodes = exports.ScriptErrorCodes = void 0;
// Export error codes
var errors_1 = require("./errors");
Object.defineProperty(exports, "ScriptErrorCodes", { enumerable: true, get: function () { return errors_1.ScriptErrorCodes; } });
Object.defineProperty(exports, "BashErrorCodes", { enumerable: true, get: function () { return errors_1.BashErrorCodes; } });
Object.defineProperty(exports, "PowerShellErrorCodes", { enumerable: true, get: function () { return errors_1.PowerShellErrorCodes; } });
// Export actions
var script_action_1 = require("./script-action");
Object.defineProperty(exports, "ScriptAction", { enumerable: true, get: function () { return script_action_1.ScriptAction; } });
var bash_action_1 = require("./bash-action");
Object.defineProperty(exports, "BashAction", { enumerable: true, get: function () { return bash_action_1.BashAction; } });
var powershell_action_1 = require("./powershell-action");
Object.defineProperty(exports, "PowerShellAction", { enumerable: true, get: function () { return powershell_action_1.PowerShellAction; } });
//# sourceMappingURL=index.js.map
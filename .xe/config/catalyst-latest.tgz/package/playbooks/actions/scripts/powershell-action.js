"use strict";
/**
 * PowerShell Action - PowerShell script execution
 *
 * Executes PowerShell scripts using child_process.exec() with pwsh shell.
 * Requires PowerShell 7+ (cross-platform).
 *
 * Template interpolation ({{variable-name}}) is handled by the template engine
 * BEFORE this action executes, so the config.code and config.env already have
 * variables replaced.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PowerShellAction = void 0;
const shell_action_base_1 = require("./shell-action-base");
const errors_1 = require("./errors");
/**
 * PowerShell script execution action
 *
 * Executes PowerShell scripts with environment variable support and proper
 * working directory management.
 *
 * @example
 * ```typescript
 * const action = new PowerShellAction();
 * const result = await action.execute({
 *   code: `
 *     $ErrorActionPreference = 'Stop'
 *     Write-Host "Running tests"
 *     npm test
 *   `,
 *   env: {
 *     NODE_ENV: 'test'
 *   },
 *   timeout: 60000
 * });
 * ```
 *
 * @req FR:playbook-actions-scripts/shell.powershell
 * @req FR:playbook-actions-scripts/shell.base-class
 * @req FR:playbook-actions-scripts/security.shell
 * @req NFR:playbook-actions-scripts/maintainability.shared-base
 */
class PowerShellAction extends shell_action_base_1.ShellActionBase {
    constructor() {
        super(...arguments);
        /**
         * External dependencies required by this action
         *
         * Requires PowerShell 7+ (pwsh), available cross-platform.
         */
        this.dependencies = {
            cli: [{
                    name: 'pwsh',
                    versionCommand: 'pwsh --version',
                    minVersion: '7.0.0',
                    installDocs: 'https://github.com/PowerShell/PowerShell#get-powershell'
                }]
        };
    }
    /**
     * Get the shell executable name
     *
     * @returns 'pwsh'
     */
    getShellExecutable() {
        return 'pwsh';
    }
    /**
     * Get error helper functions for PowerShell
     *
     * @returns PowerShell error helpers
     */
    getErrorHelpers() {
        return errors_1.PowerShellErrors;
    }
}
exports.PowerShellAction = PowerShellAction;
PowerShellAction.actionType = 'powershell';
/**
 * Primary property for YAML shorthand syntax
 *
 * Enables compact YAML syntax:
 * ```yaml
 * - powershell: Write-Host "hello"
 * ```
 * Instead of:
 * ```yaml
 * - powershell:
 *     code: Write-Host "hello"
 * ```
 */
PowerShellAction.primaryProperty = 'code';
//# sourceMappingURL=powershell-action.js.map
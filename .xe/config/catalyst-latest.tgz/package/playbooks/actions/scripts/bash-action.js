"use strict";
/**
 * Bash Action - Bash script execution
 *
 * Executes Bash scripts using child_process.exec() with bash shell.
 * Available on Unix/Linux/macOS systems.
 *
 * Template interpolation ({{variable-name}}) is handled by the template engine
 * BEFORE this action executes, so the config.code and config.env already have
 * variables replaced.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BashAction = void 0;
const shell_action_base_1 = require("./shell-action-base");
const errors_1 = require("./errors");
/**
 * Bash script execution action
 *
 * Executes Bash scripts with environment variable support and proper
 * working directory management.
 *
 * @example
 * ```typescript
 * const action = new BashAction();
 * const result = await action.execute({
 *   code: `
 *     set -e
 *     echo "Building project"
 *     npm run build
 *   `,
 *   env: {
 *     NODE_ENV: 'production'
 *   },
 *   timeout: 120000
 * });
 * ```
 *
 * @req FR:playbook-actions-scripts/shell.bash
 * @req FR:playbook-actions-scripts/shell.base-class
 * @req FR:playbook-actions-scripts/security.shell
 * @req NFR:playbook-actions-scripts/maintainability.shared-base
 */
class BashAction extends shell_action_base_1.ShellActionBase {
    constructor() {
        super(...arguments);
        /**
         * External dependencies required by this action
         *
         * Bash executable is required on Unix/Linux/macOS systems (native).
         * On Windows, bash is available via WSL (Windows Subsystem for Linux).
         */
        this.dependencies = {
            cli: [
                {
                    name: 'bash',
                    versionCommand: 'bash --version',
                    platforms: ['linux', 'darwin'],
                    installDocs: 'https://www.gnu.org/software/bash/'
                },
                {
                    name: 'bash',
                    versionCommand: 'bash --version',
                    platforms: ['win32'],
                    installDocs: 'https://docs.microsoft.com/windows/wsl/install'
                }
            ]
        };
    }
    /**
     * Get the shell executable name
     *
     * @returns 'bash'
     */
    getShellExecutable() {
        return 'bash';
    }
    /**
     * Get error helper functions for bash
     *
     * @returns Bash error helpers
     */
    getErrorHelpers() {
        return errors_1.BashErrors;
    }
}
exports.BashAction = BashAction;
BashAction.actionType = 'bash';
/**
 * Primary property for YAML shorthand syntax
 *
 * Enables compact YAML syntax:
 * ```yaml
 * - bash: echo "hello"
 * ```
 * Instead of:
 * ```yaml
 * - bash:
 *     code: echo "hello"
 * ```
 */
BashAction.primaryProperty = 'code';
//# sourceMappingURL=bash-action.js.map
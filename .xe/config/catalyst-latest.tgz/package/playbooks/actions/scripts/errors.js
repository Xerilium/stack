"use strict";
/**
 * Error codes and utilities for script execution actions
 *
 * This module defines error codes for the script, bash, and powershell actions,
 * along with helper functions for creating CatalystError instances with proper
 * guidance messages.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PowerShellErrors = exports.BashErrors = exports.ScriptErrors = exports.PowerShellErrorCodes = exports.BashErrorCodes = exports.ScriptErrorCodes = void 0;
const errors_1 = require("../../../core/errors");
/**
 * Error codes for script action (JavaScript execution)
 *
 * @req FR:playbook-actions-scripts/common.validation
 * @req FR:playbook-actions-scripts/script.error-handling
 * @req FR:playbook-actions-scripts/shell.error-mapping
 * @req NFR:playbook-actions-scripts/maintainability.error-codes
 * @req NFR:playbook-actions-scripts/reliability.error-messages
 */
exports.ScriptErrorCodes = {
    /**
     * Script configuration is invalid (missing code, invalid timeout, etc.)
     */
    ConfigInvalid: 'ScriptConfigInvalid',
    /**
     * Working directory does not exist
     */
    InvalidCwd: 'ScriptInvalidCwd',
    /**
     * JavaScript syntax error in provided code
     */
    SyntaxError: 'ScriptSyntaxError',
    /**
     * Runtime error occurred during script execution
     */
    RuntimeError: 'ScriptRuntimeError',
    /**
     * Script execution exceeded timeout limit
     */
    Timeout: 'ScriptTimeout'
};
/**
 * Error codes for bash action (Bash script execution)
 */
exports.BashErrorCodes = {
    /**
     * Bash configuration is invalid (missing code, invalid timeout, etc.)
     */
    ConfigInvalid: 'BashConfigInvalid',
    /**
     * Working directory does not exist
     */
    InvalidCwd: 'BashInvalidCwd',
    /**
     * Bash command not found (ENOENT error)
     */
    CommandNotFound: 'BashCommandNotFound',
    /**
     * Permission denied when executing bash command (EACCES error)
     */
    PermissionDenied: 'BashPermissionDenied',
    /**
     * Bash command failed with non-zero exit code
     */
    CommandFailed: 'BashCommandFailed',
    /**
     * Bash script execution exceeded timeout limit
     */
    Timeout: 'BashTimeout'
};
/**
 * Error codes for powershell action (PowerShell script execution)
 */
exports.PowerShellErrorCodes = {
    /**
     * PowerShell configuration is invalid (missing code, invalid timeout, etc.)
     */
    ConfigInvalid: 'PowerShellConfigInvalid',
    /**
     * Working directory does not exist
     */
    InvalidCwd: 'PowerShellInvalidCwd',
    /**
     * PowerShell command not found (ENOENT error)
     */
    CommandNotFound: 'PowerShellCommandNotFound',
    /**
     * Permission denied when executing PowerShell command (EACCES error)
     */
    PermissionDenied: 'PowerShellPermissionDenied',
    /**
     * PowerShell command failed with non-zero exit code
     */
    CommandFailed: 'PowerShellCommandFailed',
    /**
     * PowerShell script execution exceeded timeout limit
     */
    Timeout: 'PowerShellTimeout'
};
/**
 * Helper functions for creating script action errors
 */
exports.ScriptErrors = {
    /**
     * Create error for invalid script configuration
     */
    configInvalid: (reason) => new errors_1.CatalystError(`Invalid script configuration: ${reason}`, exports.ScriptErrorCodes.ConfigInvalid, `Ensure script config has valid 'code' property and timeout >= 0. ${reason}`),
    /**
     * Create error for invalid working directory
     */
    invalidCwd: (cwd) => new errors_1.CatalystError(`Working directory does not exist: ${cwd}`, exports.ScriptErrorCodes.InvalidCwd, `Ensure the working directory exists before executing the script. Path: ${cwd}`),
    /**
     * Create error for JavaScript syntax errors
     */
    syntaxError: (originalError) => new errors_1.CatalystError(`JavaScript syntax error in script code`, exports.ScriptErrorCodes.SyntaxError, `Fix the JavaScript syntax error in your script code. ${originalError.message}`, originalError),
    /**
     * Create error for JavaScript runtime errors
     */
    runtimeError: (originalError) => new errors_1.CatalystError(`Runtime error during script execution`, exports.ScriptErrorCodes.RuntimeError, `Review the error details and fix the runtime issue in your script. ${originalError.message}`, originalError),
    /**
     * Create error for script timeout
     */
    timeout: (timeoutMs) => new errors_1.CatalystError(`Script execution exceeded timeout of ${timeoutMs}ms`, exports.ScriptErrorCodes.Timeout, `Optimize your script or increase the timeout value. Current timeout: ${timeoutMs}ms`)
};
/**
 * Helper functions for creating bash action errors
 */
exports.BashErrors = {
    /**
     * Create error for invalid bash configuration
     */
    configInvalid: (reason) => new errors_1.CatalystError(`Invalid bash configuration: ${reason}`, exports.BashErrorCodes.ConfigInvalid, `Ensure bash config has valid 'code' property and timeout >= 0. ${reason}`),
    /**
     * Create error for invalid working directory
     */
    invalidCwd: (cwd) => new errors_1.CatalystError(`Working directory does not exist: ${cwd}`, exports.BashErrorCodes.InvalidCwd, `Ensure the working directory exists before executing the bash script. Path: ${cwd}`),
    /**
     * Create error when bash command is not found
     */
    commandNotFound: (stdout, stderr) => new errors_1.CatalystError(`Bash command not found`, exports.BashErrorCodes.CommandNotFound, `Ensure bash is installed and available in PATH. stdout: ${stdout}, stderr: ${stderr}`),
    /**
     * Create error when permission is denied
     */
    permissionDenied: (stdout, stderr) => new errors_1.CatalystError(`Permission denied when executing bash command`, exports.BashErrorCodes.PermissionDenied, `Check file permissions and execution rights. stdout: ${stdout}, stderr: ${stderr}`),
    /**
     * Create error when bash command fails with non-zero exit code
     */
    commandFailed: (exitCode, stdout, stderr) => new errors_1.CatalystError(`Bash command failed with exit code ${exitCode}`, exports.BashErrorCodes.CommandFailed, `Review the command output for errors. Exit code: ${exitCode}, stdout: ${stdout}, stderr: ${stderr}`),
    /**
     * Create error for bash timeout
     */
    timeout: (timeoutMs) => new errors_1.CatalystError(`Bash execution exceeded timeout of ${timeoutMs}ms`, exports.BashErrorCodes.Timeout, `Optimize your bash script or increase the timeout value. Current timeout: ${timeoutMs}ms`)
};
/**
 * Helper functions for creating PowerShell action errors
 */
exports.PowerShellErrors = {
    /**
     * Create error for invalid PowerShell configuration
     */
    configInvalid: (reason) => new errors_1.CatalystError(`Invalid PowerShell configuration: ${reason}`, exports.PowerShellErrorCodes.ConfigInvalid, `Ensure PowerShell config has valid 'code' property and timeout >= 0. ${reason}`),
    /**
     * Create error for invalid working directory
     */
    invalidCwd: (cwd) => new errors_1.CatalystError(`Working directory does not exist: ${cwd}`, exports.PowerShellErrorCodes.InvalidCwd, `Ensure the working directory exists before executing the PowerShell script. Path: ${cwd}`),
    /**
     * Create error when PowerShell command is not found
     */
    commandNotFound: (stdout, stderr) => new errors_1.CatalystError(`PowerShell command not found`, exports.PowerShellErrorCodes.CommandNotFound, `Ensure PowerShell (pwsh) is installed and available in PATH. stdout: ${stdout}, stderr: ${stderr}`),
    /**
     * Create error when permission is denied
     */
    permissionDenied: (stdout, stderr) => new errors_1.CatalystError(`Permission denied when executing PowerShell command`, exports.PowerShellErrorCodes.PermissionDenied, `Check file permissions and execution rights. stdout: ${stdout}, stderr: ${stderr}`),
    /**
     * Create error when PowerShell command fails with non-zero exit code
     */
    commandFailed: (exitCode, stdout, stderr) => new errors_1.CatalystError(`PowerShell command failed with exit code ${exitCode}`, exports.PowerShellErrorCodes.CommandFailed, `Review the command output for errors. Exit code: ${exitCode}, stdout: ${stdout}, stderr: ${stderr}`),
    /**
     * Create error for PowerShell timeout
     */
    timeout: (timeoutMs) => new errors_1.CatalystError(`PowerShell execution exceeded timeout of ${timeoutMs}ms`, exports.PowerShellErrorCodes.Timeout, `Optimize your PowerShell script or increase the timeout value. Current timeout: ${timeoutMs}ms`)
};
//# sourceMappingURL=errors.js.map
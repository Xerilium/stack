"use strict";
/**
 * Type definitions for script execution actions
 *
 * This module defines configuration interfaces and result types for the script execution actions:
 * - script: JavaScript execution in isolated VM context
 * - bash: Bash script execution via child_process
 * - powershell: PowerShell script execution via child_process
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
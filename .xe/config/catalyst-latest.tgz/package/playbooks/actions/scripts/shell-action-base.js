"use strict";
/**
 * Shell Action Base - Abstract base class for shell script execution
 *
 * Provides common functionality for bash and powershell actions:
 * - Configuration validation
 * - Working directory resolution
 * - Environment variable merging
 * - Shell command execution via child_process
 * - Timeout enforcement
 * - Error mapping to CatalystError codes
 *
 * Subclasses override getShellExecutable() and getErrorHelpers() to provide
 * shell-specific behavior.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShellActionBase = void 0;
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const logging_1 = require("../../../core/logging");
/**
 * Default timeout for shell execution (60 seconds)
 */
const DEFAULT_TIMEOUT = 60000;
/**
 * Abstract base class for shell script execution actions
 *
 * Provides all common functionality for bash and powershell actions.
 * Subclasses only need to override getShellExecutable() and getErrorHelpers().
 *
 * @req FR:playbook-actions-scripts/shell.base-class
 * @req FR:playbook-actions-scripts/shell.execution
 * @req FR:playbook-actions-scripts/shell.output-capture
 * @req FR:playbook-actions-scripts/shell.error-mapping
 * @req FR:playbook-actions-scripts/common.validation
 * @req FR:playbook-actions-scripts/common.working-directory
 * @req FR:playbook-actions-scripts/common.timeout
 * @req FR:playbook-actions-scripts/common.result-structure
 * @req NFR:playbook-actions-scripts/maintainability.single-responsibility
 * @req NFR:playbook-actions-scripts/maintainability.shared-base
 * @req NFR:playbook-actions-scripts/performance.shell-overhead
 * @req NFR:playbook-actions-scripts/performance.timeout-activation
 * @req NFR:playbook-actions-scripts/reliability.process-cleanup
 * @req NFR:playbook-actions-scripts/testability.timeout-testing
 */
class ShellActionBase {
    /**
     * Execute shell script
     *
     * @param config - Shell script configuration
     * @returns Promise resolving to action result
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        const shell = this.getShellExecutable();
        try {
            // Validate configuration
            this.validateConfig(config);
            // Resolve working directory
            const cwd = this.resolveCwd(config.cwd);
            logger.debug('ShellAction', 'Execute', `${shell} action executing`, { cwd, timeout: config.timeout ?? DEFAULT_TIMEOUT });
            logger.trace('ShellAction', 'Execute', `${shell} code`, { code: config.code.substring(0, 200) + (config.code.length > 200 ? '...' : '') });
            // Get timeout (with default)
            const timeout = config.timeout ?? DEFAULT_TIMEOUT;
            // Merge environment variables
            const env = {
                ...process.env,
                ...config.env
            };
            // Execute shell command
            const result = await this.executeShell(config.code, cwd, env, timeout);
            logger.verbose('ShellAction', 'Execute', `${shell} script completed`, { exitCode: result.exitCode });
            logger.trace('ShellAction', 'Execute', `${shell} output`, { stdout: result.stdout.substring(0, 500), stderr: result.stderr.substring(0, 500) });
            // Return success result
            return {
                code: 'Success',
                message: `${this.getShellExecutable()} script executed successfully`,
                value: result,
                error: undefined
            };
        }
        catch (err) {
            // If it's already a CatalystError, return it
            if (err && typeof err === 'object' && 'code' in err && 'guidance' in err) {
                const catalystErr = err;
                logger.debug('ShellAction', 'Execute', `${shell} script failed`, { code: catalystErr.code, message: catalystErr.message });
                return {
                    code: catalystErr.code,
                    message: catalystErr.message,
                    error: catalystErr
                };
            }
            // Otherwise, wrap in runtime error
            const helpers = this.getErrorHelpers();
            const runtimeError = helpers.commandFailed(1, '', err.message);
            logger.debug('ShellAction', 'Execute', `${shell} script runtime error`, { message: err.message });
            return {
                code: runtimeError.code,
                message: runtimeError.message,
                error: runtimeError
            };
        }
    }
    /**
     * Validate shell configuration
     *
     * @param config - Shell configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        const helpers = this.getErrorHelpers();
        if (!config.code) {
            throw helpers.configInvalid('code property is required');
        }
        if (typeof config.code !== 'string') {
            throw helpers.configInvalid('code must be a string');
        }
        if (config.timeout !== undefined && config.timeout < 0) {
            throw helpers.configInvalid('timeout must be >= 0');
        }
    }
    /**
     * Resolve working directory to absolute path
     *
     * @param cwd - Working directory from config (optional)
     * @returns Absolute path to working directory
     * @throws CatalystError if directory does not exist
     */
    resolveCwd(cwd) {
        const helpers = this.getErrorHelpers();
        const repoRoot = process.cwd();
        // Default to repository root
        const resolvedCwd = cwd
            ? path.isAbsolute(cwd)
                ? cwd
                : path.join(repoRoot, cwd)
            : repoRoot;
        // Validate directory exists
        if (!fs.existsSync(resolvedCwd)) {
            throw helpers.invalidCwd(resolvedCwd);
        }
        if (!fs.statSync(resolvedCwd).isDirectory()) {
            throw helpers.invalidCwd(resolvedCwd);
        }
        return resolvedCwd;
    }
    /**
     * Execute shell command and capture output
     *
     * @param code - Shell script code to execute
     * @param cwd - Working directory
     * @param env - Environment variables
     * @param timeout - Timeout in milliseconds
     * @returns Promise resolving to shell result
     * @throws CatalystError on execution failure
     */
    executeShell(code, cwd, env, timeout) {
        const helpers = this.getErrorHelpers();
        const shell = this.getShellExecutable();
        return new Promise((resolve, reject) => {
            const child = (0, child_process_1.exec)(code, {
                cwd,
                env,
                timeout,
                shell,
                maxBuffer: 10 * 1024 * 1024 // 10MB buffer for stdout/stderr
            }, (error, stdout, stderr) => {
                if (error) {
                    // Check error type
                    if (error.code === 'ENOENT') {
                        reject(helpers.commandNotFound(stdout, stderr));
                    }
                    else if (error.code === 'EACCES') {
                        reject(helpers.permissionDenied(stdout, stderr));
                    }
                    else if (error.killed || error.signal === 'SIGTERM') {
                        reject(helpers.timeout(timeout));
                    }
                    else if (error.code) {
                        // Non-zero exit code
                        const exitCode = error.code || 1;
                        reject(helpers.commandFailed(exitCode, stdout, stderr));
                    }
                    else {
                        // Unknown error
                        reject(helpers.commandFailed(1, stdout, stderr));
                    }
                }
                else {
                    // Success
                    resolve({
                        stdout,
                        stderr,
                        exitCode: 0
                    });
                }
            });
        });
    }
}
exports.ShellActionBase = ShellActionBase;
//# sourceMappingURL=shell-action-base.js.map
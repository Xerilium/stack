"use strict";
/**
 * PlaybookRunAction - Child playbook execution action
 *
 * Executes a registered playbook by name with optional input parameters.
 * Enables playbook composition - allowing playbooks to invoke other playbooks as steps.
 *
 * Child playbook execution is isolated - the child cannot modify parent context,
 * and inputs/outputs are explicitly mapped.
 *
 * This action extends PlaybookActionWithSteps to use StepExecutor for nested execution.
 * It loads playbooks via PlaybookProvider (zero coupling to playbook-yaml).
 *
 * @req FR:playbook-actions-controls/composition.playbook-action
 * @req FR:playbook-actions-controls/composition.playbook-action.base-class
 * @req FR:playbook-actions-controls/composition.playbook-action.loading
 * @req FR:playbook-actions-controls/composition.playbook-action.execution
 * @req FR:playbook-actions-controls/composition.playbook-action.circular-detection
 * @req FR:playbook-actions-controls/composition.playbook-action.recursion-limit
 * @req FR:playbook-actions-controls/composition.playbook-action.outputs
 * @req FR:playbook-actions-controls/composition.playbook-action.validation
 * @req FR:playbook-actions-controls/execution.nested-steps.call-stack
 * @req FR:playbook-actions-controls/metadata.primary-property
 *
 * @example
 * ```yaml
 * steps:
 *   # Shorthand syntax (primary property)
 *   - playbook: child-playbook-name
 *
 *   # Full syntax with input mapping
 *   - action: playbook
 *     config:
 *       name: deploy-service
 *       inputs:
 *         service-name: my-service
 *         environment: production
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaybookRunAction = void 0;
const types_1 = require("../../types");
const errors_1 = require("./errors");
const playbook_provider_1 = require("../../registry/playbook-provider");
const logging_1 = require("../../../core/logging");
class PlaybookRunAction extends types_1.PlaybookActionWithSteps {
    /**
     * Create a new PlaybookRunAction
     *
     * @param stepExecutor - Step executor for nested execution (from base class)
     * @param loadPlaybook - Optional playbook loader (defaults to PlaybookProvider)
     */
    constructor(stepExecutor, loadPlaybook) {
        super(stepExecutor);
        this.loadPlaybook =
            loadPlaybook ||
                ((name) => playbook_provider_1.PlaybookProvider.getInstance().load(name));
    }
    /**
     * Execute child playbook
     *
     * @param config - PlaybookRun configuration (already interpolated by Engine)
     * @returns Promise resolving to action result with child outputs
     * @throws CatalystError if playbook not found, circular reference, or exceeds depth
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        // Step 1: Validate configuration
        this.validateConfig(config);
        const { name, inputs = {} } = config;
        logger.debug("PlaybookRunAction", "Execute", "Executing playbook", {
            name,
            inputKeys: Object.keys(inputs),
        });
        // Step 2: Check for circular references
        const callStack = this.stepExecutor.getCallStack();
        if (callStack.includes(name)) {
            logger.debug("PlaybookRunAction", "Execute", "Circular reference detected", { name, callStack });
            throw errors_1.PlaybookRunErrors.circularReference([...callStack, name]);
        }
        // Step 3: Check recursion depth limit
        if (callStack.length >= PlaybookRunAction.MAX_RECURSION_DEPTH) {
            logger.debug("PlaybookRunAction", "Execute", "Max depth exceeded", {
                depth: callStack.length,
                max: PlaybookRunAction.MAX_RECURSION_DEPTH,
            });
            throw errors_1.PlaybookRunErrors.maxDepthExceeded(PlaybookRunAction.MAX_RECURSION_DEPTH);
        }
        logger.trace("PlaybookRunAction", "Execute", "Call stack", {
            callStack,
            depth: callStack.length,
        });
        // Step 4: Load child playbook
        const childPlaybook = await this.loadPlaybook(name);
        if (!childPlaybook) {
            try {
                const provider = playbook_provider_1.PlaybookProvider.getInstance();
                const loaders = provider.getProviderNames();
                logger.debug("PlaybookRunAction", "Execute", "Playbook not found", {
                    name,
                    loaders,
                });
                throw errors_1.PlaybookRunErrors.playbookNotFound(name, loaders);
            }
            catch (error) {
                // If provider access fails (e.g., in tests), provide empty loader list
                if (error.code === "PlaybookNotFound") {
                    throw error;
                }
                throw errors_1.PlaybookRunErrors.playbookNotFound(name, []);
            }
        }
        logger.verbose("PlaybookRunAction", "Execute", "Playbook loaded", {
            name,
            stepCount: childPlaybook.steps.length,
        });
        // Step 5: Execute child playbook steps using StepExecutor
        const results = await this.stepExecutor.executeSteps(childPlaybook.steps, inputs);
        // Step 6: Extract outputs from final step result
        const outputs = results.length > 0 ? results[results.length - 1].value : {};
        logger.verbose("PlaybookRunAction", "Execute", "Playbook completed", {
            name,
            executedSteps: results.length,
        });
        logger.trace("PlaybookRunAction", "Execute", "Playbook outputs", {
            outputs,
        });
        // Step 7: Return success result
        return {
            code: "Success",
            message: `Child playbook "${name}" completed successfully`,
            value: outputs,
            error: undefined,
        };
    }
    /**
     * Validate playbook action configuration
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        if (!config || typeof config !== "object") {
            throw errors_1.PlaybookRunErrors.configInvalid("config must be an object");
        }
        if (!config.name ||
            typeof config.name !== "string" ||
            config.name.trim() === "") {
            throw errors_1.PlaybookRunErrors.configInvalid("name property is required and must be a non-empty string");
        }
    }
}
exports.PlaybookRunAction = PlaybookRunAction;
/**
 * Action type identifier for registry
 */
PlaybookRunAction.actionType = "playbook";
/**
 * Primary property for YAML shorthand syntax
 * Enables: `playbook: child-playbook-name`
 */
PlaybookRunAction.primaryProperty = "name";
/**
 * Default isolation mode for nested step execution
 * Child playbooks are isolated by default for security - they cannot modify parent context
 */
PlaybookRunAction.isolated = true;
/**
 * Maximum recursion depth limit
 */
PlaybookRunAction.MAX_RECURSION_DEPTH = 10;
//# sourceMappingURL=playbook-run-action.js.map
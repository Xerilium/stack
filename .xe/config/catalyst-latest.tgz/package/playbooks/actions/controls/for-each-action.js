"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ForEachAction = void 0;
const action_1 = require("../../types/action");
const errors_1 = require("./errors");
const validation_1 = require("./validation");
const logging_1 = require("../../../core/logging");
/**
 * Array iteration action
 *
 * Iterates over array and executes steps for each item with scoped variables.
 * Provides `item` (or custom name) and `index` (or custom name) variables to nested steps.
 *
 * @example
 * ```typescript
 * const action = new ForEachAction(stepExecutor);
 * const result = await action.execute({
 *   in: [1, 2, 3],
 *   item: 'number',
 *   index: 'position',
 *   steps: [{ action: 'bash', config: { code: 'echo {{number}}' } }]
 * });
 * ```
 *
 * @req FR:playbook-actions-controls/iteration.for-each-action
 */
class ForEachAction extends action_1.PlaybookActionWithSteps {
    /**
     * Execute iteration logic
     *
     * @param config - ForEach action configuration
     * @returns Promise resolving to action result with iteration statistics
     *
     * @req FR:playbook-actions-controls/iteration.for-each-action.base-class
     * @req FR:playbook-actions-controls/iteration.for-each-action.iteration
     * @req FR:playbook-actions-controls/iteration.for-each-action.variable-scoping
     * @req FR:playbook-actions-controls/iteration.for-each-action.nesting
     * @req FR:playbook-actions-controls/iteration.for-each-action.result
     * @req NFR:playbook-actions-controls/reliability.variable-scoping
     * @req NFR:playbook-actions-controls/reliability.stack-overflow
     * @req NFR:playbook-actions-controls/reliability.resume
     * @req NFR:playbook-actions-controls/performance.loop-overhead
     * @req NFR:playbook-actions-controls/performance.overhead
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        // Step 1: Validate configuration
        this.validateConfig(config);
        // Step 2: Get array to iterate over
        const array = this.resolveArray(config.in);
        // Step 3: Get variable names (with defaults)
        const itemVarName = config.item ?? 'item';
        const indexVarName = config.index ?? 'index';
        logger.verbose('ForEachAction', 'Execute', 'Starting loop', { itemCount: array.length, itemVar: itemVarName, indexVar: indexVarName });
        // Step 4: Handle empty array case
        if (array.length === 0) {
            logger.verbose('ForEachAction', 'Execute', 'Empty array, no iterations');
            return {
                code: 'Success',
                message: 'No iterations (empty array)',
                value: {
                    iterations: 0,
                    completed: 0,
                    failed: 0
                }
            };
        }
        // Step 5: Iterate over array
        let completed = 0;
        let failed = 0;
        for (let i = 0; i < array.length; i++) {
            const item = array[i];
            logger.debug('ForEachAction', 'Execute', `Iteration ${i + 1}/${array.length}`, { [itemVarName]: item });
            // Create variable overrides for this iteration
            const variableOverrides = {
                [itemVarName]: item,
                [indexVarName]: i
            };
            try {
                // Execute steps with scoped variables
                await this.stepExecutor.executeSteps(config.steps, variableOverrides);
                completed++;
            }
            catch (err) {
                // Re-throw error to stop iteration (default fail-fast behavior)
                failed++;
                throw err;
            }
        }
        // Step 6: Return result
        const result = {
            iterations: array.length,
            completed,
            failed
        };
        logger.verbose('ForEachAction', 'Execute', 'Loop completed', { iterations: array.length, completed, failed });
        return {
            code: 'Success',
            message: `Completed ${completed} of ${array.length} iterations`,
            value: result
        };
    }
    /**
     * Validate for-each action configuration
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     *
     * @req FR:playbook-actions-controls/iteration.for-each-action.validation
     * @req FR:playbook-actions-controls/iteration.for-each-action.error-handling
     */
    validateConfig(config) {
        // Validate 'in' property exists
        if (config.in === undefined) {
            throw errors_1.ForEachErrors.configInvalid('in property is required');
        }
        // Validate steps exists and is valid
        if (!config.steps) {
            throw errors_1.ForEachErrors.configInvalid('steps property is required');
        }
        if (config.steps.length === 0) {
            throw errors_1.ForEachErrors.configInvalid('steps must contain at least one step');
        }
        (0, validation_1.validateStepArray)(config.steps, 'ForEach', 'steps');
    }
    /**
     * Resolve the array to iterate over
     *
     * @param value - Value from 'in' property
     * @returns Array to iterate over
     * @throws CatalystError if value is not an array
     *
     * @req FR:playbook-actions-controls/iteration.for-each-action.array-resolution
     */
    resolveArray(value) {
        // If it's already an array, return it
        if (Array.isArray(value)) {
            return value;
        }
        // Otherwise, it's invalid (string should have been template-interpolated to array)
        throw errors_1.ForEachErrors.invalidArray(value);
    }
}
exports.ForEachAction = ForEachAction;
/** @req FR:playbook-actions-controls/metadata.capabilities */
ForEachAction.actionType = 'for-each';
/**
 * Primary property for YAML shorthand syntax
 * Enables: `for-each: item` (with 'in' as secondary required property)
 * This makes the variable name explicit and reads naturally
 * @req FR:playbook-actions-controls/metadata.config-schemas
 */
ForEachAction.primaryProperty = 'item';
/**
 * Default isolation mode for nested step execution
 * For-each iterations share parent scope by default so variables propagate back
 * (Note: loop variables item/index are always scoped via variableOverrides)
 */
ForEachAction.isolated = false;
//# sourceMappingURL=for-each-action.js.map
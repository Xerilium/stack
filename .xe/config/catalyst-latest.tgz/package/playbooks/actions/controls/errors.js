"use strict";
/**
 * Error factory functions for control flow actions
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThrowErrors = exports.TryErrors = exports.PlaybookRunErrors = exports.ForEachErrors = exports.IfErrors = void 0;
const errors_1 = require("../../../core/errors");
/**
 * Error factories for IfAction
 *
 * @req FR:playbook-actions-controls/conditional.if-action.validation
 * @req NFR:playbook-actions-controls/maintainability.error-codes
 */
exports.IfErrors = {
    /**
     * Configuration validation error
     */
    configInvalid: (reason) => {
        return new errors_1.CatalystError(`Invalid if action configuration: ${reason}`, 'IfConfigInvalid', 'Check if action config: condition and then properties are required');
    },
    /**
     * Condition evaluation error
     */
    conditionEvaluationFailed: (condition, error) => {
        return new errors_1.CatalystError(`Failed to evaluate condition "${condition}": ${error.message}`, 'IfConditionEvaluationFailed', 'Check condition syntax - must be valid template expression');
    }
};
/**
 * Error factories for ForEachAction
 *
 * @req FR:playbook-actions-controls/iteration.for-each-action.validation
 * @req NFR:playbook-actions-controls/maintainability.error-codes
 */
exports.ForEachErrors = {
    /**
     * Configuration validation error
     */
    configInvalid: (reason) => {
        return new errors_1.CatalystError(`Invalid for-each action configuration: ${reason}`, 'ForEachConfigInvalid', 'Check for-each action config: in and steps properties are required');
    },
    /**
     * Invalid array error
     */
    invalidArray: (value) => {
        const type = Array.isArray(value) ? 'array' : typeof value;
        return new errors_1.CatalystError(`Invalid array for iteration: expected array, got ${type}`, 'ForEachInvalidArray', 'Ensure the "in" property resolves to an array');
    }
};
/**
 * Error factories for PlaybookRunAction
 *
 * @req FR:playbook-actions-controls/composition.playbook-action.validation
 * @req NFR:playbook-actions-controls/maintainability.error-codes
 */
exports.PlaybookRunErrors = {
    /**
     * Configuration validation error
     */
    configInvalid: (reason) => {
        return new errors_1.CatalystError(`Invalid playbook action configuration: ${reason}`, 'PlaybookRunConfigInvalid', 'Check playbook action config: name property is required');
    },
    /**
     * Playbook not found error
     */
    playbookNotFound: (name, registeredProviders) => {
        const providerList = registeredProviders.length > 0
            ? registeredProviders.join(', ')
            : 'none';
        return new errors_1.CatalystError(`Playbook "${name}" not found`, 'PlaybookNotFound', `Ensure playbook exists and is registered. Registered providers: ${providerList}`);
    },
    /**
     * Circular reference error
     */
    circularReference: (callStack) => {
        return new errors_1.CatalystError(`Circular playbook reference detected: ${callStack.join(' -> ')}`, 'CircularPlaybookReference', 'Refactor playbooks to avoid circular dependencies');
    },
    /**
     * Recursion depth exceeded error
     */
    maxDepthExceeded: (maxDepth) => {
        return new errors_1.CatalystError(`Maximum playbook recursion depth (${maxDepth}) exceeded`, 'MaxRecursionDepthExceeded', 'Refactor deeply nested playbook calls or increase MAX_RECURSION_DEPTH');
    }
};
/**
 * Error factories for TryAction
 *
 * @req FR:playbook-actions-controls/error-handling.try-action.validation
 * @req NFR:playbook-actions-controls/maintainability.error-codes
 */
exports.TryErrors = {
    /**
     * Configuration validation error
     */
    configInvalid: (reason) => {
        return new errors_1.CatalystError(`Invalid try action configuration: ${reason}`, 'TryConfigInvalid', 'Check try action config: steps property is required');
    }
};
/**
 * Error factories for ThrowAction
 *
 * @req FR:playbook-actions-controls/error-handling.throw-action.validation
 * @req NFR:playbook-actions-controls/maintainability.error-codes
 */
exports.ThrowErrors = {
    /**
     * Configuration validation error
     */
    configInvalid: (reason) => {
        return new errors_1.CatalystError(`Invalid throw action configuration: ${reason}`, 'ThrowConfigInvalid', 'Check throw action config: code property is required');
    }
};
//# sourceMappingURL=errors.js.map
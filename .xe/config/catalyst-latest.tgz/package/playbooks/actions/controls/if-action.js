"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IfAction = void 0;
const action_1 = require("../../types/action");
const errors_1 = require("./errors");
const validation_1 = require("./validation");
const logging_1 = require("../../../core/logging");
/**
 * Conditional execution action
 *
 * Evaluates condition and executes then/else branch based on result.
 * Condition is pre-interpolated by template engine before action executes.
 *
 * @example
 * ```typescript
 * const action = new IfAction(stepExecutor);
 * const result = await action.execute({
 *   condition: 'true',
 *   then: [{ action: 'bash', config: { code: 'echo "success"' } }],
 *   else: [{ action: 'bash', config: { code: 'echo "failure"' } }]
 * });
 * ```
 *
 * @req FR:playbook-actions-controls/conditional.if-action
 */
class IfAction extends action_1.PlaybookActionWithSteps {
    /**
     * Execute conditional logic
     *
     * @param config - If action configuration
     * @returns Promise resolving to action result with branch information
     *
     * @req FR:playbook-actions-controls/conditional.if-action.base-class
     * @req FR:playbook-actions-controls/conditional.if-action.branch-selection
     * @req FR:playbook-actions-controls/conditional.if-action.step-execution
     * @req FR:playbook-actions-controls/conditional.if-action.nesting
     * @req FR:playbook-actions-controls/conditional.if-action.result
     * @req FR:playbook-actions-controls/execution.nested-steps.base-class
     * @req FR:playbook-actions-controls/execution.nested-steps.mechanisms
     * @req FR:playbook-actions-controls/execution.nested-steps.state-management
     * @req FR:playbook-actions-controls/execution.nested-steps.error-policies
     * @req NFR:playbook-actions-controls/performance.variable-assignment
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        // Step 1: Validate configuration
        this.validateConfig(config);
        // Step 2: Evaluate condition (uses JavaScript truthy/falsy semantics)
        // Condition has already been template-interpolated by the engine
        const conditionResult = this.evaluateCondition(config.condition);
        logger.debug('IfAction', 'Execute', 'Condition evaluated', { condition: config.condition, result: conditionResult });
        // Step 3: Execute appropriate branch
        let branch;
        let executed = 0;
        if (conditionResult) {
            // Execute then branch
            logger.verbose('IfAction', 'Execute', 'Executing then branch', { stepCount: config.then.length });
            const results = await this.stepExecutor.executeSteps(config.then, undefined);
            branch = 'then';
            executed = results.length;
        }
        else if (config.else && config.else.length > 0) {
            // Execute else branch
            logger.verbose('IfAction', 'Execute', 'Executing else branch', { stepCount: config.else.length });
            const results = await this.stepExecutor.executeSteps(config.else, undefined);
            branch = 'else';
            executed = results.length;
        }
        else {
            // No else branch, condition was falsy
            logger.verbose('IfAction', 'Execute', 'Condition false, no else branch');
            branch = 'none';
            executed = 0;
        }
        // Step 4: Return result
        const result = {
            branch,
            executed
        };
        return {
            code: 'Success',
            message: `Executed ${branch} branch with ${executed} steps`,
            value: result
        };
    }
    /**
     * Validate if action configuration
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     *
     * @req FR:playbook-actions-controls/conditional.if-action.validation
     * @req FR:playbook-actions-controls/conditional.if-action.error-handling
     */
    validateConfig(config) {
        // Validate condition exists and is a string or boolean
        if (config.condition === undefined || config.condition === null) {
            throw errors_1.IfErrors.configInvalid('condition property is required');
        }
        const conditionType = typeof config.condition;
        if (conditionType !== 'string' && conditionType !== 'boolean' && conditionType !== 'number') {
            throw errors_1.IfErrors.configInvalid('condition must be a string, boolean, or number');
        }
        // For string conditions, ensure non-empty
        if (conditionType === 'string' && config.condition.trim() === '') {
            throw errors_1.IfErrors.configInvalid('condition must be a non-empty string');
        }
        // Validate then branch exists and is valid
        if (!config.then) {
            throw errors_1.IfErrors.configInvalid('then property is required');
        }
        (0, validation_1.validateStepArray)(config.then, 'If', 'then');
        // Validate else branch if provided
        if (config.else !== undefined) {
            if (!Array.isArray(config.else)) {
                throw errors_1.IfErrors.configInvalid('else property must be an array');
            }
            if (config.else.length > 0) {
                (0, validation_1.validateStepArray)(config.else, 'If', 'else');
            }
        }
    }
    /**
     * Evaluate condition using JavaScript truthy/falsy semantics
     *
     * The condition has already been template-interpolated by the engine,
     * so we just need to evaluate it as a boolean. Handles boolean, number,
     * and string values (from pure expressions like get('boolVar')).
     *
     * @param condition - Condition value (boolean, number, or string, already interpolated)
     * @returns true if condition is truthy, false otherwise
     *
     * @req FR:playbook-actions-controls/conditional.if-action.evaluation
     * @req NFR:playbook-actions-controls/performance.condition-eval
     */
    evaluateCondition(condition) {
        // If already a boolean, return directly
        if (typeof condition === 'boolean') {
            return condition;
        }
        // For numbers, use JavaScript truthy semantics (0 is falsy, everything else truthy)
        if (typeof condition === 'number') {
            return condition !== 0;
        }
        // Handle special string values that represent boolean false
        const trimmed = condition.trim().toLowerCase();
        // Explicitly falsy string values (note: "0" is NOT falsy per JavaScript string semantics)
        if (trimmed === '' || trimmed === 'false' || trimmed === 'null' || trimmed === 'undefined') {
            return false;
        }
        // Everything else is truthy (including "0")
        return true;
    }
}
exports.IfAction = IfAction;
/** @req FR:playbook-actions-controls/metadata.primary-property */
IfAction.actionType = 'if';
/**
 * Primary property for YAML shorthand syntax
 * Enables: `if: "${{ condition }}"`
 * @req FR:playbook-actions-controls/metadata.primary-property
 */
IfAction.primaryProperty = 'condition';
/**
 * Default isolation mode for nested step execution
 * If/else branches share parent scope by default so variables propagate back
 */
IfAction.isolated = false;
//# sourceMappingURL=if-action.js.map
"use strict";
/**
 * GitHub issue create action
 * @module playbooks/actions/git/issue-create-action
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubIssueCreateAction = void 0;
// @req FR:playbook-actions-git/issues.create
// @req FR:playbook-actions-git/common.validation
// @req FR:playbook-actions-git/common.result-structure
const base_1 = require("./base");
const errors_1 = require("../../../core/errors");
/**
 * Action to create a new GitHub issue
 */
class GitHubIssueCreateAction extends base_1.GitHubActionBase {
    validateConfig(config) {
        if (!config.title || config.title.trim() === '') {
            throw new errors_1.CatalystError('Issue title is required and cannot be empty', 'GitHubIssueCreateConfigInvalid', 'Provide a non-empty title for the GitHub issue');
        }
    }
    async executeGitHubOperation(config) {
        const repoFlag = await this.getRepoFlag(config.repository);
        let command = `gh issue create ${repoFlag} --title ${this.escapeShellArg(config.title)}`;
        if (config.body) {
            command += ` --body ${this.escapeShellArg(config.body)}`;
        }
        if (config.labels && config.labels.length > 0) {
            command += ` --label ${config.labels.map((l) => this.escapeShellArg(l)).join(',')}`;
        }
        if (config.assignees && config.assignees.length > 0) {
            command += ` --assignee ${config.assignees.join(',')}`;
        }
        // gh issue create outputs only the issue URL; use gh issue view to get structured data
        const issueUrl = this.executeCommand(command);
        const issueNumber = this.extractNumberFromUrl(issueUrl);
        const viewCommand = `gh issue view ${issueNumber} ${repoFlag} --json number,url,title,body,state,labels,assignees`;
        const output = this.executeCommand(viewCommand);
        const rawData = this.parseJSON(output);
        return {
            number: rawData.number,
            url: rawData.url || rawData.html_url,
            title: rawData.title,
            body: rawData.body,
            state: rawData.state.toLowerCase(),
            labels: rawData.labels?.map((l) => l.name) || [],
            assignees: rawData.assignees?.map((a) => a.login) || [],
        };
    }
    getSuccessMessage(data) {
        return `Created issue #${data.number}: ${data.title}`;
    }
    formatResultValue(data) {
        return {
            number: data.number,
            url: data.url,
            title: data.title,
            state: data.state,
        };
    }
}
exports.GitHubIssueCreateAction = GitHubIssueCreateAction;
GitHubIssueCreateAction.actionType = 'github-issue-create';
GitHubIssueCreateAction.primaryProperty = 'title';
//# sourceMappingURL=issue-create-action.js.map
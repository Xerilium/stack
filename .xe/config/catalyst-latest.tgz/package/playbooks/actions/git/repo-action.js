"use strict";
/**
 * GitHub repository info action
 * @module playbooks/actions/git/repo-action
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubRepoAction = void 0;
// @req FR:playbook-actions-git/repository.info
// @req FR:playbook-actions-git/common.result-structure
const base_1 = require("./base");
/**
 * Action to get GitHub repository information
 */
class GitHubRepoAction extends base_1.GitHubActionBase {
    validateConfig(_config) {
        // No required fields - repository is optional (defaults to current repository)
        // Validation passes automatically
    }
    async executeGitHubOperation(config) {
        // gh repo view takes repository as a positional argument, not -R flag
        const repo = config.repository || await this.getCurrentRepository();
        const command = `gh repo view ${this.escapeShellArg(repo)} --json name,owner,defaultBranchRef,visibility,url`;
        const output = this.executeCommand(command);
        const rawData = this.parseJSON(output);
        return {
            name: rawData.name,
            owner: rawData.owner?.login || rawData.owner,
            defaultBranch: rawData.defaultBranchRef?.name || rawData.defaultBranch || 'main',
            visibility: (rawData.visibility || 'public').toLowerCase(),
            url: rawData.url,
        };
    }
    getSuccessMessage(data) {
        return `Retrieved info for ${data.owner}/${data.name}`;
    }
    formatResultValue(data) {
        return {
            name: data.name,
            owner: data.owner,
            defaultBranch: data.defaultBranch,
            visibility: data.visibility,
            url: data.url,
        };
    }
}
exports.GitHubRepoAction = GitHubRepoAction;
GitHubRepoAction.actionType = 'github-repo';
GitHubRepoAction.primaryProperty = 'repository';
//# sourceMappingURL=repo-action.js.map
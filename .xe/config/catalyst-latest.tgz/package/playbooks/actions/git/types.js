"use strict";
/**
 * Type definitions for GitHub resources and configurations
 * @module playbooks/actions/git/types
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
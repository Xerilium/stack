"use strict";
/**
 * GitHub pull request create action
 * @module playbooks/actions/git/pr-create-action
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubPRCreateAction = void 0;
// @req FR:playbook-actions-git/pull-requests.create
// @req FR:playbook-actions-git/common.validation
// @req FR:playbook-actions-git/common.result-structure
const base_1 = require("./base");
const errors_1 = require("../../../core/errors");
/**
 * Action to create a new GitHub pull request
 */
class GitHubPRCreateAction extends base_1.GitHubActionBase {
    validateConfig(config) {
        if (!config.title || config.title.trim() === '') {
            throw new errors_1.CatalystError('PR title is required and cannot be empty', 'GitHubPRCreateConfigInvalid', 'Provide a non-empty title for the pull request');
        }
        if (!config.head || config.head.trim() === '') {
            throw new errors_1.CatalystError('Head branch is required and cannot be empty', 'GitHubPRCreateConfigInvalid', 'Provide the source branch name (head)');
        }
        if (!config.base || config.base.trim() === '') {
            throw new errors_1.CatalystError('Base branch is required and cannot be empty', 'GitHubPRCreateConfigInvalid', 'Provide the target branch name (base)');
        }
    }
    async executeGitHubOperation(config) {
        const repoFlag = await this.getRepoFlag(config.repository);
        let command = `gh pr create ${repoFlag} --title ${this.escapeShellArg(config.title)} --head ${this.escapeShellArg(config.head)} --base ${this.escapeShellArg(config.base)}`;
        if (config.body) {
            command += ` --body ${this.escapeShellArg(config.body)}`;
        }
        if (config.draft) {
            command += ' --draft';
        }
        // gh pr create outputs only the PR URL; use gh pr view to get structured data
        const prUrl = this.executeCommand(command);
        const prNumber = this.extractNumberFromUrl(prUrl);
        const viewCommand = `gh pr view ${prNumber} ${repoFlag} --json number,url,title,body,state,headRefName,baseRefName,isDraft`;
        const output = this.executeCommand(viewCommand);
        const rawData = this.parseJSON(output);
        return {
            number: rawData.number,
            url: rawData.url || rawData.html_url,
            title: rawData.title,
            body: rawData.body,
            state: rawData.state.toLowerCase(),
            head: rawData.headRefName || rawData.head?.ref || config.head,
            base: rawData.baseRefName || rawData.base?.ref || config.base,
            draft: rawData.isDraft ?? rawData.draft,
        };
    }
    getSuccessMessage(data) {
        return `Created PR #${data.number}: ${data.title}`;
    }
    formatResultValue(data) {
        return {
            number: data.number,
            url: data.url,
            title: data.title,
            state: data.state,
            head: data.head,
            base: data.base,
        };
    }
}
exports.GitHubPRCreateAction = GitHubPRCreateAction;
GitHubPRCreateAction.actionType = 'github-pr-create';
GitHubPRCreateAction.primaryProperty = 'title';
//# sourceMappingURL=pr-create-action.js.map
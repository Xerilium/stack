"use strict";
/**
 * GitHub pull request comment action
 * @module playbooks/actions/git/pr-comment-action
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubPRCommentAction = void 0;
// @req FR:playbook-actions-git/pull-requests.comment
// @req FR:playbook-actions-git/common.validation
// @req FR:playbook-actions-git/common.result-structure
const base_1 = require("./base");
const errors_1 = require("../../../core/errors");
/**
 * Action to add a comment to an existing GitHub pull request
 */
class GitHubPRCommentAction extends base_1.GitHubActionBase {
    validateConfig(config) {
        if (!config.pr || typeof config.pr !== 'number' || config.pr <= 0) {
            throw new errors_1.CatalystError('PR number is required and must be a positive integer', 'GitHubPRCommentConfigInvalid', 'Provide a valid pull request number');
        }
        if (!config.body || config.body.trim() === '') {
            throw new errors_1.CatalystError('Comment body is required and cannot be empty', 'GitHubPRCommentConfigInvalid', 'Provide a non-empty comment body');
        }
    }
    async executeGitHubOperation(config) {
        const repoFlag = await this.getRepoFlag(config.repository);
        const command = `gh pr comment ${config.pr} ${repoFlag} --body ${this.escapeShellArg(config.body)}`;
        // gh pr comment outputs only the comment URL; use gh api to get structured data
        const commentUrl = this.executeCommand(command);
        const { commentId, repoOwner, repoName } = this.extractCommentIdFromUrl(commentUrl);
        const apiCommand = `gh api repos/${repoOwner}/${repoName}/issues/comments/${commentId}`;
        const output = this.executeCommand(apiCommand);
        const rawData = this.parseJSON(output);
        return {
            id: rawData.id,
            url: rawData.html_url || rawData.url,
            body: rawData.body,
            createdAt: rawData.created_at || rawData.createdAt,
        };
    }
    getSuccessMessage(_data) {
        return `Added comment to PR`;
    }
    formatResultValue(data) {
        return {
            id: data.id,
            url: data.url,
        };
    }
    // Override execute to provide better success message with PR number
    async execute(config) {
        const result = await super.execute(config);
        if (result.code === 'Success') {
            result.message = `Added comment to PR #${config.pr}`;
        }
        return result;
    }
}
exports.GitHubPRCommentAction = GitHubPRCommentAction;
GitHubPRCommentAction.actionType = 'github-pr-comment';
GitHubPRCommentAction.primaryProperty = 'pr';
//# sourceMappingURL=pr-comment-action.js.map
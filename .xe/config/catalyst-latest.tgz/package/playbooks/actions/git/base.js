"use strict";
/**
 * Base class for GitHub playbook actions
 * @module playbooks/actions/git/base
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubActionBase = void 0;
// @req FR:playbook-actions-git/common.validation
// @req FR:playbook-actions-git/common.result-structure
// @req FR:playbook-actions-git/errors.graceful-failure
// @req FR:playbook-actions-git/errors.access-validation
// @req NFR:playbook-actions-git/performance.validation-speed
// @req NFR:playbook-actions-git/performance.timeouts
// @req NFR:playbook-actions-git/performance.operation-speed
// @req NFR:playbook-actions-git/security.input-validation
// @req NFR:playbook-actions-git/security.no-token-logging
// @req NFR:playbook-actions-git/security.no-sensitive-errors
// @req NFR:playbook-actions-git/reliability.resource-cleanup
// @req NFR:playbook-actions-git/reliability.no-token-leakage
const child_process_1 = require("child_process");
const errors_1 = require("./errors");
const errors_2 = require("../../../core/errors");
const logging_1 = require("../../../core/logging");
/**
 * Default command execution timeout (5 seconds)
 */
const DEFAULT_TIMEOUT = 15000;
/**
 * Abstract base class for all GitHub actions
 * Provides GitHub CLI execution and error handling
 */
class GitHubActionBase {
    /**
     * Execute the GitHub action
     * Orchestrates: validation → operation → error mapping → result formatting
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        const actionName = this.getActionName();
        try {
            // Step 1: Validate configuration
            this.validateConfig(config);
            logger.debug('GitHubAction', 'Execute', `${actionName} executing`, { config: JSON.stringify(config) });
            // Step 2: Execute GitHub operation
            const data = await this.executeGitHubOperation(config);
            // Step 3: Format success response
            const successMessage = this.getSuccessMessage(data);
            const resultValue = this.formatResultValue(data);
            logger.verbose('GitHubAction', 'Execute', `${actionName} completed`, { message: successMessage });
            logger.trace('GitHubAction', 'Execute', `${actionName} result`, { value: resultValue });
            return {
                code: 'Success',
                message: successMessage,
                value: resultValue,
            };
        }
        catch (error) {
            // Handle validation errors
            if (error instanceof errors_2.CatalystError) {
                logger.debug('GitHubAction', 'Execute', `${actionName} validation failed`, { code: error.code, message: error.message });
                return {
                    code: error.code,
                    error,
                };
            }
            // Handle GitHub errors
            if (error instanceof errors_1.GitHubError) {
                logger.debug('GitHubAction', 'Execute', `${actionName} failed`, { errorCode: error.code, message: error.message });
                return {
                    code: this.mapErrorCode(error),
                    error: this.mapError(error),
                };
            }
            // Unexpected error
            logger.debug('GitHubAction', 'Execute', `${actionName} unexpected error`, { error: error.message || String(error) });
            return {
                code: this.getActionName() + 'Failed',
                error: new errors_2.CatalystError(`Unexpected error: ${error.message || String(error)}`, this.getActionName() + 'Failed', 'Check the error details and try again'),
            };
        }
    }
    /**
     * Execute a GitHub CLI command
     */
    executeCommand(command) {
        const logger = logging_1.LogManager.framework();
        logger.trace('GitHubAction', 'ExecuteCommand', 'Executing CLI command', { command: command.substring(0, 100) });
        try {
            const output = (0, child_process_1.execSync)(command, {
                encoding: 'utf-8',
                timeout: DEFAULT_TIMEOUT,
                stdio: ['pipe', 'pipe', 'pipe'],
            });
            logger.trace('GitHubAction', 'ExecuteCommand', 'CLI completed', { outputLength: output.length });
            return output.trim();
        }
        catch (error) {
            logger.trace('GitHubAction', 'ExecuteCommand', 'CLI failed', { error: error.message });
            throw this.mapExecutionError(error);
        }
    }
    /**
     * Map execution errors to GitHubError types
     */
    mapExecutionError(error) {
        const message = error.message || String(error);
        // Authentication errors
        if (message.includes('Not logged in') ||
            message.includes('not logged in') ||
            message.includes('auth login')) {
            return new errors_1.GitHubAuthError('GitHub authentication required', 'Run: gh auth login', error);
        }
        // Not found errors
        if (message.includes('not found') ||
            message.includes('could not resolve') ||
            message.includes('Not Found')) {
            return new errors_1.GitHubNotFoundError('GitHub resource not found', 'Check that the repository, issue, or PR exists', error);
        }
        // Permission errors
        if (message.includes('permission') ||
            message.includes('not accessible') ||
            message.includes('Forbidden')) {
            return new errors_1.GitHubPermissionError('Insufficient permissions for GitHub operation', 'Check your access token scopes and repository permissions', error);
        }
        // Rate limit errors
        if (message.includes('rate limit') || message.includes('API rate limit')) {
            return new errors_1.GitHubRateLimitError('GitHub API rate limit exceeded', 'Wait before retrying or use a different authentication token', error);
        }
        // Timeout errors
        if (error.code === 'ETIMEDOUT' || message.includes('timed out')) {
            return new errors_1.GitHubNetworkError('GitHub CLI command timed out', 'Check your network connection and try again', error);
        }
        // Generic network/execution errors
        return new errors_1.GitHubNetworkError(`GitHub CLI command failed: ${message}`, 'Check your network connection and GitHub CLI installation', error);
    }
    /**
     * Parse JSON response from GitHub CLI
     */
    parseJSON(output) {
        try {
            return JSON.parse(output);
        }
        catch (error) {
            throw new errors_1.GitHubError('json_parse_error', 'Failed to parse JSON response from GitHub CLI', 'This may indicate an issue with the GitHub CLI installation', error);
        }
    }
    /**
     * Get the current repository context (cached)
     */
    async getCurrentRepository() {
        if (this.repositoryCache) {
            return this.repositoryCache;
        }
        const output = this.executeCommand('gh repo view --json nameWithOwner');
        const data = this.parseJSON(output);
        this.repositoryCache = data.nameWithOwner;
        return this.repositoryCache;
    }
    /**
     * Extract issue/PR number from a GitHub URL returned by `gh create` commands.
     *
     * Only accepts URLs matching the expected GitHub pattern
     * (e.g. https://github.com/owner/repo/issues/42 or /pull/7).
     * Rejects arbitrary strings to avoid misinterpreting unexpected output.
     */
    extractNumberFromUrl(url) {
        const match = url
            .trim()
            .match(/^https:\/\/github\.com\/[^/]+\/[^/]+\/(?:issues|pull)\/(\d+)$/);
        if (!match) {
            throw new errors_1.GitHubError('parse_error', `Unexpected output from GitHub CLI (expected an issue/PR URL): ${url}`, 'This may indicate a change in GitHub CLI output format');
        }
        return parseInt(match[1], 10);
    }
    /**
     * Extract comment ID from a GitHub comment URL returned by `gh comment` commands.
     *
     * Only accepts URLs matching the expected GitHub comment pattern
     * (e.g. https://github.com/owner/repo/issues/18#issuecomment-4109518383).
     * Rejects arbitrary strings to avoid misinterpreting unexpected output.
     */
    extractCommentIdFromUrl(url) {
        const match = url
            .trim()
            .match(/^https:\/\/github\.com\/([^/]+)\/([^/]+)\/(?:issues|pull)\/\d+#issuecomment-(\d+)$/);
        if (!match) {
            throw new errors_1.GitHubError('parse_error', `Unexpected output from GitHub CLI (expected a comment URL): ${url}`, 'This may indicate a change in GitHub CLI output format');
        }
        return {
            repoOwner: match[1],
            repoName: match[2],
            commentId: parseInt(match[3], 10),
        };
    }
    /**
     * Escape shell arguments for safe command execution
     */
    escapeShellArg(arg) {
        // Replace single quotes with '\'' and wrap in single quotes
        return `'${arg.replace(/'/g, "'\\''")}'`;
    }
    /**
     * Build repository flag for commands
     */
    async getRepoFlag(repository) {
        if (repository) {
            return `-R ${this.escapeShellArg(repository)}`;
        }
        // Use current repository context
        const repo = await this.getCurrentRepository();
        return `-R ${this.escapeShellArg(repo)}`;
    }
    /**
     * Get the action name for error code prefixing
     * Default implementation extracts from class name (e.g., "GitHubIssueCreateAction" → "GitHubIssueCreate")
     */
    getActionName() {
        const className = this.constructor.name;
        // Remove "Action" suffix if present
        return className.endsWith('Action') ? className.slice(0, -6) : className;
    }
    /**
     * Format result value for PlaybookActionResult
     * Default implementation returns data as-is, but subclasses can override
     */
    formatResultValue(data) {
        return data;
    }
    /**
     * Map GitHubError to action-specific error code
     */
    mapErrorCode(error) {
        const actionName = this.getActionName();
        if (error instanceof errors_1.GitHubAuthError) {
            return actionName + 'AuthenticationFailed';
        }
        else if (error instanceof errors_1.GitHubNotFoundError) {
            return actionName + 'NotFound';
        }
        else if (error instanceof errors_1.GitHubPermissionError) {
            return actionName + 'PermissionDenied';
        }
        else if (error instanceof errors_1.GitHubRateLimitError) {
            return actionName + 'RateLimitExceeded';
        }
        else if (error instanceof errors_1.GitHubNetworkError) {
            return actionName + 'NetworkError';
        }
        else {
            return actionName + 'Failed';
        }
    }
    /**
     * Map GitHubError to CatalystError with preserved guidance
     */
    mapError(error) {
        const code = this.mapErrorCode(error);
        return new errors_2.CatalystError(error.message, code, error.guidance || 'Check the error details and try again', error);
    }
}
exports.GitHubActionBase = GitHubActionBase;
//# sourceMappingURL=base.js.map
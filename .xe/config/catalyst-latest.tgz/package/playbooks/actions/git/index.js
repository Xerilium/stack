"use strict";
/**
 * Git & GitHub Playbook Actions
 *
 * This module provides playbook actions for local git state management
 * (gitignore-edit) and remote GitHub operations (issues, pull requests,
 * repositories).
 *
 * @module playbooks/actions/git
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubActionBase = exports.GitHubNetworkError = exports.GitHubRateLimitError = exports.GitHubPermissionError = exports.GitHubNotFoundError = exports.GitHubAuthError = exports.GitHubError = exports.GitignoreEditAction = exports.GitHubRepoAction = exports.GitHubPRCommentAction = exports.GitHubPRCreateAction = exports.GitHubIssueCommentAction = exports.GitHubIssueCreateAction = void 0;
// @req FR:playbook-actions-git/issues.create
// @req FR:playbook-actions-git/issues.comment
// @req FR:playbook-actions-git/pull-requests.create
// @req FR:playbook-actions-git/pull-requests.comment
// @req FR:playbook-actions-git/repository.info
// @req FR:playbook-actions-git/gitignore-edit.@action
/**
 * Action Classes
 */
var issue_create_action_1 = require("./issue-create-action");
Object.defineProperty(exports, "GitHubIssueCreateAction", { enumerable: true, get: function () { return issue_create_action_1.GitHubIssueCreateAction; } });
var issue_comment_action_1 = require("./issue-comment-action");
Object.defineProperty(exports, "GitHubIssueCommentAction", { enumerable: true, get: function () { return issue_comment_action_1.GitHubIssueCommentAction; } });
var pr_create_action_1 = require("./pr-create-action");
Object.defineProperty(exports, "GitHubPRCreateAction", { enumerable: true, get: function () { return pr_create_action_1.GitHubPRCreateAction; } });
var pr_comment_action_1 = require("./pr-comment-action");
Object.defineProperty(exports, "GitHubPRCommentAction", { enumerable: true, get: function () { return pr_comment_action_1.GitHubPRCommentAction; } });
var repo_action_1 = require("./repo-action");
Object.defineProperty(exports, "GitHubRepoAction", { enumerable: true, get: function () { return repo_action_1.GitHubRepoAction; } });
var gitignore_edit_action_1 = require("./gitignore-edit-action");
Object.defineProperty(exports, "GitignoreEditAction", { enumerable: true, get: function () { return gitignore_edit_action_1.GitignoreEditAction; } });
/**
 * Error Classes
 */
var errors_1 = require("./errors");
Object.defineProperty(exports, "GitHubError", { enumerable: true, get: function () { return errors_1.GitHubError; } });
Object.defineProperty(exports, "GitHubAuthError", { enumerable: true, get: function () { return errors_1.GitHubAuthError; } });
Object.defineProperty(exports, "GitHubNotFoundError", { enumerable: true, get: function () { return errors_1.GitHubNotFoundError; } });
Object.defineProperty(exports, "GitHubPermissionError", { enumerable: true, get: function () { return errors_1.GitHubPermissionError; } });
Object.defineProperty(exports, "GitHubRateLimitError", { enumerable: true, get: function () { return errors_1.GitHubRateLimitError; } });
Object.defineProperty(exports, "GitHubNetworkError", { enumerable: true, get: function () { return errors_1.GitHubNetworkError; } });
/**
 * Base Class (for extensibility)
 */
var base_1 = require("./base");
Object.defineProperty(exports, "GitHubActionBase", { enumerable: true, get: function () { return base_1.GitHubActionBase; } });
//# sourceMappingURL=index.js.map
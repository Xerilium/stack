"use strict";
/**
 * GitHub error hierarchy for structured error handling
 * @module playbooks/actions/git/errors
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubNetworkError = exports.GitHubRateLimitError = exports.GitHubPermissionError = exports.GitHubNotFoundError = exports.GitHubAuthError = exports.GitHubError = void 0;
// @req FR:playbook-actions-git/errors.graceful-failure
// @req FR:playbook-actions-git/errors.actionable-messages
// @req NFR:playbook-actions-git/reliability.actionable-errors
/**
 * Base error class for all GitHub-related errors
 */
class GitHubError extends Error {
    constructor(code, message, guidance, cause) {
        super(message);
        this.name = 'GitHubError';
        this.code = code;
        this.guidance = guidance;
        this.cause = cause;
        // Maintain proper prototype chain for instanceof checks
        Object.setPrototypeOf(this, GitHubError.prototype);
        // Preserve stack trace
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, this.constructor);
        }
    }
    /**
     * Serialize error for logging or transmission
     */
    toJSON() {
        return {
            name: this.name,
            code: this.code,
            message: this.message,
            guidance: this.guidance,
            stack: this.stack,
            cause: this.cause
                ? {
                    message: this.cause.message,
                    stack: this.cause.stack,
                }
                : undefined,
        };
    }
}
exports.GitHubError = GitHubError;
/**
 * Authentication error - user is not authenticated with GitHub
 */
class GitHubAuthError extends GitHubError {
    constructor(message, guidance, cause) {
        super('auth_required', message, guidance, cause);
        this.name = 'GitHubAuthError';
        Object.setPrototypeOf(this, GitHubAuthError.prototype);
    }
}
exports.GitHubAuthError = GitHubAuthError;
/**
 * Not found error - resource (repository, issue, PR) does not exist
 */
class GitHubNotFoundError extends GitHubError {
    constructor(message, guidance, cause) {
        super('not_found', message, guidance, cause);
        this.name = 'GitHubNotFoundError';
        Object.setPrototypeOf(this, GitHubNotFoundError.prototype);
    }
}
exports.GitHubNotFoundError = GitHubNotFoundError;
/**
 * Permission error - user lacks permissions for the operation
 */
class GitHubPermissionError extends GitHubError {
    constructor(message, guidance, cause) {
        super('permission_denied', message, guidance, cause);
        this.name = 'GitHubPermissionError';
        Object.setPrototypeOf(this, GitHubPermissionError.prototype);
    }
}
exports.GitHubPermissionError = GitHubPermissionError;
/**
 * Rate limit error - GitHub API rate limit exceeded
 */
class GitHubRateLimitError extends GitHubError {
    constructor(message, guidance, cause) {
        super('rate_limit_exceeded', message, guidance, cause);
        this.name = 'GitHubRateLimitError';
        Object.setPrototypeOf(this, GitHubRateLimitError.prototype);
    }
}
exports.GitHubRateLimitError = GitHubRateLimitError;
/**
 * Network error - command execution or network connectivity failure
 */
class GitHubNetworkError extends GitHubError {
    constructor(message, guidance, cause) {
        super('network_error', message, guidance, cause);
        this.name = 'GitHubNetworkError';
        Object.setPrototypeOf(this, GitHubNetworkError.prototype);
    }
}
exports.GitHubNetworkError = GitHubNetworkError;
//# sourceMappingURL=errors.js.map
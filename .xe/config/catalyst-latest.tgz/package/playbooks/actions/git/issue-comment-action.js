"use strict";
/**
 * GitHub issue comment action
 * @module playbooks/actions/git/issue-comment-action
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GitHubIssueCommentAction = void 0;
// @req FR:playbook-actions-git/issues.comment
// @req FR:playbook-actions-git/common.validation
// @req FR:playbook-actions-git/common.result-structure
const base_1 = require("./base");
const errors_1 = require("../../../core/errors");
/**
 * Action to add a comment to an existing GitHub issue
 */
class GitHubIssueCommentAction extends base_1.GitHubActionBase {
    validateConfig(config) {
        if (!config.issue || typeof config.issue !== 'number' || config.issue <= 0) {
            throw new errors_1.CatalystError('Issue number is required and must be a positive integer', 'GitHubIssueCommentConfigInvalid', 'Provide a valid issue number');
        }
        if (!config.body || config.body.trim() === '') {
            throw new errors_1.CatalystError('Comment body is required and cannot be empty', 'GitHubIssueCommentConfigInvalid', 'Provide a non-empty comment body');
        }
    }
    async executeGitHubOperation(config) {
        const repoFlag = await this.getRepoFlag(config.repository);
        const command = `gh issue comment ${config.issue} ${repoFlag} --body ${this.escapeShellArg(config.body)}`;
        // gh issue comment outputs only the comment URL; use gh api to get structured data
        const commentUrl = this.executeCommand(command);
        const { commentId, repoOwner, repoName } = this.extractCommentIdFromUrl(commentUrl);
        const apiCommand = `gh api repos/${repoOwner}/${repoName}/issues/comments/${commentId}`;
        const output = this.executeCommand(apiCommand);
        const rawData = this.parseJSON(output);
        return {
            id: rawData.id,
            url: rawData.html_url || rawData.url,
            body: rawData.body,
            createdAt: rawData.created_at || rawData.createdAt,
        };
    }
    getSuccessMessage(_data) {
        return `Added comment to issue`;
    }
    formatResultValue(data) {
        return {
            id: data.id,
            url: data.url,
        };
    }
    // Override execute to provide better success message with issue number
    async execute(config) {
        const result = await super.execute(config);
        if (result.code === 'Success') {
            result.message = `Added comment to issue #${config.issue}`;
        }
        return result;
    }
}
exports.GitHubIssueCommentAction = GitHubIssueCommentAction;
GitHubIssueCommentAction.actionType = 'github-issue-comment';
GitHubIssueCommentAction.primaryProperty = 'issue';
//# sourceMappingURL=issue-comment-action.js.map
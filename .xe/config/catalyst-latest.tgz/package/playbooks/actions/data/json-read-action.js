"use strict";
// @req FR:playbook-actions-data/json-read.@action
// @req FR:playbook-actions-data/json-read.input
// @req FR:playbook-actions-data/json-read.read
// @req FR:playbook-actions-data/json-read.errors
// @req FR:playbook-actions-data/json-read.output
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonReadAction = void 0;
const errors_1 = require("../../../core/errors");
const read_action_1 = require("../io/file/read-action");
/**
 * JSON read action
 *
 * Reads a file and parses its content as JSON. File I/O (path validation,
 * encoding, error mapping) is delegated to `file-read`; this action layers
 * JSON parsing on top.
 *
 * @example
 * ```typescript
 * const action = new JsonReadAction();
 * const result = await action.execute({ path: 'config.json' });
 * // result.value === parsed JSON value
 * ```
 *
 * @example YAML shorthand
 * ```yaml
 * steps:
 *   - name: catalog
 *     json-read: catalyst://playbooks/schema.json
 * ```
 */
class JsonReadAction {
    async execute(config) {
        // Delegate file I/O to file-read — inherits path validation, encoding
        // handling, and file-error mapping. file-read also validates that
        // config.path is present, so we don't duplicate that check here.
        const fileResult = await new read_action_1.FileReadAction().execute({
            path: config?.path,
            encoding: config?.encoding
        });
        // Propagate file errors as-is.
        if (fileResult.code !== 'Success') {
            return fileResult;
        }
        // Parse the file content as JSON.
        try {
            const parsed = JSON.parse(fileResult.value);
            return {
                code: 'Success',
                message: `Read and parsed JSON from ${config.path}`,
                value: parsed,
                error: undefined
            };
        }
        catch (error) {
            const parseError = new errors_1.CatalystError(`Failed to parse JSON in ${config.path}: ${error.message}`, 'JsonParseError', `The file '${config.path}' did not contain valid JSON. Check the file's contents.`, error);
            return {
                code: parseError.code,
                message: parseError.message,
                error: parseError
            };
        }
    }
}
exports.JsonReadAction = JsonReadAction;
JsonReadAction.actionType = 'json-read';
JsonReadAction.primaryProperty = 'path';
//# sourceMappingURL=json-read-action.js.map
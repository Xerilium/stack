"use strict";
/**
 * Data-format Actions for Playbook Workflows
 *
 * Native actions for reading and writing structured data files (currently
 * JSON). File I/O concerns are inherited from playbook-actions-io's file
 * actions; this module owns the parse/serialize layer.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonWriteAction = exports.JsonReadAction = void 0;
var json_read_action_1 = require("./json-read-action");
Object.defineProperty(exports, "JsonReadAction", { enumerable: true, get: function () { return json_read_action_1.JsonReadAction; } });
var json_write_action_1 = require("./json-write-action");
Object.defineProperty(exports, "JsonWriteAction", { enumerable: true, get: function () { return json_write_action_1.JsonWriteAction; } });
//# sourceMappingURL=index.js.map
"use strict";
// @req FR:playbook-actions-data/json-read.input
// @req FR:playbook-actions-data/json-write.input
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
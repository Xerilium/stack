"use strict";
// @req FR:playbook-actions-io/file.delete-action.implementation
// @req FR:playbook-actions-io/file.delete-action.deletion
// @req FR:playbook-actions-io/file.delete-action.result-format
// @req FR:playbook-actions-io/file.delete-action.error-handling
// @req FR:playbook-actions-io/security.config-validation
// @req NFR:playbook-actions-io/maintainability.single-responsibility
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileDeleteAction = void 0;
const fs = __importStar(require("fs/promises"));
const errors_1 = require("../../../../core/errors");
const logging_1 = require("../../../../core/logging");
const path_validation_1 = require("../utils/path-validation");
/**
 * File delete action
 *
 * Deletes a file at the specified path. Returns an error if the file
 * does not exist or cannot be deleted.
 *
 * @example
 * ```typescript
 * const action = new FileDeleteAction();
 * const result = await action.execute({
 *   path: '.xe/temp/output.txt'
 * });
 * // result.value === true if file was deleted
 * ```
 *
 * @example YAML shorthand
 * ```yaml
 * steps:
 *   - name: cleanup-temp
 *     file-delete: .xe/temp/output.txt
 * ```
 */
class FileDeleteAction {
    /**
     * Execute file deletion
     *
     * @param config - File delete configuration
     * @returns Promise resolving to action result
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        try {
            // Validate configuration
            this.validateConfig(config);
            // Extract path
            const { path: filePath } = config;
            // Validate and normalize path (prevents directory traversal)
            const safePath = (0, path_validation_1.validatePath)(filePath);
            logger.debug('FileDeleteAction', 'Execute', 'Executing file delete', { path: safePath });
            // Delete the file
            await fs.unlink(safePath);
            logger.verbose('FileDeleteAction', 'Execute', 'File deleted', { path: safePath });
            return {
                code: 'Success',
                message: `Successfully deleted file: ${filePath}`,
                value: true,
                error: undefined
            };
        }
        catch (error) {
            logger.debug('FileDeleteAction', 'Execute', 'File delete failed', { path: config.path, error: error.message });
            return this.handleError(error, config);
        }
    }
    /**
     * Validate configuration before execution
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        if (!config.path) {
            throw new errors_1.CatalystError('Missing required configuration property: path', 'FileConfigInvalid', `The file-delete action requires a 'path' property in the config. Provide a valid file path.`);
        }
    }
    /**
     * Handle errors and convert to PlaybookActionResult
     *
     * @param error - Error that occurred
     * @param config - Action configuration
     * @returns PlaybookActionResult with error details
     */
    handleError(error, config) {
        // If already a CatalystError, return it
        if (error instanceof errors_1.CatalystError) {
            return {
                code: error.code,
                message: `File delete failed for ${config.path}: ${error.message}`,
                error
            };
        }
        // Map Node.js errors to CatalystError
        const nodeError = error;
        if (nodeError.code === 'ENOENT') {
            const catalystError = new errors_1.CatalystError(`File not found: ${config.path}`, 'FileNotFound', `The file '${config.path}' does not exist. Check that the path is correct and the file has been created.`, error);
            return {
                code: catalystError.code,
                message: catalystError.message,
                error: catalystError
            };
        }
        if (nodeError.code === 'EACCES' || nodeError.code === 'EPERM') {
            const catalystError = new errors_1.CatalystError(`Permission denied deleting ${config.path}`, 'FilePermissionDenied', `Unable to delete '${config.path}' due to insufficient permissions. ` +
                `Check that the file is writable by the current user.`, error);
            return {
                code: catalystError.code,
                message: catalystError.message,
                error: catalystError
            };
        }
        // Generic error
        const catalystError = new errors_1.CatalystError(`Failed to delete file: ${config.path}`, 'FileDeleteFailed', `An error occurred while deleting '${config.path}'. See error details for more information.`, error);
        return {
            code: catalystError.code,
            message: catalystError.message,
            error: catalystError
        };
    }
}
exports.FileDeleteAction = FileDeleteAction;
FileDeleteAction.actionType = 'file-delete';
/**
 * Primary property for YAML shorthand syntax
 * Enables: `file-delete: path/to/file`
 */
FileDeleteAction.primaryProperty = 'path';
//# sourceMappingURL=delete-action.js.map
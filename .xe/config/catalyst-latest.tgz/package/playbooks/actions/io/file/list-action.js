"use strict";
// @req FR:playbook-actions-io/file-list.@action
// @req FR:playbook-actions-io/file-list.input
// @req FR:playbook-actions-io/file-list.enumerate
// @req FR:playbook-actions-io/file-list.format
// @req FR:playbook-actions-io/file-list.errors
// @req FR:playbook-actions-io/file-list.output
// @req NFR:playbook-actions-io/maintainability.single-responsibility
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileListAction = void 0;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const glob_1 = require("glob");
const errors_1 = require("../../../../core/errors");
const path_validation_1 = require("../utils/path-validation");
const VALID_RELATIVE_TO = ['root', 'cwd', 'absolute'];
/**
 * File list action
 *
 * Enumerates directory entries matching an optional glob pattern. Supports
 * flat (e.g. `*.md`) and recursive (e.g. `** /*.md`, written without the
 * space) globs. Result paths can be formatted relative to the input
 * directory (default), the current working directory, or as absolute paths.
 *
 * @example
 * ```typescript
 * const action = new FileListAction();
 * const result = await action.execute({
 *   path: 'playbooks',
 *   pattern: '*.md'
 * });
 * // result.value === ['create-feature.md', 'repair-feature.md', ...]
 * ```
 *
 * @example YAML shorthand
 * ```yaml
 * steps:
 *   - name: playbook-files
 *     file-list:
 *       path: catalyst://playbooks
 *       pattern: '*.md'
 * ```
 */
class FileListAction {
    async execute(config) {
        try {
            this.validateConfig(config);
            const { path: dirPath, pattern = '*', relativeTo = 'root' } = config;
            // Path traversal prevention. validatePath returns a normalized absolute path.
            const safeDir = (0, path_validation_1.validatePath)(dirPath);
            // Surface "not a directory / doesn't exist" with the right error code
            // BEFORE handing off to glob (glob silently returns []).
            const stat = await fs.stat(safeDir).catch((err) => {
                const code = err.code;
                if (code === 'ENOENT') {
                    throw new errors_1.CatalystError(`Directory not found: ${dirPath}`, 'FileNotFound', `The file-list action cannot list '${dirPath}' because the directory does not exist.`, err);
                }
                if (code === 'EACCES' || code === 'EPERM') {
                    throw new errors_1.CatalystError(`Permission denied listing ${dirPath}`, 'FilePermissionDenied', `The file-list action cannot access '${dirPath}' due to insufficient permissions.`, err);
                }
                throw err;
            });
            if (!stat.isDirectory()) {
                throw new errors_1.CatalystError(`Not a directory: ${dirPath}`, 'FileNotFound', `The file-list action requires a directory; '${dirPath}' is not a directory.`);
            }
            // Glob runs relative to `safeDir` and returns matches as POSIX-style paths.
            const matches = await (0, glob_1.glob)(pattern, {
                cwd: safeDir,
                nodir: true,
                dot: false,
                posix: true
            });
            const formatted = this.formatPaths(matches, safeDir, relativeTo).sort();
            return {
                code: 'Success',
                message: `Listed ${formatted.length} entries matching '${pattern}' in ${dirPath}`,
                value: formatted,
                error: undefined
            };
        }
        catch (error) {
            return this.handleError(error, config);
        }
    }
    validateConfig(config) {
        if (!config || typeof config !== 'object') {
            throw new errors_1.CatalystError('Missing configuration for file-list', 'FileConfigInvalid', `The file-list action requires a config object with at least a 'path' property.`);
        }
        if (!config.path) {
            throw new errors_1.CatalystError('Missing required configuration property: path', 'FileConfigInvalid', `The file-list action requires a 'path' property in the config. Provide a directory path.`);
        }
        if (config.relativeTo !== undefined && !VALID_RELATIVE_TO.includes(config.relativeTo)) {
            throw new errors_1.CatalystError(`Invalid relativeTo value: ${config.relativeTo}`, 'FileConfigInvalid', `The file-list action's 'relativeTo' must be one of: ${VALID_RELATIVE_TO.join(', ')}.`);
        }
    }
    /**
     * Format glob matches per the requested relativeTo mode.
     * - `root` (default): relative to the listed directory
     * - `cwd`: relative to process.cwd()
     * - `absolute`: full filesystem paths
     */
    formatPaths(matches, safeDir, relativeTo) {
        switch (relativeTo) {
            case 'root':
                return matches; // glob already returned cwd-relative-to-safeDir (i.e., root-relative)
            case 'absolute':
                return matches.map((m) => path.join(safeDir, m));
            case 'cwd':
                return matches.map((m) => path.relative(process.cwd(), path.join(safeDir, m)));
        }
    }
    handleError(error, config) {
        if (error instanceof errors_1.CatalystError) {
            return {
                code: error.code,
                message: error.message,
                error
            };
        }
        const nodeError = error;
        if (nodeError.code === 'EACCES' || nodeError.code === 'EPERM') {
            const wrapped = new errors_1.CatalystError(`Permission denied listing ${config?.path}`, 'FilePermissionDenied', `Unable to list '${config?.path}' due to insufficient permissions.`, error);
            return { code: wrapped.code, message: wrapped.message, error: wrapped };
        }
        const wrapped = new errors_1.CatalystError(`Failed to list directory: ${config?.path}`, 'FileListFailed', `An error occurred while listing '${config?.path}'. See error details for more information.`, error);
        return { code: wrapped.code, message: wrapped.message, error: wrapped };
    }
}
exports.FileListAction = FileListAction;
FileListAction.actionType = 'file-list';
FileListAction.primaryProperty = 'path';
//# sourceMappingURL=list-action.js.map
"use strict";
// @req FR:playbook-actions-io/file.exists-action.implementation
// @req FR:playbook-actions-io/file.exists-action.check
// @req FR:playbook-actions-io/file.exists-action.result-format
// @req FR:playbook-actions-io/file.exists-action.error-handling
// @req NFR:playbook-actions-io/maintainability.single-responsibility
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileExistsAction = void 0;
const fs = __importStar(require("fs/promises"));
const errors_1 = require("../../../../core/errors");
const path_validation_1 = require("../utils/path-validation");
/**
 * File exists action
 *
 * Checks if a file exists at the specified path. Returns a boolean value
 * indicating whether the file exists. Does NOT throw errors for non-existent
 * files - that's the expected use case.
 *
 * @example
 * ```typescript
 * const action = new FileExistsAction();
 * const result = await action.execute({
 *   path: '.xe/config.json'
 * });
 * // result.value === true if file exists, false otherwise
 * ```
 *
 * @example YAML shorthand
 * ```yaml
 * steps:
 *   - name: check-config
 *     file-exists: .xe/config.json
 *
 *   - if: "{{check-config}}"
 *     then:
 *       - file-read: .xe/config.json
 * ```
 */
class FileExistsAction {
    /**
     * Execute file existence check
     *
     * @param config - File exists configuration
     * @returns Promise resolving to action result with boolean value
     */
    async execute(config) {
        try {
            // Validate configuration
            this.validateConfig(config);
            // Extract path
            const { path: filePath } = config;
            // Validate and normalize path (prevents directory traversal)
            const safePath = (0, path_validation_1.validatePath)(filePath);
            // Check if file exists
            try {
                await fs.access(safePath, fs.constants.F_OK);
                // File exists
                return {
                    code: 'Success',
                    message: `File exists: ${filePath}`,
                    value: true,
                    error: undefined
                };
            }
            catch {
                // File does not exist - this is NOT an error condition
                return {
                    code: 'Success',
                    message: `File does not exist: ${filePath}`,
                    value: false,
                    error: undefined
                };
            }
        }
        catch (error) {
            return this.handleError(error, config);
        }
    }
    /**
     * Validate configuration before execution
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        if (!config.path) {
            throw new errors_1.CatalystError('Missing required configuration property: path', 'FileConfigInvalid', `The file-exists action requires a 'path' property in the config. Provide a valid file path.`);
        }
    }
    /**
     * Handle errors and convert to PlaybookActionResult
     *
     * @param error - Error that occurred
     * @param config - Action configuration
     * @returns PlaybookActionResult with error details
     */
    handleError(error, config) {
        // If already a CatalystError, return it
        if (error instanceof errors_1.CatalystError) {
            return {
                code: error.code,
                message: `File exists check failed for ${config.path}: ${error.message}`,
                error
            };
        }
        // Map Node.js errors to CatalystError
        const nodeError = error;
        if (nodeError.code === 'EACCES' || nodeError.code === 'EPERM') {
            const catalystError = new errors_1.CatalystError(`Permission denied checking ${config.path}`, 'FilePermissionDenied', `Unable to check '${config.path}' due to insufficient permissions. ` +
                `Check that the path is accessible by the current user.`, error);
            return {
                code: catalystError.code,
                message: catalystError.message,
                error: catalystError
            };
        }
        // Generic error
        const catalystError = new errors_1.CatalystError(`Failed to check file existence: ${config.path}`, 'FileCheckFailed', `An error occurred while checking '${config.path}'. See error details for more information.`, error);
        return {
            code: catalystError.code,
            message: catalystError.message,
            error: catalystError
        };
    }
}
exports.FileExistsAction = FileExistsAction;
FileExistsAction.actionType = 'file-exists';
/**
 * Primary property for YAML shorthand syntax
 * Enables: `file-exists: path/to/file`
 */
FileExistsAction.primaryProperty = 'path';
//# sourceMappingURL=exists-action.js.map
"use strict";
// @req FR:playbook-actions-io/file.write-action.implementation
// @req FR:playbook-actions-io/file.write-action.atomic-write
// @req FR:playbook-actions-io/file.write-action.content-processing
// @req FR:playbook-actions-io/file.write-action.result-format
// @req FR:playbook-actions-io/file.write-action.error-handling
// @req FR:playbook-actions-io/security.config-validation
// @req NFR:playbook-actions-io/performance.file-write-overhead
// @req NFR:playbook-actions-io/maintainability.single-responsibility
// @req NFR:playbook-actions-io/reliability.error-guidance
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileWriteAction = void 0;
const errors_1 = require("../../../../core/errors");
const logging_1 = require("../../../../core/logging");
const path_validation_1 = require("../utils/path-validation");
const atomic_write_1 = require("../utils/atomic-write");
const front_matter_1 = require("../utils/front-matter");
/**
 * File write action
 *
 * Writes file contents with atomic write pattern, front matter support,
 * and simple text replacement.
 *
 * @example
 * ```typescript
 * const action = new FileWriteAction();
 * const result = await action.execute({
 *   path: '.xe/features/my-feature/spec.md',
 *   content: '# Feature\n\nDescription here',
 *   frontMatter: { id: 'my-feature', author: 'me' }
 * });
 * ```
 */
class FileWriteAction {
    /**
     * Execute file write operation
     *
     * @param config - File write configuration
     * @returns Promise resolving to action result
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        try {
            // Validate configuration
            this.validateConfig(config);
            // Extract configuration with defaults
            const { path: filePath, content, encoding = 'utf8', frontMatter, replace } = config;
            // Validate and normalize path
            const safePath = (0, path_validation_1.validatePath)(filePath);
            logger.debug('FileWriteAction', 'Execute', 'Executing file write', { path: safePath, encoding, hasFrontMatter: !!frontMatter, hasReplace: !!replace });
            // Process content
            let processedContent = content;
            // Apply replace dictionary if provided
            if (replace) {
                for (const [find, replaceWith] of Object.entries(replace)) {
                    // Use global regex to replace all occurrences
                    const regex = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
                    processedContent = processedContent.replace(regex, replaceWith);
                }
            }
            // Add front matter if provided
            if (frontMatter) {
                processedContent = (0, front_matter_1.addFrontMatter)(processedContent, frontMatter, filePath);
            }
            // Write file atomically
            await (0, atomic_write_1.atomicWrite)(safePath, processedContent, encoding);
            // Calculate bytes written
            const bytesWritten = Buffer.byteLength(processedContent, encoding);
            // Success
            const result = {
                path: filePath,
                bytesWritten
            };
            logger.verbose('FileWriteAction', 'Execute', 'File write completed', { path: safePath, bytesWritten });
            return {
                code: 'Success',
                message: `Successfully wrote ${bytesWritten} bytes to ${filePath}`,
                value: result,
                error: undefined
            };
        }
        catch (error) {
            logger.debug('FileWriteAction', 'Execute', 'File write failed', { path: config.path, error: error.message });
            return this.handleError(error, config);
        }
    }
    /**
     * Validate configuration before execution
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        if (!config.path) {
            throw new errors_1.CatalystError('Missing required configuration property: path', 'FileConfigInvalid', `The file-write action requires a 'path' property in the config. Provide a valid file path.`);
        }
        if (config.content === undefined) {
            throw new errors_1.CatalystError('Missing required configuration property: content', 'FileConfigInvalid', `The file-write action requires a 'content' property in the config. Provide content to write.`);
        }
    }
    /**
     * Handle errors and convert to PlaybookActionResult
     *
     * @param error - Error that occurred
     * @param config - Action configuration
     * @returns PlaybookActionResult with error details
     */
    handleError(error, config) {
        // If already a CatalystError, return it
        if (error instanceof errors_1.CatalystError) {
            return {
                code: error.code,
                message: `File write failed for ${config.path}: ${error.message}`,
                error
            };
        }
        // Generic error
        const catalystError = new errors_1.CatalystError(`Failed to write file: ${config.path}`, 'FileWriteFailed', `An error occurred while writing to '${config.path}'. See error details for more information.`, error);
        return {
            code: catalystError.code,
            message: catalystError.message,
            error: catalystError
        };
    }
}
exports.FileWriteAction = FileWriteAction;
FileWriteAction.actionType = 'file-write';
FileWriteAction.primaryProperty = 'path';
//# sourceMappingURL=write-action.js.map
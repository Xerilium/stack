"use strict";
// @req FR:playbook-actions-io/file.read-action.implementation
// @req FR:playbook-actions-io/file.read-action.file-reading
// @req FR:playbook-actions-io/file.read-action.result-format
// @req FR:playbook-actions-io/file.read-action.error-handling
// @req FR:playbook-actions-io/security.config-validation
// @req NFR:playbook-actions-io/performance.file-read-overhead
// @req NFR:playbook-actions-io/maintainability.single-responsibility
// @req NFR:playbook-actions-io/reliability.error-guidance
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileReadAction = void 0;
const fs = __importStar(require("fs/promises"));
const errors_1 = require("../../../../core/errors");
const logging_1 = require("../../../../core/logging");
const path_validation_1 = require("../utils/path-validation");
/**
 * File read action
 *
 * Reads file contents with encoding support and path validation.
 *
 * @example
 * ```typescript
 * const action = new FileReadAction();
 * const result = await action.execute({
 *   path: '.xe/product.md',
 *   encoding: 'utf8'
 * });
 * ```
 */
class FileReadAction {
    /**
     * Execute file read operation
     *
     * @param config - File read configuration
     * @returns Promise resolving to action result
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        try {
            // Validate configuration
            this.validateConfig(config);
            // Extract configuration with defaults
            const { path: filePath, encoding = 'utf8' } = config;
            // Validate and normalize path
            const safePath = (0, path_validation_1.validatePath)(filePath);
            logger.debug('FileReadAction', 'Execute', 'Executing file read', { path: safePath, encoding });
            // Read file
            const content = await fs.readFile(safePath, { encoding: encoding });
            logger.verbose('FileReadAction', 'Execute', 'File read completed', { path: safePath, bytes: content.length });
            logger.trace('FileReadAction', 'Execute', 'Content preview', { content: content.substring(0, 200) });
            // Success
            return {
                code: 'Success',
                message: `Successfully read file: ${filePath}`,
                value: content,
                error: undefined
            };
        }
        catch (error) {
            logger.debug('FileReadAction', 'Execute', 'File read failed', { path: config.path, error: error.message });
            return this.handleError(error, config);
        }
    }
    /**
     * Validate configuration before execution
     *
     * @param config - Configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        if (!config.path) {
            throw new errors_1.CatalystError('Missing required configuration property: path', 'FileConfigInvalid', `The file-read action requires a 'path' property in the config. Provide a valid file path.`);
        }
        // Validate encoding if provided
        const validEncodings = ['utf8', 'utf-8', 'ascii', 'base64', 'binary', 'hex'];
        if (config.encoding && !validEncodings.includes(config.encoding)) {
            throw new errors_1.CatalystError(`Invalid encoding: ${config.encoding}`, 'FileInvalidEncoding', `The encoding '${config.encoding}' is not supported. Valid encodings: ${validEncodings.join(', ')}`);
        }
    }
    /**
     * Handle errors and convert to PlaybookActionResult
     *
     * @param error - Error that occurred
     * @param config - Action configuration
     * @returns PlaybookActionResult with error details
     */
    handleError(error, config) {
        // If already a CatalystError, return it
        if (error instanceof errors_1.CatalystError) {
            return {
                code: error.code,
                message: `File read failed for ${config.path}: ${error.message}`,
                error
            };
        }
        // Map Node.js errors to CatalystError
        const nodeError = error;
        if (nodeError.code === 'ENOENT') {
            const catalystError = new errors_1.CatalystError(`File not found: ${config.path}`, 'FileNotFound', `The file '${config.path}' does not exist. Check that the path is correct and the file has been created.`, error);
            return {
                code: catalystError.code,
                message: catalystError.message,
                error: catalystError
            };
        }
        if (nodeError.code === 'EACCES' || nodeError.code === 'EPERM') {
            const catalystError = new errors_1.CatalystError(`Permission denied reading ${config.path}`, 'FilePermissionDenied', `Unable to read '${config.path}' due to insufficient permissions. ` +
                `Check that the file is readable by the current user.`, error);
            return {
                code: catalystError.code,
                message: catalystError.message,
                error: catalystError
            };
        }
        // Generic error
        const catalystError = new errors_1.CatalystError(`Failed to read file: ${config.path}`, 'FileReadFailed', `An error occurred while reading '${config.path}'. See error details for more information.`, error);
        return {
            code: catalystError.code,
            message: catalystError.message,
            error: catalystError
        };
    }
}
exports.FileReadAction = FileReadAction;
FileReadAction.actionType = 'file-read';
FileReadAction.primaryProperty = 'path';
//# sourceMappingURL=read-action.js.map
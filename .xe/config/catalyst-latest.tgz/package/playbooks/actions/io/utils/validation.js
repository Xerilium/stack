"use strict";
// @req FR:playbook-actions-io/http.base-class.error-handling
// @req NFR:playbook-actions-io/maintainability.shared-logic
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultStatusValidator = defaultStatusValidator;
exports.validateResponseStatus = validateResponseStatus;
const errors_1 = require("../../../../core/errors");
/**
 * Status validation utility
 *
 * Validates HTTP response status codes against configured rules.
 */
/**
 * Default status validator: 2xx status codes are valid
 *
 * @param status - HTTP status code
 * @returns true if status is valid (200-299)
 */
function defaultStatusValidator(status) {
    return status >= 200 && status < 300;
}
/**
 * Validate response status code
 *
 * @param status - HTTP status code
 * @param validator - Custom validation function (defaults to 2xx validator)
 * @param errorCode - Error code to use if validation fails (default: 'HttpInvalidStatus')
 * @throws CatalystError if status is invalid
 *
 * @example
 * ```typescript
 * validateResponseStatus(200); // No error
 * validateResponseStatus(404); // Throws CatalystError
 * validateResponseStatus(503, (s) => s === 503); // No error
 * ```
 */
function validateResponseStatus(status, validator = defaultStatusValidator, errorCode = 'HttpInvalidStatus') {
    if (!validator(status)) {
        throw new errors_1.CatalystError(`HTTP request failed with status ${status}`, errorCode, `The server returned status code ${status} which is considered invalid. ` +
            `Common status codes: 200 (OK), 404 (Not Found), 500 (Server Error). ` +
            `Check the API documentation for expected status codes, or configure a custom status validator.`);
    }
}
//# sourceMappingURL=validation.js.map
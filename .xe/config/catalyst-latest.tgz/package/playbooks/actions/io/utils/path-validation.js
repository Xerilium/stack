"use strict";
// @req FR:playbook-actions-io/file.read-action.file-reading
// @req FR:playbook-actions-io/file.write-action.atomic-write
// @req FR:playbook-actions-io/security.path-traversal-prevention
// @req NFR:playbook-actions-io/maintainability.shared-logic
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.validatePath = validatePath;
exports.isSafePath = isSafePath;
const path = __importStar(require("path"));
const errors_1 = require("../../../../core/errors");
/**
 * Path validation utility
 *
 * Validates and normalizes file paths to prevent directory traversal attacks.
 */
/**
 * Validate and normalize a file path
 *
 * @param filePath - Path to validate
 * @param errorCode - Error code for invalid paths (default: 'FileInvalidPath')
 * @returns Normalized absolute path
 * @throws CatalystError if path contains directory traversal attempts
 *
 * @example
 * ```typescript
 * const safePath = validatePath('./data/file.txt'); // OK
 * const badPath = validatePath('../../../etc/passwd'); // Throws error
 * ```
 */
function validatePath(filePath, errorCode = 'FileInvalidPath') {
    // Normalize the path (resolves . and .. segments)
    const normalized = path.normalize(filePath);
    // Check for directory traversal attempts
    // After normalization, '..' segments that escape should be visible
    if (normalized.includes('..')) {
        throw new errors_1.CatalystError(`Invalid path: ${filePath} contains directory traversal`, errorCode, `The path '${filePath}' contains '..' segments which could be used for directory traversal attacks. ` +
            `Use absolute paths or paths relative to the current working directory without '..' segments.`);
    }
    // Resolve to absolute path
    // If already absolute, returns as-is
    // If relative, resolves against current working directory
    const absolutePath = path.resolve(normalized);
    return absolutePath;
}
/**
 * Check if a path is safe (no directory traversal)
 *
 * @param filePath - Path to check
 * @returns true if path is safe
 */
function isSafePath(filePath) {
    try {
        validatePath(filePath);
        return true;
    }
    catch (_error) {
        return false;
    }
}
//# sourceMappingURL=path-validation.js.map
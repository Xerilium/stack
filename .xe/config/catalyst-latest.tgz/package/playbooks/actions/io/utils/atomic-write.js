"use strict";
// @req FR:playbook-actions-io/file.write-action.atomic-write
// @req NFR:playbook-actions-io/reliability.atomic-writes
// @req NFR:playbook-actions-io/reliability.temp-file-cleanup
// @req NFR:playbook-actions-io/maintainability.shared-logic
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.atomicWrite = atomicWrite;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const errors_1 = require("../../../../core/errors");
/**
 * Atomic write utility
 *
 * Writes files atomically to prevent corruption on crash or interruption.
 * Uses a temp file + rename pattern for atomicity.
 */
/**
 * Write content to a file atomically
 *
 * Writes to a temporary file first, then renames it to the target path.
 * This ensures the file is either fully written or not written at all.
 *
 * @param filePath - Target file path
 * @param content - Content to write
 * @param encoding - File encoding (default: 'utf8')
 * @throws CatalystError on write or rename failure
 *
 * @example
 * ```typescript
 * await atomicWrite('/path/to/file.txt', 'Hello World', 'utf8');
 * ```
 */
async function atomicWrite(filePath, content, encoding = 'utf8') {
    // Generate temporary file path in same directory
    const directory = path.dirname(filePath);
    const filename = path.basename(filePath);
    const tempPath = path.join(directory, `.${filename}.tmp`);
    try {
        // Ensure parent directory exists
        await fs.mkdir(directory, { recursive: true });
        // Write to temporary file
        await fs.writeFile(tempPath, content, { encoding });
        // Atomically rename temp file to target path
        await fs.rename(tempPath, filePath);
    }
    catch (error) {
        // Clean up temp file if it exists
        try {
            await fs.unlink(tempPath);
        }
        catch (_cleanupError) {
            // Ignore cleanup errors
        }
        // Map error to CatalystError
        const nodeError = error;
        if (nodeError.code === 'EACCES' || nodeError.code === 'EPERM') {
            throw new errors_1.CatalystError(`Permission denied writing to ${filePath}`, 'FilePermissionDenied', `Unable to write to '${filePath}' due to insufficient permissions. ` +
                `Check that the file and directory are writable by the current user.`, error);
        }
        if (nodeError.code === 'ENOSPC') {
            throw new errors_1.CatalystError(`Disk full while writing to ${filePath}`, 'FileDiskFull', `Unable to write to '${filePath}' because the disk is full. ` +
                `Free up disk space and try again.`, error);
        }
        throw new errors_1.CatalystError(`Failed to write file: ${filePath}`, 'FileWriteFailed', `An error occurred while writing to '${filePath}'. See error details for more information.`, error);
    }
}
//# sourceMappingURL=atomic-write.js.map
"use strict";
// @req FR:playbook-actions-io/http.base-class.config-interface
// @req FR:playbook-actions-io/http.request-bodies.config-interface
// @req FR:playbook-actions-io/file.read-action.implementation
// @req FR:playbook-actions-io/file.write-action.implementation
// @req NFR:playbook-actions-io/maintainability.type-safety
// @req NFR:playbook-actions-io/maintainability.error-codes
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
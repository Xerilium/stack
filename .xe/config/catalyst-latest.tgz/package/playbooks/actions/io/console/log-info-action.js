"use strict";
// @req FR:playbook-actions-io/log.info-action
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogInfoAction = void 0;
const base_log_action_1 = require("./base-log-action");
/**
 * Log info action
 *
 * Writes an informational message via the framework Logger.
 *
 * @example
 * ```yaml
 * steps:
 *   # Full syntax
 *   - action: log-info
 *     config:
 *       message: "Processing item {{index}} of {{total}}"
 *
 *   # Shorthand syntax
 *   - log-info: "Starting deployment to {{environment}}"
 * ```
 */
class LogInfoAction extends base_log_action_1.LogActionBase {
    constructor() {
        super(...arguments);
        this.level = 'info';
    }
}
exports.LogInfoAction = LogInfoAction;
LogInfoAction.actionType = 'log-info';
LogInfoAction.primaryProperty = 'message';
//# sourceMappingURL=log-info-action.js.map
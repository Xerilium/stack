"use strict";
// @req FR:playbook-actions-io/log.warning-action
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogWarningAction = void 0;
const base_log_action_1 = require("./base-log-action");
/**
 * Log warning action
 *
 * Writes a warning message via the framework Logger.
 *
 * @example
 * ```yaml
 * steps:
 *   # Full syntax
 *   - action: log-warning
 *     config:
 *       message: "Feature {{feature-name}} is deprecated"
 *
 *   # Shorthand syntax
 *   - log-warning: "Config file not found, using defaults"
 * ```
 */
class LogWarningAction extends base_log_action_1.LogActionBase {
    constructor() {
        super(...arguments);
        this.level = 'warning';
    }
}
exports.LogWarningAction = LogWarningAction;
LogWarningAction.actionType = 'log-warning';
LogWarningAction.primaryProperty = 'message';
//# sourceMappingURL=log-warning-action.js.map
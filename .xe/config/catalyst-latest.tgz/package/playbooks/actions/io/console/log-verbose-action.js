"use strict";
// @req FR:playbook-actions-io/log.verbose-action
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogVerboseAction = void 0;
const base_log_action_1 = require("./base-log-action");
/**
 * Log verbose action
 *
 * Writes a verbose message via the framework Logger.
 * Used for detailed progress information that may be too noisy for normal output.
 *
 * @example
 * ```yaml
 * steps:
 *   # Full syntax
 *   - action: log-verbose
 *     config:
 *       message: "Request headers: {{headers}}"
 *       source: "HttpClient"
 *       action: "SendRequest"
 *
 *   # Shorthand syntax
 *   - log-verbose: "File content length: {{content-length}} bytes"
 * ```
 */
class LogVerboseAction extends base_log_action_1.LogActionBase {
    constructor() {
        super(...arguments);
        this.level = 'verbose';
    }
}
exports.LogVerboseAction = LogVerboseAction;
LogVerboseAction.actionType = 'log-verbose';
LogVerboseAction.primaryProperty = 'message';
//# sourceMappingURL=log-verbose-action.js.map
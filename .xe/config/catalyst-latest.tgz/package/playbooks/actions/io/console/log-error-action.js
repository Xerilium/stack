"use strict";
// @req FR:playbook-actions-io/log.error-action
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogErrorAction = void 0;
const base_log_action_1 = require("./base-log-action");
/**
 * Log error action
 *
 * Writes an error message via the framework Logger.
 * Does NOT terminate playbook execution - use the 'throw' action for that.
 *
 * @example
 * ```yaml
 * steps:
 *   # Full syntax
 *   - action: log-error
 *     config:
 *       message: "Validation failed for {{item-name}}"
 *       source: "Validator"
 *       action: "CheckInput"
 *
 *   # Shorthand syntax
 *   - log-error: "Error processing {{file}}: {{error}}"
 * ```
 */
class LogErrorAction extends base_log_action_1.LogActionBase {
    constructor() {
        super(...arguments);
        this.level = 'error';
    }
}
exports.LogErrorAction = LogErrorAction;
LogErrorAction.actionType = 'log-error';
LogErrorAction.primaryProperty = 'message';
//# sourceMappingURL=log-error-action.js.map
"use strict";
// @req FR:playbook-actions-io/log.debug-action
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogDebugAction = void 0;
const base_log_action_1 = require("./base-log-action");
/**
 * Log debug action
 *
 * Writes a debug message via the framework Logger.
 * Used for troubleshooting and development diagnostics.
 *
 * @example
 * ```yaml
 * steps:
 *   # Full syntax
 *   - action: log-debug
 *     config:
 *       message: "Current state: {{state}}"
 *       data:
 *         variables: { x: 1, y: 2 }
 *
 *   # Shorthand syntax
 *   - log-debug: "Variable values: x={{x}}, y={{y}}"
 * ```
 */
class LogDebugAction extends base_log_action_1.LogActionBase {
    constructor() {
        super(...arguments);
        this.level = 'debug';
    }
}
exports.LogDebugAction = LogDebugAction;
LogDebugAction.actionType = 'log-debug';
LogDebugAction.primaryProperty = 'message';
//# sourceMappingURL=log-debug-action.js.map
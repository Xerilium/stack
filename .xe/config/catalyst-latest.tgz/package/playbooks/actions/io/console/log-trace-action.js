"use strict";
// @req FR:playbook-actions-io/log.trace-action
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogTraceAction = void 0;
const base_log_action_1 = require("./base-log-action");
/**
 * Log trace action
 *
 * Writes a trace message via the framework Logger.
 * Intended for telemetry and detailed execution tracing.
 *
 * @example
 * ```yaml
 * steps:
 *   # Full syntax
 *   - action: log-trace
 *     config:
 *       message: "Step completed"
 *       source: "Engine"
 *       action: "ExecuteStep"
 *       data:
 *         step: "product-md"
 *         duration: 150
 *
 *   # Shorthand syntax
 *   - log-trace: "API call: method={{method}}, url={{url}}, status={{status}}"
 * ```
 */
class LogTraceAction extends base_log_action_1.LogActionBase {
    constructor() {
        super(...arguments);
        this.level = 'trace';
    }
}
exports.LogTraceAction = LogTraceAction;
LogTraceAction.actionType = 'log-trace';
LogTraceAction.primaryProperty = 'message';
//# sourceMappingURL=log-trace-action.js.map
"use strict";
// @req FR:playbook-actions-io/http.post-action.implementation
// @req NFR:playbook-actions-io/maintainability.single-responsibility
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpPostAction = void 0;
const base_http_action_1 = require("./base-http-action");
/**
 * HTTP POST action
 *
 * Executes HTTP POST requests with request body support, retry logic,
 * timeout enforcement, and comprehensive error handling.
 *
 * @example
 * ```typescript
 * const action = new HttpPostAction();
 * const result = await action.execute({
 *   url: 'https://api.example.com/users',
 *   headers: { 'Authorization': 'Bearer token' },
 *   body: { email: 'user@example.com', name: 'User' },
 *   timeout: 30000,
 *   retries: 3
 * });
 * ```
 */
class HttpPostAction extends base_http_action_1.HttpActionBase {
    constructor() {
        super(...arguments);
        this.method = 'POST';
    }
}
exports.HttpPostAction = HttpPostAction;
HttpPostAction.actionType = 'http-post';
//# sourceMappingURL=post-action.js.map
"use strict";
// @req FR:playbook-actions-io/http.put-action.implementation
// @req NFR:playbook-actions-io/maintainability.single-responsibility
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpPutAction = void 0;
const base_http_action_1 = require("./base-http-action");
/**
 * HTTP PUT action
 *
 * Executes HTTP PUT requests with request body support, retry logic,
 * timeout enforcement, and comprehensive error handling.
 *
 * @example
 * ```typescript
 * const action = new HttpPutAction();
 * const result = await action.execute({
 *   url: 'https://api.example.com/users/123',
 *   headers: { 'Authorization': 'Bearer token' },
 *   body: { email: 'updated@example.com', name: 'Updated User' },
 *   timeout: 30000,
 *   retries: 3
 * });
 * ```
 */
class HttpPutAction extends base_http_action_1.HttpActionBase {
    constructor() {
        super(...arguments);
        this.method = 'PUT';
    }
}
exports.HttpPutAction = HttpPutAction;
HttpPutAction.actionType = 'http-put';
//# sourceMappingURL=put-action.js.map
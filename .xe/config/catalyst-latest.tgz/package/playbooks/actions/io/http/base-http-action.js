"use strict";
// @req FR:playbook-actions-io/http.base-class.abstract-implementation
// @req FR:playbook-actions-io/http.base-class.config-interface
// @req FR:playbook-actions-io/http.base-class.request-execution
// @req FR:playbook-actions-io/http.base-class.timeout-enforcement
// @req FR:playbook-actions-io/http.base-class.retry-logic
// @req FR:playbook-actions-io/http.base-class.result-format
// @req FR:playbook-actions-io/http.base-class.error-handling
// @req FR:playbook-actions-io/http.base-class.header-masking
// @req FR:playbook-actions-io/http.request-bodies.serialization
// @req FR:playbook-actions-io/security.config-validation
// @req NFR:playbook-actions-io/performance.http-overhead
// @req NFR:playbook-actions-io/maintainability.single-responsibility
// @req NFR:playbook-actions-io/maintainability.shared-logic
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpActionBase = void 0;
const errors_1 = require("../../../../core/errors");
const logging_1 = require("../../../../core/logging");
const retry_1 = require("../utils/retry");
const timeout_1 = require("../utils/timeout");
const masking_1 = require("../utils/masking");
const validation_1 = require("../utils/validation");
/**
 * Abstract base class for all HTTP actions
 *
 * Provides shared HTTP functionality including request execution, retry logic,
 * timeout enforcement, header masking, status validation, and error handling.
 *
 * Subclasses must define:
 * - static readonly actionType: Kebab-case action identifier (e.g., 'http-get')
 * - readonly method: HTTP method (GET, POST, PUT, PATCH)
 */
class HttpActionBase {
    /**
     * Execute HTTP request with retry, timeout, and error handling
     *
     * @param config - Action configuration
     * @returns Promise resolving to action result
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        try {
            // Validate configuration
            this.validateConfig(config);
            // Extract configuration with defaults
            const { url, headers = {}, timeout = 30000, retries = 3, validateStatus = validation_1.defaultStatusValidator } = config;
            // Get action type for logging
            const actionType = this.constructor.actionType;
            // Mask URL and headers for logging
            const maskedUrl = (0, masking_1.maskSensitiveUrlParams)(url);
            const maskedHeaders = (0, masking_1.maskSensitiveHeaders)(headers);
            logger.debug('HttpAction', 'Execute', `${actionType} executing request`, { url: maskedUrl, timeout, retries });
            logger.trace('HttpAction', 'Execute', `${actionType} headers`, { headers: maskedHeaders });
            // Execute request with retry and timeout
            const response = await (0, retry_1.executeWithRetry)(async () => {
                return await (0, timeout_1.withTimeout)(this.performRequest(config), timeout, 'HttpTimeout');
            }, retries, (error) => {
                // Determine if error is retryable
                if (error instanceof errors_1.CatalystError && error.code === 'HttpInvalidStatus') {
                    // Extract status code from error context if available
                    const statusMatch = error.message.match(/status (\d+)/);
                    const status = statusMatch ? parseInt(statusMatch[1], 10) : undefined;
                    return (0, retry_1.isRetryableHttpError)(error, status);
                }
                // Other errors (network, timeout) are retryable
                return true;
            });
            // Validate status
            (0, validation_1.validateResponseStatus)(response.status, validateStatus);
            logger.verbose('HttpAction', 'Execute', `${actionType} completed`, { url: maskedUrl, status: response.status });
            logger.trace('HttpAction', 'Execute', `${actionType} response`, { bodyLength: response.body.length, headers: response.headers });
            // Success
            return {
                code: 'Success',
                message: `HTTP ${this.method} request to ${maskedUrl} completed with status ${response.status}`,
                value: response,
                error: undefined
            };
        }
        catch (error) {
            const maskedUrl = (0, masking_1.maskSensitiveUrlParams)(config.url);
            logger.debug('HttpAction', 'Execute', `${this.constructor.actionType} failed`, { url: maskedUrl, error: error.message });
            return this.handleError(error, config);
        }
    }
    /**
     * Perform the actual HTTP request
     *
     * @param config - Action configuration
     * @returns Promise resolving to HTTP response
     */
    async performRequest(config) {
        const { url, headers = {} } = config;
        try {
            // Prepare request options
            const requestOptions = {
                method: this.method,
                headers: {
                    'User-Agent': 'Catalyst-Playbook/1.0',
                    ...headers
                }
            };
            // Add body for POST/PUT/PATCH requests
            if (this.hasBody(config)) {
                const bodyConfig = config;
                if (bodyConfig.body !== undefined) {
                    // Determine content type
                    const contentType = bodyConfig.contentType ||
                        (typeof bodyConfig.body === 'object' ? 'application/json' : 'text/plain');
                    // Add Content-Type header if not already set
                    if (!requestOptions.headers) {
                        requestOptions.headers = {};
                    }
                    requestOptions.headers['Content-Type'] = contentType;
                    // Serialize body
                    if (typeof bodyConfig.body === 'object') {
                        requestOptions.body = JSON.stringify(bodyConfig.body);
                    }
                    else {
                        requestOptions.body = bodyConfig.body;
                    }
                }
            }
            // Execute fetch
            const response = await fetch(url, requestOptions);
            // Read response body
            const body = await response.text();
            // Parse JSON if applicable
            let bodyAsJson;
            const contentType = response.headers.get('content-type');
            if (contentType?.includes('application/json')) {
                try {
                    bodyAsJson = JSON.parse(body);
                }
                catch (_e) {
                    // Ignore JSON parse errors
                }
            }
            // Convert headers to record
            const responseHeaders = {};
            response.headers.forEach((value, key) => {
                responseHeaders[key] = value;
            });
            return {
                status: response.status,
                headers: responseHeaders,
                body,
                bodyAsJson
            };
        }
        catch (error) {
            // Map fetch errors to CatalystError
            if (error.code === 'ENOTFOUND') {
                throw new errors_1.CatalystError(`DNS resolution failed for ${url}`, 'HttpDnsError', `Unable to resolve the hostname in ${url}. Check that the URL is correct and that you have network connectivity.`, error);
            }
            throw new errors_1.CatalystError(`Network error during HTTP ${this.method} request`, 'HttpNetworkError', `Failed to connect to ${url}. This could be due to network connectivity issues, firewall rules, or the server being unreachable.`, error);
        }
    }
    /**
     * Check if this action supports request bodies
     *
     * @param _config - Action configuration (unused but kept for interface consistency)
     * @returns true if action supports bodies (POST/PUT/PATCH)
     */
    hasBody(_config) {
        return this.method === 'POST' || this.method === 'PUT' || this.method === 'PATCH';
    }
    /**
     * Validate configuration before execution
     *
     * @param config - Action configuration to validate
     * @throws CatalystError if configuration is invalid
     */
    validateConfig(config) {
        if (!config.url) {
            const actionType = this.constructor.actionType;
            throw new errors_1.CatalystError('Missing required configuration property: url', 'HttpConfigInvalid', `The ${actionType} action requires a 'url' property in the config. Provide a valid HTTP/HTTPS URL.`);
        }
        if (config.timeout !== undefined && config.timeout < 0) {
            throw new errors_1.CatalystError('Invalid timeout value: must be >= 0', 'HttpConfigInvalid', `The timeout value must be a positive number (in milliseconds). Provided: ${config.timeout}`);
        }
        try {
            new URL(config.url);
        }
        catch (error) {
            throw new errors_1.CatalystError(`Invalid URL format: ${config.url}`, 'HttpConfigInvalid', `The URL '${config.url}' is not a valid HTTP/HTTPS URL. URLs must start with http:// or https:// and include a hostname.`, error);
        }
    }
    /**
     * Handle errors and convert to PlaybookActionResult
     *
     * @param error - Error that occurred
     * @param config - Action configuration
     * @returns PlaybookActionResult with error details
     */
    handleError(error, config) {
        const maskedUrl = (0, masking_1.maskSensitiveUrlParams)(config.url);
        // If already a CatalystError, return it
        if (error instanceof errors_1.CatalystError) {
            return {
                code: error.code,
                message: `HTTP ${this.method} request to ${maskedUrl} failed: ${error.message}`,
                error
            };
        }
        // Otherwise, wrap in generic error
        const catalystError = new errors_1.CatalystError(`HTTP ${this.method} request failed: ${error.message}`, 'HttpRequestFailed', `An unexpected error occurred during the HTTP ${this.method} request to ${maskedUrl}. See error details for more information.`, error);
        return {
            code: catalystError.code,
            message: catalystError.message,
            error: catalystError
        };
    }
}
exports.HttpActionBase = HttpActionBase;
/**
 * Primary property for YAML shorthand syntax
 * All HTTP actions use 'url' as the primary property
 */
HttpActionBase.primaryProperty = 'url';
//# sourceMappingURL=base-http-action.js.map
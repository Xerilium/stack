"use strict";
// @req FR:playbook-actions-io/http.get-action.implementation
// @req NFR:playbook-actions-io/maintainability.single-responsibility
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpGetAction = void 0;
const base_http_action_1 = require("./base-http-action");
/**
 * HTTP GET action
 *
 * Executes HTTP GET requests with retry logic, timeout enforcement,
 * and comprehensive error handling.
 *
 * @example
 * ```typescript
 * const action = new HttpGetAction();
 * const result = await action.execute({
 *   url: 'https://api.example.com/users/123',
 *   headers: { 'Authorization': 'Bearer token' },
 *   timeout: 30000,
 *   retries: 3
 * });
 * ```
 */
class HttpGetAction extends base_http_action_1.HttpActionBase {
    constructor() {
        super(...arguments);
        this.method = 'GET';
    }
}
exports.HttpGetAction = HttpGetAction;
HttpGetAction.actionType = 'http-get';
//# sourceMappingURL=get-action.js.map
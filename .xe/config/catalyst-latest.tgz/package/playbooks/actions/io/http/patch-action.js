"use strict";
// @req FR:playbook-actions-io/http.patch-action.implementation
// @req NFR:playbook-actions-io/maintainability.single-responsibility
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpPatchAction = void 0;
const base_http_action_1 = require("./base-http-action");
/**
 * HTTP PATCH action
 *
 * Executes HTTP PATCH requests with request body support, retry logic,
 * timeout enforcement, and comprehensive error handling.
 *
 * @example
 * ```typescript
 * const action = new HttpPatchAction();
 * const result = await action.execute({
 *   url: 'https://api.example.com/users/123',
 *   headers: { 'Authorization': 'Bearer token' },
 *   body: { email: 'patched@example.com' },
 *   timeout: 30000,
 *   retries: 3
 * });
 * ```
 */
class HttpPatchAction extends base_http_action_1.HttpActionBase {
    constructor() {
        super(...arguments);
        this.method = 'PATCH';
    }
}
exports.HttpPatchAction = HttpPatchAction;
HttpPatchAction.actionType = 'http-patch';
//# sourceMappingURL=patch-action.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpDeleteAction = void 0;
const base_http_action_1 = require("./base-http-action");
/**
 * HTTP DELETE action
 *
 * Executes HTTP DELETE requests with optional request body support, retry logic,
 * timeout enforcement, and comprehensive error handling.
 *
 * @req FR:playbook-actions-io/http.delete-action.implementation
 * @req NFR:playbook-actions-io/maintainability.single-responsibility
 *
 * @example
 * ```typescript
 * const action = new HttpDeleteAction();
 * const result = await action.execute({
 *   url: 'https://api.example.com/users/123',
 *   headers: { 'Authorization': 'Bearer token' },
 *   timeout: 30000,
 *   retries: 3
 * });
 * ```
 */
class HttpDeleteAction extends base_http_action_1.HttpActionBase {
    constructor() {
        super(...arguments);
        this.method = 'DELETE';
    }
}
exports.HttpDeleteAction = HttpDeleteAction;
HttpDeleteAction.actionType = 'http-delete';
//# sourceMappingURL=delete-action.js.map
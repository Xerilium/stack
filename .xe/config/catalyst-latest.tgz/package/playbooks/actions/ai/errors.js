"use strict";
/**
 * Error factory functions for AI prompt action
 *
 * Provider errors are in ai-provider feature (src/ai/providers/errors.ts)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIPromptErrors = void 0;
const errors_1 = require("../../../core/errors");
/**
 * Error factories for AIPromptAction
 *
 * @req FR:playbook-actions-ai/ai-prompt.validation
 * @req FR:playbook-actions-ai/ai-prompt.timeout.error
 * @req NFR:playbook-actions-ai/maintain.consistency
 */
exports.AIPromptErrors = {
    /**
     * Missing prompt property error
     *
     * @req FR:playbook-actions-ai/ai-prompt.validation.prompt-missing
     */
    promptMissing: () => {
        return new errors_1.CatalystError('AI prompt action requires prompt property', 'AIPromptMissing', 'Provide a prompt string in the ai-prompt action configuration');
    },
    /**
     * Empty prompt string error
     *
     * @req FR:playbook-actions-ai/ai-prompt.validation.prompt-empty
     */
    promptEmpty: () => {
        return new errors_1.CatalystError('AI prompt cannot be empty', 'AIPromptEmpty', 'Provide a non-empty prompt string');
    },
    /**
     * Invalid timeout value error
     *
     * @req FR:playbook-actions-ai/ai-prompt.validation.timeout-invalid
     */
    timeoutInvalid: (value) => {
        return new errors_1.CatalystError(`Invalid inactivity timeout: ${value}`, 'InvalidAITimeout', 'Timeout must be a non-negative number in milliseconds');
    },
    /**
     * Inactivity timeout exceeded error
     *
     * @req FR:playbook-actions-ai/ai-prompt.timeout.error
     */
    timeout: (timeoutMs) => {
        return new errors_1.CatalystError(`AI request timed out after ${timeoutMs}ms of inactivity`, 'AIPromptTimeout', 'Increase inactivityTimeout or check if AI is responding');
    },
    /**
     * Output file not created error
     */
    outputFileMissing: (filePath) => {
        return new errors_1.CatalystError(`AI did not write output to expected file: ${filePath}`, 'AIOutputFileMissing', 'AI was instructed to write output to a file but the file was not created');
    }
};
//# sourceMappingURL=errors.js.map
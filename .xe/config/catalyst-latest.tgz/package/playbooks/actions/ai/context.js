"use strict";
/**
 * Context assembly utilities for AI prompts
 *
 * Handles writing context values to temporary files and generating
 * prompt instructions that reference those files.
 *
 * Context values can be either:
 * - File paths: If the value looks like a path and the file exists, use it directly
 * - Literal content: Written to a temporary file to avoid formatting conflicts
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.assembleContext = assembleContext;
exports.assembleReturnInstruction = assembleReturnInstruction;
exports.cleanupTempFiles = cleanupTempFiles;
exports.readOutputFile = readOutputFile;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const os = __importStar(require("os"));
const crypto_1 = require("crypto");
/**
 * Check if a string could be a file path
 *
 * Multi-line strings are never file paths.
 * Single-line strings are potential file paths (including single-word like "LICENSE").
 *
 * @param value - String to check
 * @returns True if the string could be a file path (single line)
 *
 * @req FR:playbook-actions-ai/ai-prompt.context.detection
 */
function couldBeFilePath(value) {
    // Multi-line strings are never file paths
    return !value.includes('\n');
}
/**
 * Check if a file exists at the given path
 *
 * @param filePath - Path to check
 * @returns True if file exists and is accessible
 */
async function fileExists(filePath) {
    try {
        await fs.access(filePath);
        return true;
    }
    catch {
        return false;
    }
}
/**
 * Assemble context values into temporary files and generate instruction block
 *
 * All context values are written to temporary files to avoid formatting conflicts.
 * Context may contain Markdown, XML, JSON, or code that could conflict with prompt formatting.
 *
 * @param context - Dictionary of name-value pairs (may be undefined or empty)
 * @returns Promise resolving to instruction block and cleanup file list
 *
 * @example
 * ```typescript
 * const { instruction, cleanupFiles } = await assembleContext({
 *   'source-code': fileContent,
 *   'requirements': specText
 * });
 * // instruction = "## Context Files\n\nReview the following files..."
 * // cleanupFiles = ['/tmp/catalyst-context-source-code-xxx.txt', ...]
 * ```
 *
 * @req FR:playbook-actions-ai/ai-prompt.context
 * @req FR:playbook-actions-ai/ai-prompt.context.detection
 * @req FR:playbook-actions-ai/ai-prompt.context.files
 * @req FR:playbook-actions-ai/ai-prompt.context.instruction
 * @req FR:playbook-actions-ai/ai-prompt.context.position
 */
async function assembleContext(context) {
    if (!context || Object.keys(context).length === 0) {
        return { instruction: '', cleanupFiles: [] };
    }
    const cleanupFiles = [];
    const fileEntries = [];
    for (const [name, value] of Object.entries(context)) {
        // @req FR:playbook-actions-ai/ai-prompt.context.detection
        if (typeof value === 'string' && couldBeFilePath(value) && await fileExists(value)) {
            // Use existing file directly - no cleanup needed
            fileEntries.push(`- ${name}: ${value}`);
        }
        else {
            // @req FR:playbook-actions-ai/ai-prompt.context.files
            const safeName = name.replace(/[^a-zA-Z0-9-_]/g, '_');
            const filePath = path.join(os.tmpdir(), `catalyst-context-${safeName}-${(0, crypto_1.randomUUID)()}.txt`);
            const content = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
            await fs.writeFile(filePath, content, 'utf-8');
            cleanupFiles.push(filePath);
            fileEntries.push(`- ${name}: ${filePath}`);
        }
    }
    // @req FR:playbook-actions-ai/ai-prompt.context.instruction
    const instruction = `## Context Files

Review the following files for context before proceeding:
${fileEntries.join('\n')}

`;
    return { instruction, cleanupFiles };
}
/**
 * Assemble return value instruction and create output file path
 *
 * When a return value is specified, behavior depends on provider type:
 * - Interactive providers (can write files): instruction tells AI to write to a temp file
 * - Headless providers (SDK-based): instruction tells AI to respond with only the output
 *
 * @param returnDesc - Description of expected return value (may be undefined or empty)
 * @param headless - Whether the provider is headless (SDK-based, no filesystem access)
 * @returns Instruction block and output file path (null if headless or no return specified)
 *
 * @example
 * ```typescript
 * // Interactive provider with return specified
 * const { instruction, outputFile } = assembleReturnInstruction(
 *   'A JSON array of security concerns.', false
 * );
 * // outputFile = '/tmp/catalyst-output-xxx.txt'
 *
 * // Headless provider with return specified
 * const { instruction, outputFile } = assembleReturnInstruction(
 *   'A JSON array of security concerns.', true
 * );
 * // outputFile = null (response.content is used directly)
 * ```
 *
 * @req FR:playbook-actions-ai/ai-prompt.return
 * @req FR:playbook-actions-ai/ai-prompt.return.file
 * @req FR:playbook-actions-ai/ai-prompt.return.empty
 */
function assembleReturnInstruction(returnDesc, headless = false) {
    // @req FR:playbook-actions-ai/ai-prompt.return.empty
    if (!returnDesc?.trim()) {
        return { instruction: '', outputFile: null };
    }
    // @req FR:playbook-actions-ai/ai-prompt.return
    if (headless) {
        // Headless providers return content in the response — no file needed.
        // Constrain the AI to respond with only the requested output.
        const instruction = `
## Required Output

${returnDesc}

IMPORTANT: Respond with ONLY the requested output above. Do not include any commentary, explanation, or conversational text. Your entire response must be the output and nothing else.
`;
        return { instruction, outputFile: null };
    }
    // @req FR:playbook-actions-ai/ai-prompt.return.file
    // Interactive providers can write files directly
    const outputFile = path.join(os.tmpdir(), `catalyst-output-${(0, crypto_1.randomUUID)()}.txt`);
    const instruction = `
## Required Output

${returnDesc}

IMPORTANT: Write your output to: ${outputFile}
`;
    return { instruction, outputFile };
}
/**
 * Clean up temporary files created during context/return assembly
 *
 * Silently ignores errors if files don't exist or can't be deleted.
 *
 * @param files - Array of file paths to delete
 */
async function cleanupTempFiles(files) {
    for (const file of files) {
        try {
            await fs.unlink(file);
        }
        catch {
            // Ignore errors - file may not exist or may have been cleaned up already
        }
    }
}
/**
 * Read output file contents for return value extraction
 *
 * @param outputFile - Path to output file
 * @returns File contents as string, or null if file doesn't exist
 */
async function readOutputFile(outputFile) {
    try {
        const content = await fs.readFile(outputFile, 'utf-8');
        return content;
    }
    catch {
        return null;
    }
}
//# sourceMappingURL=context.js.map
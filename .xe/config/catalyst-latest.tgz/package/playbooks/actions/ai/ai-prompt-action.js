"use strict";
/**
 * AI Prompt Action implementation
 *
 * Executes AI prompts using configured providers with role-based system prompts,
 * context file assembly, and return value extraction via output files.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIPromptAction = void 0;
const errors_1 = require("./errors");
const logging_1 = require("../../../core/logging");
const roles_1 = require("./roles");
const context_1 = require("./context");
const factory_1 = require("../../../ai/providers/factory");
// @req FR:playbook-actions-ai/ai-prompt.timeout.default
const DEFAULT_INACTIVITY_TIMEOUT = 300000;
// @req FR:playbook-actions-ai/ai-prompt.provider-resolution
const DEFAULT_PROVIDER = 'claude';
/**
 * AI Prompt Action
 *
 * Executes AI prompts with:
 * - Role-based system prompt generation (known roles or custom)
 * - Context file assembly (writes values to temp files)
 * - Return value extraction via output files
 * - Inactivity-based timeout handling
 *
 * @example
 * ```typescript
 * const action = new AIPromptAction();
 *
 * const result = await action.execute({
 *   prompt: 'Analyze this code for security issues.',
 *   role: 'Architect',
 *   context: { 'source-code': fileContent },
 *   return: 'A list of security vulnerabilities found.'
 * });
 *
 * console.log(result.value); // Contents of output file
 * ```
 *
 * @req FR:playbook-actions-ai/ai-prompt.config
 */
class AIPromptAction {
    constructor() {
        /**
         * Playbook owner for default role resolution
         * Set by the engine before execution
         */
        this.playbookOwner = 'Engineer';
    }
    /**
     * Set the playbook owner for default role resolution
     *
     * Called by the engine before execute() to provide context.
     *
     * @param owner - Playbook owner property value
     */
    setPlaybookOwner(owner) {
        this.playbookOwner = owner;
    }
    /**
     * Execute the AI prompt action
     *
     * @param config - Action configuration
     * @returns Promise resolving to action result
     *
     * @req FR:playbook-actions-ai/ai-prompt.role
     * @req FR:playbook-actions-ai/ai-prompt.context
     * @req FR:playbook-actions-ai/ai-prompt.context.position
     * @req FR:playbook-actions-ai/ai-prompt.return
     * @req FR:playbook-actions-ai/ai-prompt.result
     * @req FR:playbook-actions-ai/ai-prompt.provider-resolution
     * @req FR:playbook-actions-ai/ai-prompt.timeout.default
     * @req NFR:playbook-actions-ai/reliability.errors
     */
    async execute(config) {
        const logger = logging_1.LogManager.framework();
        this.validateConfig(config);
        const filesToCleanup = [];
        try {
            // @req FR:playbook-actions-ai/ai-prompt.provider-resolution
            const providerName = config.provider || DEFAULT_PROVIDER;
            const provider = (0, factory_1.createAIProvider)(providerName);
            const isHeadless = provider.capabilities.includes('headless');
            // @req FR:playbook-actions-ai/ai-prompt.role
            const systemPrompt = (0, roles_1.resolveSystemPrompt)(config.role, this.playbookOwner);
            logger.debug('AIPromptAction', 'Execute', 'Executing AI prompt', { role: config.role || this.playbookOwner, provider: providerName, headless: isHeadless });
            logger.trace('AIPromptAction', 'Execute', 'System prompt', { systemPrompt: systemPrompt.substring(0, 200) });
            // @req FR:playbook-actions-ai/ai-prompt.context.position
            const { instruction: contextInstruction, cleanupFiles: contextFiles } = await (0, context_1.assembleContext)(config.context);
            filesToCleanup.push(...contextFiles);
            logger.trace('AIPromptAction', 'Execute', 'Context assembled', { contextFileCount: contextFiles.length });
            // Headless providers use response content directly; interactive providers write to a file
            const { instruction: returnInstruction, outputFile } = (0, context_1.assembleReturnInstruction)(config.return, isHeadless);
            if (outputFile) {
                filesToCleanup.push(outputFile);
            }
            // @req FR:playbook-actions-ai/ai-prompt.context.position
            const prompt = contextInstruction + config.prompt + returnInstruction;
            logger.trace('AIPromptAction', 'Execute', 'Final prompt', { promptLength: prompt.length, hasReturn: !!config.return });
            // @req FR:playbook-actions-ai/ai-prompt.timeout.activity
            // @req FR:playbook-actions-ai/ai-prompt.timeout.cancel
            // @req NFR:playbook-actions-ai/reliability.timeout
            const request = {
                model: config.model,
                systemPrompt,
                prompt,
                maxTokens: config.maxTokens,
                inactivityTimeout: config.inactivityTimeout ?? DEFAULT_INACTIVITY_TIMEOUT
            };
            logger.verbose('AIPromptAction', 'Execute', 'Executing provider', { provider: providerName, model: config.model, maxTokens: config.maxTokens });
            const response = await provider.execute(request);
            // @req FR:playbook-actions-ai/ai-prompt.return
            // @req FR:playbook-actions-ai/ai-prompt.result
            let value = null;
            if (outputFile) {
                // Interactive provider: read from the output file it was told to write
                const outputContent = await (0, context_1.readOutputFile)(outputFile);
                if (outputContent !== null) {
                    value = outputContent;
                    logger.trace('AIPromptAction', 'Execute', 'Output file read', { outputFile, contentLength: outputContent.length });
                }
                else {
                    throw errors_1.AIPromptErrors.outputFileMissing(outputFile);
                }
            }
            else if (response.content) {
                // Headless provider or no return: use response content directly
                value = response.content;
            }
            logger.verbose('AIPromptAction', 'Execute', 'Completed', { provider: providerName, hasOutput: value !== null });
            return {
                code: 'Success',
                message: `AI prompt executed successfully using ${providerName}`,
                value,
                error: undefined
            };
        }
        catch (error) {
            logger.debug('AIPromptAction', 'Execute', 'Failed', { error: error.message });
            throw error;
        }
        finally {
            await (0, context_1.cleanupTempFiles)(filesToCleanup);
        }
    }
    /**
     * Validate action configuration
     *
     * @param config - Configuration to validate
     * @throws CatalystError if validation fails
     *
     * @req FR:playbook-actions-ai/ai-prompt.validation
     */
    validateConfig(config) {
        // @req FR:playbook-actions-ai/ai-prompt.validation.prompt-missing
        if (config.prompt === undefined || config.prompt === null) {
            throw errors_1.AIPromptErrors.promptMissing();
        }
        // @req FR:playbook-actions-ai/ai-prompt.validation.prompt-empty
        if (typeof config.prompt !== 'string' || config.prompt.trim() === '') {
            throw errors_1.AIPromptErrors.promptEmpty();
        }
        // @req FR:playbook-actions-ai/ai-prompt.validation.timeout-invalid
        if (config.inactivityTimeout !== undefined &&
            (typeof config.inactivityTimeout !== 'number' ||
                config.inactivityTimeout < 0)) {
            throw errors_1.AIPromptErrors.timeoutInvalid(config.inactivityTimeout);
        }
    }
}
exports.AIPromptAction = AIPromptAction;
/** @req FR:playbook-actions-ai/ai-prompt.metadata */
AIPromptAction.actionType = 'ai-prompt';
/** @req FR:playbook-actions-ai/ai-prompt.metadata */
AIPromptAction.primaryProperty = 'prompt';
//# sourceMappingURL=ai-prompt-action.js.map
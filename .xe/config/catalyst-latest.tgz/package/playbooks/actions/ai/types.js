"use strict";
/**
 * Type definitions for ai-prompt action
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
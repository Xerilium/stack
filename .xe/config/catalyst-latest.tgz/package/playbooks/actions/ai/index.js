"use strict";
/**
 * AI Action exports
 *
 * Public API for the playbook-actions-ai feature.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIPromptErrors = exports.readOutputFile = exports.cleanupTempFiles = exports.assembleReturnInstruction = exports.assembleContext = exports.getKnownRoles = exports.resolveSystemPrompt = exports.AIProviderErrors = exports.resetMockProvider = exports.getMockProvider = exports.getHeadlessProviders = exports.getAvailableAIProviders = exports.createAIProvider = exports.MockAIProvider = exports.AIPromptAction = void 0;
/**
 * Main action
 *
 * @req FR:playbook-actions-ai/ai-prompt.config
 * @req NFR:playbook-actions-ai/maintain.separation
 */
var ai_prompt_action_1 = require("./ai-prompt-action");
Object.defineProperty(exports, "AIPromptAction", { enumerable: true, get: function () { return ai_prompt_action_1.AIPromptAction; } });
var providers_1 = require("../../../ai/providers");
Object.defineProperty(exports, "MockAIProvider", { enumerable: true, get: function () { return providers_1.MockAIProvider; } });
// Factory functions (re-exported from ai-provider)
var providers_2 = require("../../../ai/providers");
Object.defineProperty(exports, "createAIProvider", { enumerable: true, get: function () { return providers_2.createAIProvider; } });
Object.defineProperty(exports, "getAvailableAIProviders", { enumerable: true, get: function () { return providers_2.getAvailableAIProviders; } });
Object.defineProperty(exports, "getHeadlessProviders", { enumerable: true, get: function () { return providers_2.getHeadlessProviders; } });
Object.defineProperty(exports, "getMockProvider", { enumerable: true, get: function () { return providers_2.getMockProvider; } });
Object.defineProperty(exports, "resetMockProvider", { enumerable: true, get: function () { return providers_2.resetMockProvider; } });
// Provider errors (re-exported from ai-provider)
var providers_3 = require("../../../ai/providers");
Object.defineProperty(exports, "AIProviderErrors", { enumerable: true, get: function () { return providers_3.AIProviderErrors; } });
// Utility functions
var roles_1 = require("./roles");
Object.defineProperty(exports, "resolveSystemPrompt", { enumerable: true, get: function () { return roles_1.resolveSystemPrompt; } });
Object.defineProperty(exports, "getKnownRoles", { enumerable: true, get: function () { return roles_1.getKnownRoles; } });
var context_1 = require("./context");
Object.defineProperty(exports, "assembleContext", { enumerable: true, get: function () { return context_1.assembleContext; } });
Object.defineProperty(exports, "assembleReturnInstruction", { enumerable: true, get: function () { return context_1.assembleReturnInstruction; } });
Object.defineProperty(exports, "cleanupTempFiles", { enumerable: true, get: function () { return context_1.cleanupTempFiles; } });
Object.defineProperty(exports, "readOutputFile", { enumerable: true, get: function () { return context_1.readOutputFile; } });
// Action errors (ai-prompt specific)
var errors_1 = require("./errors");
Object.defineProperty(exports, "AIPromptErrors", { enumerable: true, get: function () { return errors_1.AIPromptErrors; } });
//# sourceMappingURL=index.js.map
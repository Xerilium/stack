"use strict";
/**
 * GitHub helper functions for legacy playbook scripts
 *
 * Note: These functions are placeholders for mocking in tests.
 * The actual implementations use execSync with `gh` CLI directly
 * in the new-init-issue.ts and new-blueprint-issue.ts scripts.
 *
 * @deprecated This module exists only for test compatibility
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getProjectName = getProjectName;
exports.isGitHubCliAvailable = isGitHubCliAvailable;
exports.findIssue = findIssue;
exports.prepareIssueTemplate = prepareIssueTemplate;
exports.createGitHubIssue = createGitHubIssue;
function getProjectName() {
    throw new Error('Not implemented - use gh CLI directly');
}
function isGitHubCliAvailable() {
    throw new Error('Not implemented - use gh CLI directly');
}
function findIssue(_title) {
    throw new Error('Not implemented - use gh CLI directly');
}
function prepareIssueTemplate(_project) {
    throw new Error('Not implemented - use gh CLI directly');
}
function createGitHubIssue(_title, _body) {
    throw new Error('Not implemented - use gh CLI directly');
}
//# sourceMappingURL=github.js.map
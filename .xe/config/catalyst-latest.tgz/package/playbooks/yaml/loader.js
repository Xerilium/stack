"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.YamlPlaybookLoader = void 0;
exports.registerYamlLoader = registerYamlLoader;
const fs = __importStar(require("fs"));
const fsPromises = __importStar(require("fs/promises"));
const yaml = __importStar(require("js-yaml"));
const playbook_provider_1 = require("../registry/playbook-provider");
const transformer_1 = require("./transformer");
const logging_1 = require("../../core/logging");
const errors_1 = require("../../core/errors");
/**
 * Playbook loader for loading YAML files
 *
 * @req FR:playbook-yaml/provider.interface
 * @req FR:playbook-yaml/provider.existence
 * @req FR:playbook-yaml/provider.transformation
 * @req FR:playbook-yaml/provider.registration
 *
 * Loads playbooks from .yaml and .yml files. Path resolution is handled by
 * PlaybookProvider - this loader just checks file existence and
 * loads/transforms the file if it exists.
 *
 * @see {@link PlaybookLoader} Loader interface
 * @see {@link registerYamlLoader} Registration function
 *
 * @example
 * ```typescript
 * const loader = new YamlPlaybookLoader();
 * loader.supports('/path/to/playbook.yaml')  // true
 * loader.supports('/path/to/playbook.yml')   // true
 * loader.supports('/path/to/playbook.ts')    // false
 *
 * const playbook = await loader.load('/path/to/playbook.yaml');
 * ```
 */
class YamlPlaybookLoader {
    constructor() {
        this.name = 'yaml';
    }
    /**
     * Check if loader can load the specified file path
     *
     * Returns true for paths ending with .yaml or .yml extension.
     *
     * @param identifier - File path (already resolved by PlaybookProvider)
     * @returns true if identifier ends with .yaml or .yml
     */
    supports(identifier) {
        return identifier.endsWith('.yaml') || identifier.endsWith('.yml');
    }
    /**
     * Load and transform YAML playbook file
     *
     * **Flow**:
     * 1. Check if file exists (return undefined if not)
     * 2. Read file content as UTF-8
     * 3. Parse YAML using js-yaml
     * 4. Transform to Playbook interface using YamlTransformer
     * 5. Return playbook or throw error on failure
     *
     * **Error Handling**: Returns undefined only for "file not found".
     * Throws CatalystError for load failures (YAML parse, transform errors).
     *
     * @param identifier - File path to load (already resolved by PlaybookProvider)
     * @returns Playbook if loaded successfully, undefined if file not found
     * @throws {CatalystError} If file exists but fails to load (parse/transform error)
     */
    async load(identifier) {
        const logger = logging_1.LogManager.framework();
        // Check file exists - return undefined to allow loader chain to continue
        if (!fs.existsSync(identifier)) {
            logger.trace('YamlPlaybookLoader', 'Load', 'YAML file not found', { path: identifier });
            return undefined;
        }
        logger.debug('YamlPlaybookLoader', 'Load', 'Loading YAML playbook', { path: identifier });
        try {
            // Read file content
            const content = await fsPromises.readFile(identifier, 'utf-8');
            // Parse YAML
            const yamlContent = yaml.load(content);
            // Transform to Playbook interface
            const playbook = (0, transformer_1.transformPlaybook)(yamlContent);
            logger.trace('YamlPlaybookLoader', 'Load', 'YAML playbook loaded', { name: playbook.name, steps: playbook.steps?.length });
            return playbook;
        }
        catch (error) {
            // File exists but failed to load - throw error with details
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new errors_1.CatalystError(`Failed to load playbook "${identifier}": ${errorMessage}`, 'PlaybookLoadFailed', 'Check the playbook YAML syntax and structure.', error instanceof Error ? error : undefined);
        }
    }
}
exports.YamlPlaybookLoader = YamlPlaybookLoader;
/**
 * Register YAML loader with PlaybookProvider
 *
 * @req FR:playbook-yaml/provider.registration - Registers provider with PlaybookProvider
 * @req FR:playbook-yaml/provider.initialization - Called during application startup
 *
 * Called by generated initialization code during application startup.
 * Creates YamlPlaybookLoader instance and registers with singleton provider.
 *
 * @example
 * ```typescript
 * // In generated registry/initialize-providers.ts
 * import { registerYamlLoader } from '../yaml/provider';
 *
 * export function initializeProviders() {
 *   registerYamlLoader();
 * }
 * ```
 */
function registerYamlLoader() {
    const provider = playbook_provider_1.PlaybookProvider.getInstance();
    provider.register(new YamlPlaybookLoader());
}
//# sourceMappingURL=loader.js.map
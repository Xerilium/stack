"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseYAML = parseYAML;
const yaml = __importStar(require("js-yaml"));
/**
 * Parse YAML content to JavaScript object
 *
 * @req FR:playbook-yaml/parsing.library
 * @req FR:playbook-yaml/parsing.errors
 * @req FR:playbook-yaml/structure.encoding
 * @req NFR:playbook-yaml/reliability.errors
 *
 * @param yamlContent - YAML string to parse
 * @returns Parsed JavaScript object
 * @throws Error with line/column details on syntax errors
 */
function parseYAML(yamlContent) {
    if (!yamlContent || yamlContent.trim().length === 0) {
        throw new Error('YAML content is empty');
    }
    try {
        const parsed = yaml.load(yamlContent, {
            // Safe loading - no arbitrary code execution
            schema: yaml.DEFAULT_SCHEMA,
            // Include position information for error reporting
            filename: 'playbook.yaml',
        });
        if (parsed === null || parsed === undefined) {
            throw new Error('YAML content is empty or invalid');
        }
        return parsed;
    }
    catch (err) {
        if (err instanceof yaml.YAMLException) {
            // Enhance error message with line/column information
            const line = err.mark?.line !== undefined ? err.mark.line + 1 : 'unknown';
            const column = err.mark?.column !== undefined ? err.mark.column + 1 : 'unknown';
            throw new Error(`YAML syntax error at line ${line}, column ${column}: ${err.reason || err.message}`);
        }
        throw err;
    }
}
//# sourceMappingURL=parser.js.map
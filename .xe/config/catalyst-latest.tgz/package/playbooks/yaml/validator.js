"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidationError = void 0;
exports.validatePlaybook = validatePlaybook;
const ajv_1 = __importDefault(require("ajv"));
const fs = __importStar(require("fs"));
/**
 * Custom error class for validation failures
 *
 * @req NFR:playbook-yaml/reliability.errors
 * @req NFR:playbook-yaml/reliability.context
 */
class ValidationError extends Error {
    constructor(message, filePath, line, column, errors) {
        super(message);
        this.filePath = filePath;
        this.line = line;
        this.column = column;
        this.errors = errors;
        this.name = 'ValidationError';
    }
}
exports.ValidationError = ValidationError;
/**
 * Schema validator singleton
 */
class SchemaValidator {
    constructor() {
        this.validateFn = null;
        this.ajv = new ajv_1.default({
            allErrors: true,
            verbose: true,
            strict: false,
        });
    }
    /**
     * Load and compile schema
     *
     * Schema location: Always loads from node_modules/@xerilium/catalyst/playbooks/schema.json
     *
     * Build process copies dist → node_modules, so schema is always available at this location
     * for both local development and installed packages.
     */
    loadSchema() {
        if (this.validateFn) {
            return; // Already loaded
        }
        // Always load from node_modules (build copies dist → node_modules)
        const schemaPath = require.resolve('@xerilium/catalyst/playbooks/schema.json');
        const schemaContent = fs.readFileSync(schemaPath, 'utf-8');
        const schema = JSON.parse(schemaContent);
        this.validateFn = this.ajv.compile(schema);
    }
    /**
     * Validate playbook object against schema
     *
     * @param playbook - Parsed playbook object
     * @returns ValidationResult with errors if invalid
     */
    validate(playbook) {
        this.loadSchema();
        const valid = this.validateFn(playbook);
        if (valid) {
            return { valid: true };
        }
        const errors = this.formatErrors(this.validateFn.errors || []);
        return {
            valid: false,
            errors,
        };
    }
    /**
     * Format ajv errors into readable validation error details
     */
    formatErrors(ajvErrors) {
        return ajvErrors.map(err => {
            const path = err.instancePath || err.schemaPath || 'root';
            let message = err.message || 'Validation failed';
            // Enhance message with parameter details
            if (err.params) {
                if (err.keyword === 'required') {
                    message = `Property '${err.params.missingProperty}' is required`;
                }
                else if (err.keyword === 'type') {
                    message = `Property should be ${err.params.type}, got ${typeof err.data}`;
                }
                else if (err.keyword === 'pattern') {
                    message = `Property does not match pattern: ${err.params.pattern}`;
                }
                else if (err.keyword === 'minItems') {
                    message = `Array must have at least ${err.params.limit} items`;
                }
            }
            return {
                path: path.replace(/^\//, ''),
                message,
            };
        });
    }
}
// Singleton instance
const validator = new SchemaValidator();
/**
 * Validate playbook object against JSON Schema
 *
 * @req FR:playbook-yaml/parsing.validation
 * @req FR:playbook-yaml/schema.file
 * @req NFR:playbook-yaml/performance.validation
 * @req NFR:playbook-yaml/reliability.context
 *
 * @param playbook - Parsed playbook object to validate
 * @returns ValidationResult with success status and optional errors
 */
function validatePlaybook(playbook) {
    return validator.validate(playbook);
}
//# sourceMappingURL=validator.js.map
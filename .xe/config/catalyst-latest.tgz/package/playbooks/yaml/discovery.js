"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaybookDiscovery = void 0;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const glob_1 = require("glob");
const logging_1 = require("../../core/logging");
/**
 * Playbook discovery service
 *
 * @req FR:playbook-yaml/discovery.locations
 * @req FR:playbook-yaml/discovery.extension
 * @req FR:playbook-yaml/discovery.performance
 * @req FR:playbook-yaml/discovery.naming
 * @req NFR:playbook-yaml/performance.discovery
 *
 * Discovers playbook YAML files in package and custom directories.
 * Scans both `playbooks/` (package playbooks) and `.xe/playbooks/` (custom playbooks).
 *
 * @example
 * ```typescript
 * const discovery = new PlaybookDiscovery();
 * const playbookPaths = await discovery.discover();
 *
 * console.log(`Found ${playbookPaths.length} playbooks`);
 *
 * // Load each discovered playbook
 * const loader = new PlaybookLoader();
 * for (const path of playbookPaths) {
 *   const playbook = await loader.load(path);
 *   console.log(`- ${playbook.name}: ${playbook.description}`);
 * }
 * ```
 */
class PlaybookDiscovery {
    constructor() {
        // Define search paths
        this.searchPaths = [
            path.join(process.cwd(), 'playbooks'), // Package playbooks
            path.join(process.cwd(), '.xe/playbooks'), // Custom playbooks
        ];
    }
    /**
     * Discover all playbook YAML files
     *
     * Scans package (playbooks/) and custom (.xe/playbooks/) directories
     * for .yaml files.
     *
     * @returns Array of absolute paths to playbook files, sorted alphabetically
     */
    async discover() {
        const logger = logging_1.LogManager.framework();
        const allPaths = [];
        logger.debug('PlaybookDiscovery', 'Discover', 'Discovering playbooks', { searchPaths: this.searchPaths });
        for (const searchPath of this.searchPaths) {
            try {
                // Check if directory exists
                await fs.access(searchPath);
                // Glob for .yaml files
                const pattern = path.join(searchPath, '**/*.yaml');
                const files = await (0, glob_1.glob)(pattern, {
                    absolute: true,
                    nodir: true,
                });
                logger.trace('PlaybookDiscovery', 'Discover', 'Found playbooks in path', { path: searchPath, count: files.length });
                allPaths.push(...files);
            }
            catch (err) {
                // Directory doesn't exist, skip silently
                logger.trace('PlaybookDiscovery', 'Discover', 'Playbook directory not found', { path: searchPath });
                continue;
            }
        }
        // Remove duplicates and sort
        const uniquePaths = Array.from(new Set(allPaths));
        uniquePaths.sort();
        logger.debug('PlaybookDiscovery', 'Discover', 'Playbook discovery complete', { total: uniquePaths.length });
        return uniquePaths;
    }
}
exports.PlaybookDiscovery = PlaybookDiscovery;
//# sourceMappingURL=discovery.js.map
"use strict";
/**
 * Template Engine Core
 *
 * Provides secure template interpolation with dual syntax:
 * - {{variable}} for simple string substitution
 * - ${{ expression }} for JavaScript expression evaluation
 *
 * Security features:
 * - Context sanitization (prototype pollution prevention)
 * - Expression sandboxing (no eval/require)
 * - Secret masking (prevent exposure in output/errors)
 * - Path traversal prevention
 * - Expression timeout protection
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TemplateEngine = void 0;
const fs = __importStar(require("fs"));
const jse_eval_1 = require("jse-eval");
const errors_1 = require("../../core/errors");
const logging_1 = require("../../core/logging");
const sanitizer_1 = require("./sanitizer");
const secret_manager_1 = require("./secret-manager");
const path_resolver_1 = require("./path-resolver");
const module_loader_1 = require("./module-loader");
const PROTOCOL_PREFIX_RE = /^(xe|catalyst|temp):\/\//;
/**
 * Template Engine for secure string interpolation and expression evaluation.
 *
 * @req FR:playbook-template-engine/interface
 */
class TemplateEngine {
    constructor() {
        this.secretManager = new secret_manager_1.SecretManager();
        this.pathResolver = new path_resolver_1.PathProtocolResolver();
        this.moduleLoader = new module_loader_1.ModuleLoader();
        this.customFunctions = new Map();
    }
    /**
     * Interpolates a template string with the given context.
     *
     * Processing order (per FR-4.2):
     * 1. Resolve raw path protocols (xe://, catalyst://, temp://) anywhere in string
     * 2. Evaluate ${{ expressions }} (with timeout)
     * 3. Replace {{variables}} and {{protocols}} in brackets
     * 4. Mask secrets in output
     *
     * @param template - Template string with {{}} and/or ${{}} syntax
     * @param context - Context object for variable/expression evaluation
     * @returns Interpolated string with secrets masked
     * @throws CatalystError on syntax errors, undefined variables, or timeouts
     *
     * @req FR:playbook-template-engine/interface.methods
     * @req FR:playbook-template-engine/syntax.dual
     * @req FR:playbook-template-engine/syntax.dual.simple
     * @req FR:playbook-template-engine/syntax.dual.js
     * @req FR:playbook-template-engine/syntax.timing
     * @req FR:playbook-template-engine/syntax.runtime
     * @req NFR:playbook-template-engine/performance
     * @req NFR:playbook-template-engine/security
     */
    async interpolate(template, context) {
        try {
            // Sanitize context to prevent security issues
            const safeContext = (0, sanitizer_1.sanitizeContext)(context);
            // Step 0: Protect escaped template markers (\{{ → sentinel, \}} → sentinel)
            // @req FR:playbook-template-engine/syntax.escape
            // @req FR:playbook-template-engine/syntax.escape.passthrough
            let result = template.replace(/\\{{/g, '__TMPL_ESC_OPEN__');
            result = result.replace(/\\}}/g, '__TMPL_ESC_CLOSE__');
            // Step 1: Resolve raw path protocols (xe://, catalyst://, temp://) anywhere in string
            result = await this.resolveRawProtocols(result);
            // Step 2: Evaluate ${{ expressions }}
            result = await this.evaluateExpressions(result, safeContext);
            // Step 3: Replace {{variables}} and {{protocols}} in brackets
            result = await this.interpolateVariablesAndProtocols(result, safeContext);
            // Step 4: Mask secrets in output
            result = this.secretManager.mask(result);
            // Step 5: Restore escaped template markers (sentinel → {{ and }})
            // @req FR:playbook-template-engine/syntax.escape.syntax
            result = result.replace(/__TMPL_ESC_OPEN__/g, '{{');
            result = result.replace(/__TMPL_ESC_CLOSE__/g, '}}');
            return result;
        }
        catch (error) {
            // Determine error code
            let code = 'TemplateError';
            if (error.message.includes('InvalidStringTemplate'))
                code = 'InvalidStringTemplate';
            if (error.message.includes('InvalidExpressionTemplate'))
                code = 'InvalidExpressionTemplate';
            if (error.message.includes('ExpressionTimeout'))
                code = 'ExpressionTimeout';
            if (error.message.includes('InvalidProtocol'))
                code = 'InvalidProtocol';
            // Mask secrets in error messages
            const maskedMessage = this.secretManager.mask(error.message);
            throw new errors_1.CatalystError(maskedMessage, code, 'Check template syntax and context values', error);
        }
    }
    /**
     * Recursively interpolates all string values in an object.
     *
     * @param obj - Object with string values to interpolate
     * @param context - Context for interpolation
     * @param skipKeys - Keys to skip interpolation (e.g., nested steps in control flow)
     * @returns New object with interpolated values
     *
     * @req FR:playbook-template-engine/interface.interpolateObject
     * @req FR:playbook-template-engine/syntax.simple.preserve
     */
    async interpolateObject(obj, context, skipKeys = []) {
        const result = {};
        for (const [key, value] of Object.entries(obj)) {
            // Skip interpolation for specified keys (e.g., nested steps)
            if (skipKeys.includes(key)) {
                result[key] = value;
                continue;
            }
            if (typeof value === 'string') {
                // Check if this is a pure expression (single ${{ ... }} with no other content)
                // If so, return the raw value instead of stringifying it
                const pureExprMatch = value.match(/^\$\{\{(.+?)\}\}$/s);
                if (pureExprMatch && !value.includes('{{', 3)) {
                    // Pure expression - evaluate and return raw value (not stringified)
                    const safeContext = (0, sanitizer_1.sanitizeContext)(context);
                    result[key] = await this.evaluateExpressionWithTimeout(pureExprMatch[1].trim(), safeContext);
                }
                // Check if this is a pure variable reference (single {{variable}} with no other content)
                // If so, return the raw value to preserve type (arrays, objects, numbers, booleans)
                else if (/^\{\{[^}]+\}\}$/.test(value)) {
                    const varName = value.slice(2, -2).trim();
                    const safeContext = (0, sanitizer_1.sanitizeContext)(context);
                    const rawValue = this.getNestedValue(safeContext, varName);
                    if (rawValue !== undefined) {
                        result[key] = rawValue;
                    }
                    else {
                        // Fall through to interpolate() which will throw InvalidStringTemplate
                        result[key] = await this.interpolate(value, context);
                    }
                }
                else {
                    // Mixed content or multiple references - interpolate as string
                    result[key] = await this.interpolate(value, context);
                }
            }
            else if (Array.isArray(value)) {
                // Recursively process arrays
                result[key] = await Promise.all(value.map((item) => typeof item === 'string'
                    ? this.interpolate(item, context)
                    : item !== null && typeof item === 'object'
                        ? this.interpolateObject(item, context, skipKeys)
                        : item));
            }
            else if (value !== null && typeof value === 'object') {
                // Recursively process nested objects
                result[key] = await this.interpolateObject(value, context, skipKeys);
            }
            else {
                // Preserve non-string values
                result[key] = value;
            }
        }
        return result;
    }
    /**
     * Loads custom functions from a JavaScript module alongside the playbook.
     *
     * @param playbookPath - Path to the playbook file
     * @returns Object with exported functions
     *
     * @req FR:playbook-template-engine/syntax.js.function
     */
    async loadModule(playbookPath) {
        const functions = await this.moduleLoader.loadModule(playbookPath);
        // Register functions for use in expressions
        for (const [name, func] of Object.entries(functions)) {
            this.registerFunction(name, func);
        }
        return functions;
    }
    /**
     * Registers a custom function for use in expressions.
     *
     * @param name - Function name
     * @param func - Function implementation
     */
    registerFunction(name, func) {
        this.customFunctions.set(name, func);
    }
    /**
     * Registers a secret for masking.
     *
     * @param name - Secret name (e.g., 'GITHUB_TOKEN')
     * @param value - Secret value to mask
     */
    registerSecret(name, value) {
        this.secretManager.register(name, value);
    }
    /**
     * Evaluates ${{ expression }} blocks in the template.
     *
     * CRITICAL: Expressions must contain valid JavaScript only.
     * {{}} syntax is NOT allowed inside ${{}} expressions.
     *
     * @req FR:playbook-template-engine/syntax.js
     * @req FR:playbook-template-engine/syntax.js.string
     * @req FR:playbook-template-engine/syntax.js.ternary
     * @req FR:playbook-template-engine/syntax.js.negation
     * @req FR:playbook-template-engine/syntax.js.chaining
     * @req FR:playbook-template-engine/syntax.whitespace
     * @req FR:playbook-template-engine/security.sandbox
     * @req FR:playbook-template-engine/security.sandbox.isolation.globals
     * @req NFR:playbook-template-engine/security.sandbox
     */
    async evaluateExpressions(template, context) {
        // Regex to find ${{ expression }} blocks
        const expressionRegex = /\$\{\{(.+?)\}\}/gs;
        let result = template;
        const matches = Array.from(template.matchAll(expressionRegex));
        for (const match of matches) {
            const [fullMatch, expression] = match;
            // CRITICAL: Reject {{}} syntax inside ${{}}
            if (expression.includes('{{') || expression.includes('}}')) {
                throw new Error('InvalidExpressionTemplate: {{}} syntax not allowed inside ${{}} expressions');
            }
            try {
                const logger = logging_1.LogManager.framework();
                logger.debug('TemplateEngine', 'Evaluate', 'Evaluating expression', { expression: expression.trim() });
                // Evaluate expression with timeout protection
                const value = await this.evaluateExpressionWithTimeout(expression.trim(), context);
                logger.trace('TemplateEngine', 'Evaluate', 'Expression result', { expression: expression.trim(), result: value });
                // Replace expression with result - use JSON.stringify for objects/arrays
                const stringValue = (value !== null && typeof value === 'object')
                    ? JSON.stringify(value)
                    : String(value);
                result = result.replace(fullMatch, stringValue);
            }
            catch (error) {
                // Include the expression in the error message for debugging
                const expr = expression.trim();
                const originalError = error.message || String(error);
                // Calculate indent width based on log prefix configuration
                const indentWidth = (0, logging_1.getLogPrefixWidth)('CLI.Main');
                const indent = ' '.repeat(indentWidth);
                // Try to extract position from parse error and show problematic code
                const posMatch = originalError.match(/parse error \[\d+:(\d+)\]/);
                let errorDetail = originalError;
                if (posMatch) {
                    // Parser uses 1-indexed columns, convert to 0-indexed for pointer
                    const col = parseInt(posMatch[1], 10) - 1;
                    // Show the expression with a pointer to where it failed
                    const pointer = ' '.repeat(Math.max(0, col)) + '^';
                    errorDetail = `${originalError}\n${indent}${expr}\n${indent}${pointer}`;
                }
                throw new Error(`InvalidExpressionTemplate: Failed to evaluate "$\{{ ${expr} }}":\n${indent}${errorDetail}`);
            }
        }
        return result;
    }
    /**
     * Evaluates a single expression with timeout protection.
     * Uses jse-eval for full JavaScript expression support including method chaining.
     *
     * @req FR:playbook-template-engine/security.sandbox.timeout.max
     * @req FR:playbook-template-engine/security.sandbox.timeout.error
     * @req FR:playbook-template-engine/security.sandbox.timeout.loops
     * @req NFR:playbook-template-engine/reliability.timeout
     * @req NFR:playbook-template-engine/performance.expression
     */
    async evaluateExpressionWithTimeout(expression, context) {
        const timeout = 10000; // 10 seconds
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                reject(new Error('ExpressionTimeout: Expression took too long to evaluate'));
            }, timeout);
            try {
                // Build evaluation context with get(), logs(), and custom functions
                const evalContext = {
                    // Provide get() function for accessing context variables OR path-protocol file content.
                    // @req FR:playbook-template-engine/paths.usage
                    // @req FR:playbook-template-engine/paths.conditionals.content
                    // @req FR:playbook-template-engine/paths.conditionals.existence
                    // @req FR:playbook-template-engine/paths.conditionals.missing
                    get: (path) => {
                        if (typeof path === 'string' && PROTOCOL_PREFIX_RE.test(path)) {
                            return this.resolveGetProtocolSync(path);
                        }
                        return this.getNestedValue(context, path);
                    },
                    // Provide logs() function for querying captured log entries
                    // @req FR:playbook-template-engine/context.logs
                    // @req FR:playbook-template-engine/context.logs.read
                    // @req FR:playbook-template-engine/context.logs.filter
                    // @req FR:playbook-template-engine/context.logs.security
                    // @req FR:playbook-template-engine/context.logs.empty
                    logs: (filterLevel) => {
                        const allLogs = structuredClone(context['__logs'] ?? []);
                        if (filterLevel) {
                            return allLogs.filter((entry) => entry.level === filterLevel);
                        }
                        return allLogs;
                    },
                    // Spread custom registered functions
                    ...Object.fromEntries(this.customFunctions),
                };
                // Compile and evaluate expression using jse-eval
                const evaluator = (0, jse_eval_1.compile)(expression);
                const result = evaluator(evalContext);
                clearTimeout(timer);
                resolve(result);
            }
            catch (error) {
                clearTimeout(timer);
                reject(error);
            }
        });
    }
    /**
     * Interpolates {{variable}} and {{protocol://}} placeholders in the template.
     *
     * @req FR:playbook-template-engine/syntax.simple
     * @req FR:playbook-template-engine/syntax.simple.resolve
     * @req FR:playbook-template-engine/syntax.simple.preserve
     * @req FR:playbook-template-engine/syntax.simple.conditional
     * @req FR:playbook-template-engine/syntax.simple.yaml
     * @req FR:playbook-template-engine/paths.protocols
     * @req FR:playbook-template-engine/paths.usage
     * @req NFR:playbook-template-engine/performance.overhead
     */
    async interpolateVariablesAndProtocols(template, context) {
        // Validate no unclosed {{
        if (template.includes('{{') && !template.match(/\{\{[^}]*\}\}/)) {
            throw new Error('InvalidStringTemplate: Unclosed {{ bracket');
        }
        // Regex to find {{...}} placeholders
        const regex = /\{\{([^}]+)\}\}/g;
        let result = template;
        const matches = Array.from(template.matchAll(regex));
        for (const match of matches) {
            const [fullMatch, content] = match;
            const trimmedContent = content.trim();
            // Check if this is a protocol reference
            if (trimmedContent.startsWith('xe://') || trimmedContent.startsWith('catalyst://') || trimmedContent.startsWith('temp://')) {
                try {
                    const resolvedPath = await this.pathResolver.resolve(trimmedContent);
                    result = result.replace(fullMatch, resolvedPath);
                }
                catch (error) {
                    throw new Error(`InvalidProtocol: ${error.message}`);
                }
            }
            else {
                // Regular variable substitution
                const value = this.getNestedValue(context, trimmedContent);
                if (value === undefined) {
                    throw new Error(`InvalidStringTemplate: Variable '${trimmedContent}' is undefined`);
                }
                // Convert value to string - use JSON.stringify for objects/arrays
                const stringValue = (value !== null && typeof value === 'object')
                    ? JSON.stringify(value)
                    : String(value);
                result = result.replace(fullMatch, stringValue);
            }
        }
        return result;
    }
    /**
     * Resolves raw path protocols (xe://, catalyst://, temp://) anywhere in the string,
     * EXCEPT inside ${{ ... }} expression blocks — those are left intact so the expression
     * evaluator's get() can resolve them to file content per FR:paths.usage and
     * FR:paths.conditionals.content.
     *
     * Per FR:paths.protocols: "System MUST resolve path protocols in all string values"
     * Per FR:paths.usage: Supports raw paths like `file-read: xe://features/my-feature/spec.md`
     */
    async resolveRawProtocols(template) {
        // Split the template into ${{...}} blocks (preserved as-is) and other segments
        // (where raw protocols get resolved). This keeps get('xe://...') inside expressions
        // visible to the expression evaluator.
        const expressionRegex = /\$\{\{.+?\}\}/gs;
        const segments = [];
        let lastIndex = 0;
        for (const match of template.matchAll(expressionRegex)) {
            if (match.index > lastIndex) {
                segments.push({ text: template.slice(lastIndex, match.index), isExpression: false });
            }
            segments.push({ text: match[0], isExpression: true });
            lastIndex = match.index + match[0].length;
        }
        if (lastIndex < template.length) {
            segments.push({ text: template.slice(lastIndex), isExpression: false });
        }
        // Match xe://, catalyst://, or temp:// optionally followed by path characters (not inside {{}} brackets).
        // Path continues until whitespace, quote, or end of string. The path part is
        // optional — `temp://` alone means the base directory (per FR:paths.protocols.bare).
        const protocolRegex = /(?<!\{\{)\b(xe|catalyst|temp):\/\/([^\s"'}\]]*)/g;
        for (const segment of segments) {
            if (segment.isExpression)
                continue;
            const matches = Array.from(segment.text.matchAll(protocolRegex));
            for (const match of matches) {
                const [fullMatch, protocol, pathPart] = match;
                const protocolPath = `${protocol}://${pathPart}`;
                try {
                    const resolvedPath = await this.pathResolver.resolve(protocolPath);
                    segment.text = segment.text.replace(fullMatch, resolvedPath);
                }
                catch (error) {
                    throw new Error(`InvalidProtocol: ${error.message}`);
                }
            }
        }
        return segments.map(s => s.text).join('');
    }
    /**
     * Resolves a value returned by get() when the argument was a path protocol string.
     * Returns file content (string) if file exists, undefined otherwise — per
     * FR:paths.conditionals.content and FR:paths.conditionals.missing.
     */
    resolveGetProtocolSync(pathOrVar) {
        if (!PROTOCOL_PREFIX_RE.test(pathOrVar))
            return undefined;
        try {
            // pathResolver.resolve is async; we replicate the sync path-construction here
            // because expression evaluation runs synchronously inside jse-eval.
            const resolved = this.pathResolver.resolveSync(pathOrVar);
            if (!fs.existsSync(resolved))
                return undefined;
            return fs.readFileSync(resolved, 'utf-8');
        }
        catch {
            return undefined;
        }
    }
    /**
     * Gets a nested value from an object using dot notation.
     *
     * Example: getNestedValue({ a: { b: 'value' } }, 'a.b') → 'value'
     *
     * @req FR:playbook-template-engine/context.interface
     * @req FR:playbook-template-engine/context.kebab
     * @req FR:playbook-template-engine/context.dot
     * @req FR:playbook-template-engine/context.sources
     * @req NFR:playbook-template-engine/reliability
     */
    getNestedValue(obj, path) {
        const parts = path.split('.');
        let current = obj;
        for (const part of parts) {
            if (current === null || current === undefined) {
                return undefined;
            }
            current = current[part];
        }
        return current;
    }
}
exports.TemplateEngine = TemplateEngine;
//# sourceMappingURL=engine.js.map
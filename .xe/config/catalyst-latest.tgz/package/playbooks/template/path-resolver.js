"use strict";
/**
 * Path Protocol Resolution Module
 *
 * Resolves custom protocol paths (xe://, catalyst://) to filesystem paths.
 * Provides security validation and auto-extension detection.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PathProtocolResolver = void 0;
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
/**
 * Resolves custom protocol paths to filesystem paths.
 *
 * Supported protocols:
 * - xe:// → .xe/ directory (project-local)
 * - catalyst:// → node_modules/@xerilium/catalyst/ (package resources)
 * - temp:// → OS temp directory (platform-agnostic)
 *
 * Security features:
 * - Path traversal prevention (rejects ../)
 * - Absolute path rejection
 * - Extension auto-detection (.md, .json, none)
 *
 * @req FR:playbook-template-engine/paths.protocols.xe
 * @req FR:playbook-template-engine/paths.protocols.catalyst
 * @req FR:playbook-template-engine/paths.protocols.temp
 * @req FR:playbook-template-engine/paths.protocols.extension
 * @req FR:playbook-template-engine/paths.protocols.timing
 * @req FR:playbook-template-engine/paths.conditionals.content
 * @req FR:playbook-template-engine/paths.conditionals.existence
 * @req FR:playbook-template-engine/paths.conditionals.missing
 * @req NFR:playbook-template-engine/performance.path
 */
class PathProtocolResolver {
    constructor() {
        this.protocolMap = new Map([
            ['xe', '.xe'],
            ['catalyst', 'node_modules/@xerilium/catalyst'],
            ['temp', os.tmpdir()],
        ]);
    }
    /**
     * Resolves a protocol path to a filesystem path.
     *
     * @param protocolPath - Path with protocol (e.g., "xe://features/spec.md")
     * @returns Resolved filesystem path
     * @throws Error with code 'InvalidProtocol' on security violations
     */
    async resolve(protocolPath) {
        const basePath = this.resolveBasePath(protocolPath);
        if (basePath === null)
            return protocolPath; // no protocol, return as-is
        return await this.autoDetectExtension(basePath);
    }
    /**
     * Synchronous variant of resolve(), used by the expression evaluator's get()
     * since jse-eval runs synchronously. Same security checks, same extension
     * auto-detection — just uses fs.existsSync instead of fs.promises.access.
     */
    resolveSync(protocolPath) {
        const basePath = this.resolveBasePath(protocolPath);
        if (basePath === null)
            return protocolPath;
        return this.autoDetectExtensionSync(basePath);
    }
    /**
     * Shared validation + base-path construction for resolve() and resolveSync().
     * Returns null if the input has no protocol prefix (caller returns input as-is).
     *
     * A bare protocol with no path part (e.g. `temp://`) resolves to the base
     * directory itself. This is the natural form for directory-targeting actions
     * like file-list.
     */
    resolveBasePath(protocolPath) {
        if (!protocolPath.includes(':'))
            return null;
        // (.*) — allow empty path part. `temp://` is a valid reference to the base dir.
        const match = protocolPath.match(/^(\w+):\/\/(.*)$/);
        if (!match) {
            throw new Error('InvalidProtocol: Malformed protocol syntax');
        }
        const [, protocol, pathPart] = match;
        const baseDir = this.protocolMap.get(protocol);
        if (!baseDir) {
            throw new Error(`InvalidProtocol: Unsupported protocol '${protocol}://'`);
        }
        if (pathPart.includes('..')) {
            throw new Error('InvalidProtocol: Path traversal not allowed');
        }
        if (pathPart.startsWith('/')) {
            throw new Error('InvalidProtocol: Absolute paths not allowed');
        }
        // Bare protocol (e.g. `temp://`) resolves to the base directory.
        const resolvedBase = path.isAbsolute(baseDir)
            ? baseDir
            : path.join(process.cwd(), baseDir);
        return pathPart === '' ? resolvedBase : path.join(resolvedBase, pathPart);
    }
    /**
     * Auto-detects file extension if not provided.
     * Tries: .md → .json → no extension.
     * Skipped when the basePath already points at an existing directory —
     * a directory is the intended target (e.g. for file-list), not a file stub.
     */
    async autoDetectExtension(basePath) {
        if (path.extname(basePath))
            return basePath;
        if (await this.isDirectory(basePath))
            return basePath;
        const mdPath = basePath + '.md';
        if (await this.fileExists(mdPath))
            return mdPath;
        const jsonPath = basePath + '.json';
        if (await this.fileExists(jsonPath))
            return jsonPath;
        return basePath;
    }
    /** Synchronous variant of autoDetectExtension() — same lookup order. */
    autoDetectExtensionSync(basePath) {
        if (path.extname(basePath))
            return basePath;
        if (this.isDirectorySync(basePath))
            return basePath;
        const mdPath = basePath + '.md';
        if (fs.existsSync(mdPath))
            return mdPath;
        const jsonPath = basePath + '.json';
        if (fs.existsSync(jsonPath))
            return jsonPath;
        return basePath;
    }
    async isDirectory(p) {
        try {
            const stat = await fs.promises.stat(p);
            return stat.isDirectory();
        }
        catch {
            return false;
        }
    }
    isDirectorySync(p) {
        try {
            return fs.statSync(p).isDirectory();
        }
        catch {
            return false;
        }
    }
    /**
     * Checks if a file exists.
     */
    async fileExists(filePath) {
        try {
            await fs.promises.access(filePath, fs.constants.F_OK);
            return true;
        }
        catch {
            return false;
        }
    }
}
exports.PathProtocolResolver = PathProtocolResolver;
//# sourceMappingURL=path-resolver.js.map
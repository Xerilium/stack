"use strict";
/**
 * Module Loading Module
 *
 * Dynamically loads custom JavaScript modules alongside playbook files.
 * Provides custom functions for use in template expressions.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModuleLoader = void 0;
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
/**
 * Loads custom JavaScript modules for template functions.
 *
 * Module Discovery:
 * For a playbook at `/path/to/playbook.yaml`, checks for `/path/to/playbook.js`
 *
 * Module Format:
 * ```javascript
 * export function myFunction(arg) { return arg * 2; }
 * export function anotherFunction(a, b) { return a + b; }
 * ```
 *
 * @req FR:playbook-template-engine/modules.autoload
 */
class ModuleLoader {
    /**
     * Loads a JavaScript module from the given playbook path.
     *
     * @param playbookPath - Path to the playbook file (.yaml, .json, etc.)
     * @returns Object with exported functions, or empty object if module not found
     * @throws Error with code 'ModuleLoadError' on syntax errors or invalid exports
     *
     * @req FR:playbook-template-engine/modules.autoload.naming
     * @req FR:playbook-template-engine/modules.autoload.exports
     * @req FR:playbook-template-engine/modules.autoload.timing
     * @req FR:playbook-template-engine/modules.callable
     * @req FR:playbook-template-engine/modules.autoload.errors
     * @req FR:playbook-template-engine/security.modules.isolation
     * @req FR:playbook-template-engine/security.modules.isolation.timeout
     * @req FR:playbook-template-engine/security.modules.isolation.memory
     * @req FR:playbook-template-engine/security.modules.errors.parse
     * @req FR:playbook-template-engine/security.modules.errors.runtime
     * @req FR:playbook-template-engine/security.modules.errors.missing
     * @req NFR:playbook-template-engine/performance.module
     * @req NFR:playbook-template-engine/reliability.graceful
     * @req NFR:playbook-template-engine/devex.typescript
     * @req NFR:playbook-template-engine/devex.linenumbers
     * @req NFR:playbook-template-engine/devex.intellisense
     * @req NFR:playbook-template-engine/devex.errors
     */
    async loadModule(playbookPath) {
        try {
            // Construct module path by replacing extension with .js
            const modulePath = this.getModulePath(playbookPath);
            // Check if module exists
            if (!(await this.fileExists(modulePath))) {
                // Module is optional, return empty object
                return {};
            }
            // Dynamically import the module
            const module = await Promise.resolve(`${modulePath}`).then(s => __importStar(require(s)));
            // Validate exports are functions
            const functions = {};
            for (const [name, value] of Object.entries(module)) {
                if (typeof value === 'function') {
                    functions[name] = value;
                }
            }
            return functions;
        }
        catch (error) {
            // Wrap errors in ModuleLoadError
            throw new Error(`ModuleLoadError: Failed to load module - ${error.message}`);
        }
    }
    /**
     * Constructs the module path from a playbook path.
     *
     * Example: `/path/to/playbook.yaml` → `/path/to/playbook.js`
     */
    getModulePath(playbookPath) {
        const parsed = path.parse(playbookPath);
        return path.join(parsed.dir, `${parsed.name}.js`);
    }
    /**
     * Checks if a file exists.
     */
    async fileExists(filePath) {
        try {
            await fs.promises.access(filePath, fs.constants.F_OK);
            return true;
        }
        catch {
            return false;
        }
    }
}
exports.ModuleLoader = ModuleLoader;
//# sourceMappingURL=module-loader.js.map
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaybookProvider = void 0;
const path = __importStar(require("path"));
const errors_1 = require("../../core/errors");
/**
 * Unified provider for playbooks and actions
 *
 * @req FR:playbook-definition/provider.class
 * @req FR:playbook-definition/provider.search-path
 * @req FR:playbook-definition/provider.loader-order
 * @req FR:playbook-definition/provider.duplicate-prevention
 * @req FR:playbook-definition/provider.action-instantiation
 * @req FR:playbook-definition/provider.action-initialization
 * @req FR:playbook-definition/provider.dependency-injection
 * @req FR:playbook-definition/provider.caching
 * @req NFR:playbook-definition/testability.mockable
 * @req NFR:playbook-definition/testability.abstraction
 *
 * Manages:
 * - Playbook loading via registered loaders (YAML, etc.)
 * - Action instantiation from the action catalog
 * - Caching for both playbooks and action instances
 *
 * Supports dependency injection for testing via constructor parameters.
 *
 * **Usage**:
 * ```typescript
 * // Production: use singleton
 * const provider = PlaybookProvider.getInstance();
 * const playbook = await provider.loadPlaybook('my-playbook');
 * const action = provider.createAction('script', stepExecutor);
 *
 * // Testing: create isolated instance
 * const testProvider = new PlaybookProvider();
 * testProvider.registerAction('mock-action', MockAction);
 * ```
 *
 * @see {@link PlaybookLoader} Loader interface for playbook loading
 * @see {@link ActionMetadata} Metadata structure for actions
 */
class PlaybookProvider {
    /**
     * Create a new PlaybookProvider instance
     *
     * For production use, prefer getInstance() singleton.
     * For testing, create instances directly to isolate test state.
     */
    constructor() {
        // Playbook loader management
        this.loaders = new Map();
        this.loaderOrder = [];
        this.loadersInitialized = false;
        // Action catalog management
        this.actionCatalog = new Map();
        // Caching
        this.playbookCache = new Map();
        /** Search paths for resolving relative playbook names */
        this.searchPaths = [
            '.xe/playbooks',
            'node_modules/@xerilium/catalyst/playbooks'
        ];
        // Instance is ready - loaders and actions registered lazily or via register methods
    }
    /**
     * Get singleton provider instance
     *
     * Initializes loaders and action catalog on first access.
     *
     * @returns The singleton PlaybookProvider instance
     */
    static getInstance() {
        if (!PlaybookProvider.instance) {
            PlaybookProvider.instance = new PlaybookProvider();
        }
        return PlaybookProvider.instance;
    }
    /**
     * Reset singleton instance (testing only)
     *
     * @internal
     */
    static resetInstance() {
        PlaybookProvider.instance = null;
    }
    // ─────────────────────────────────────────────────────────────────────────────
    // Playbook Loading
    // ─────────────────────────────────────────────────────────────────────────────
    /**
     * Load playbook by name or path
     *
     * Automatically initializes loaders on first call if needed.
     * Results are cached - subsequent calls for same identifier return cached playbook.
     *
     * **Path Resolution**:
     * 1. If identifier is absolute or starts with ./ or ../, use as-is
     * 2. Otherwise, resolve against search paths with extension variants
     * 3. Try each candidate path with each loader in registration order
     * 4. Return first successful load
     *
     * @param identifier - Playbook identifier (file path or name)
     * @returns Loaded playbook
     * @throws {CatalystError} If playbook not found
     *
     * @example
     * ```typescript
     * const playbook = await provider.loadPlaybook('deploy-service');
     * const playbook2 = await provider.loadPlaybook('./custom/playbook.yaml');
     * ```
     */
    async loadPlaybook(identifier) {
        // Check cache first
        const cached = this.playbookCache.get(identifier);
        if (cached) {
            return cached;
        }
        // Initialize loaders if not done
        this.initializeLoaders();
        // Load playbook
        const playbook = await this.loadPlaybookInternal(identifier);
        if (!playbook) {
            throw new errors_1.CatalystError(`Playbook "${identifier}" not found`, 'PlaybookNotFound', `Searched paths: ${this.searchPaths.join(', ')}. ` +
                `Registered loaders: ${this.loaderOrder.join(', ') || 'none'}`);
        }
        // Cache and return
        this.playbookCache.set(identifier, playbook);
        return playbook;
    }
    /**
     * Register a playbook loader
     *
     * Loaders are checked in registration order during loadPlaybook().
     * First loader that supports and successfully loads a playbook wins.
     *
     * @param loader - Loader implementation to register
     * @throws {CatalystError} If loader with same name already registered
     */
    registerLoader(loader) {
        if (this.loaders.has(loader.name)) {
            throw new errors_1.CatalystError(`Loader '${loader.name}' is already registered`, 'DuplicateLoaderName', `A loader with name '${loader.name}' has already been registered.`);
        }
        this.loaders.set(loader.name, loader);
        this.loaderOrder.push(loader.name);
    }
    /**
     * Initialize all loaders from generated catalog
     *
     * Called automatically on first loadPlaybook() call.
     * Can be called explicitly to pre-initialize.
     */
    initializeLoaders() {
        if (this.loadersInitialized) {
            return;
        }
        // Import and register loaders from generated catalog
        // Using require to avoid circular dependency issues
        try {
            const { LOADER_CLASSES } = require('./loader-catalog');
            for (const [, LoaderClass] of Object.entries(LOADER_CLASSES)) {
                const loader = new LoaderClass();
                if (!this.loaders.has(loader.name)) {
                    this.registerLoader(loader);
                }
            }
        }
        catch {
            // Loader catalog not generated yet - that's OK for testing
        }
        this.loadersInitialized = true;
    }
    /**
     * Internal playbook loading without caching
     */
    async loadPlaybookInternal(identifier) {
        const candidates = this.resolveCandidates(identifier);
        for (const candidatePath of candidates) {
            for (const loaderName of this.loaderOrder) {
                const loader = this.loaders.get(loaderName);
                if (loader.supports(candidatePath)) {
                    const playbook = await loader.load(candidatePath);
                    if (playbook) {
                        return playbook;
                    }
                }
            }
        }
        return undefined;
    }
    /**
     * Resolve identifier to candidate file paths
     *
     * Candidates are tried in order:
     * 1. Original identifier (for programmatic loaders that match by name)
     * 2. Identifier with .yaml/.yml extensions
     * 3. Search path combinations with extensions
     */
    resolveCandidates(identifier) {
        if (path.isAbsolute(identifier) || identifier.startsWith('./') || identifier.startsWith('../')) {
            return [identifier];
        }
        const candidates = [];
        // First try the identifier as-is (for programmatic loaders)
        candidates.push(identifier);
        // Then try with extensions
        candidates.push(`${identifier}.yaml`);
        candidates.push(`${identifier}.yml`);
        // Finally try search paths
        for (const searchPath of this.searchPaths) {
            const basePath = path.join(searchPath, identifier);
            candidates.push(`${basePath}.yaml`);
            candidates.push(`${basePath}.yml`);
            candidates.push(basePath);
        }
        return candidates;
    }
    // ─────────────────────────────────────────────────────────────────────────────
    // Action Management
    // ─────────────────────────────────────────────────────────────────────────────
    /**
     * Get action metadata
     *
     * @param actionType - Action type identifier (kebab-case)
     * @returns Action metadata or undefined if not found
     *
     * @example
     * ```typescript
     * const info = provider.getActionInfo('script');
     * console.log(info?.configSchema);
     * ```
     */
    getActionInfo(actionType) {
        this.initializeActions();
        return this.actionCatalog.get(actionType)?.metadata;
    }
    /**
     * Get all registered action types
     *
     * @returns Array of action type identifiers
     */
    getActionTypes() {
        this.initializeActions();
        return Array.from(this.actionCatalog.keys());
    }
    /**
     * Create action instance
     *
     * Instantiates the action class with appropriate dependencies based on
     * whether it extends PlaybookActionWithSteps.
     *
     * @param actionType - Action type identifier (kebab-case)
     * @param stepExecutor - StepExecutor for actions that need nested execution
     * @returns Instantiated action
     * @throws {CatalystError} If action type not found
     *
     * @example
     * ```typescript
     * const action = provider.createAction('script', stepExecutor);
     * const result = await action.execute({ code: 'return 42' });
     * ```
     */
    createAction(actionType, stepExecutor) {
        this.initializeActions();
        const entry = this.actionCatalog.get(actionType);
        if (!entry) {
            throw new errors_1.CatalystError(`Action "${actionType}" not found`, 'ActionNotFound', `Available actions: ${this.getActionTypes().join(', ')}`);
        }
        const { ActionClass } = entry;
        // Determine if action needs StepExecutor
        if (this.extendsPlaybookActionWithSteps(ActionClass)) {
            if (!stepExecutor) {
                throw new errors_1.CatalystError(`Action "${actionType}" requires a StepExecutor`, 'MissingStepExecutor', 'Control flow actions need a StepExecutor for nested step execution');
            }
            return new ActionClass(stepExecutor);
        }
        return new ActionClass();
    }
    /**
     * Register an action class
     *
     * For production, actions are registered via generated catalog.
     * This method enables testing with mock actions.
     *
     * @param actionType - Action type identifier (kebab-case)
     * @param ActionClass - Action class constructor
     * @param metadata - Optional metadata (defaults to minimal metadata)
     *
     * @example
     * ```typescript
     * // Testing with mock action
     * provider.registerAction('mock-action', MockAction);
     *
     * // With custom metadata
     * provider.registerAction('custom-action', CustomAction, {
     *   actionType: 'custom-action',
     *   className: 'CustomAction',
     *   primaryProperty: 'value'
     * });
     * ```
     */
    registerAction(actionType, ActionClass, metadata) {
        const fullMetadata = {
            actionType,
            className: ActionClass.name,
            ...metadata
        };
        this.actionCatalog.set(actionType, {
            metadata: fullMetadata,
            ActionClass
        });
    }
    /**
     * Unregister an action (testing only)
     *
     * @param actionType - Action type to remove
     */
    unregisterAction(actionType) {
        this.actionCatalog.delete(actionType);
    }
    /**
     * Initialize actions from generated catalog
     *
     * Called automatically on first action access.
     */
    initializeActions() {
        if (this.actionCatalog.size > 0) {
            return; // Already initialized
        }
        // Import from generated catalog
        try {
            const { ACTION_CATALOG } = require('./action-catalog');
            for (const [actionType, entry] of Object.entries(ACTION_CATALOG)) {
                const catalogEntry = entry;
                if (catalogEntry.classType) {
                    this.actionCatalog.set(actionType, {
                        metadata: catalogEntry,
                        ActionClass: catalogEntry.classType
                    });
                }
            }
        }
        catch {
            // Catalog not generated yet - that's OK for testing
        }
    }
    /**
     * Check if a class extends PlaybookActionWithSteps
     *
     * Uses prototype chain inspection to detect if the class needs StepExecutor.
     * Compares constructor names to avoid circular dependency issues.
     */
    extendsPlaybookActionWithSteps(ActionClass) {
        let proto = ActionClass.prototype;
        while (proto) {
            // Check constructor name to avoid circular import issues
            // PlaybookActionWithSteps is the base class name
            if (proto.constructor?.name === 'PlaybookActionWithSteps') {
                return true;
            }
            proto = Object.getPrototypeOf(proto);
        }
        return false;
    }
    // ─────────────────────────────────────────────────────────────────────────────
    // Cache Management
    // ─────────────────────────────────────────────────────────────────────────────
    /**
     * Clear playbook cache
     *
     * Forces reload of playbooks on next access.
     */
    clearPlaybookCache() {
        this.playbookCache.clear();
    }
    /**
     * Clear all state (testing only)
     *
     * Resets loaders, actions, and caches.
     */
    clearAll() {
        this.loaders.clear();
        this.loaderOrder = [];
        this.loadersInitialized = false;
        this.actionCatalog.clear();
        this.playbookCache.clear();
    }
    // ─────────────────────────────────────────────────────────────────────────────
    // Legacy Compatibility (deprecated)
    // ─────────────────────────────────────────────────────────────────────────────
    /**
     * @deprecated Use registerLoader() instead
     */
    register(loader) {
        this.registerLoader(loader);
    }
    /**
     * @deprecated Use loadPlaybook() instead
     */
    async load(identifier) {
        try {
            return await this.loadPlaybook(identifier);
        }
        catch {
            return undefined;
        }
    }
    /**
     * @deprecated Use getActionTypes() or check loaders directly
     */
    getProviderNames() {
        return [...this.loaderOrder];
    }
    /**
     * @deprecated Use clearAll() instead
     */
    unregister(loaderName) {
        this.loaders.delete(loaderName);
        this.loaderOrder = this.loaderOrder.filter(name => name !== loaderName);
    }
}
exports.PlaybookProvider = PlaybookProvider;
PlaybookProvider.instance = null;
//# sourceMappingURL=playbook-provider.js.map
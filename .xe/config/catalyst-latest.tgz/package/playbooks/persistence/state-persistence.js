"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatePersistence = void 0;
const promises_1 = require("fs/promises");
const path_1 = require("path");
const state_1 = require("../types/state");
const atomic_write_1 = require("./atomic-write");
/**
 * State persistence class
 *
 * @req FR:playbook-definition/persistence.active-runs
 * @req FR:playbook-definition/persistence.archive
 * @req FR:playbook-definition/persistence.atomic-writes
 * @req FR:playbook-definition/persistence.class.methods
 * @req FR:playbook-definition/persistence.class.format
 * @req FR:playbook-definition/persistence.class.performance
 * @req FR:playbook-definition/persistence.class.error-handling
 * @req NFR:playbook-definition/reliability.atomic-writes
 * @req NFR:playbook-definition/reliability.corruption-recovery
 *
 * Provides save, load, archive, and pruning operations for playbook state.
 * Uses atomic writes to prevent corruption.
 *
 * @example
 * ```typescript
 * const persistence = new StatePersistence();
 * await persistence.save(state);
 * const loaded = await persistence.load(runId);
 * await persistence.archive(runId);
 * ```
 */
class StatePersistence {
    /**
     * Create a new StatePersistence instance
     *
     * @param runsDir - Base directory for active runs (default: '.xe/runs')
     */
    constructor(runsDir = '.xe/runs') {
        this.runsDir = runsDir;
        this.historyDir = (0, path_1.join)(runsDir, 'history');
    }
    /**
     * Save playbook state to disk
     *
     * @param state - Playbook state to save
     * @throws StateError if save fails
     */
    async save(state) {
        const filePath = (0, path_1.join)(this.runsDir, `run-${state.runId}.json`);
        const isDebug = state.executionOptions?.debug ?? false;
        // Build ordered state for serialization
        // @req FR:playbook-engine/state.persistence
        // @req FR:playbook-engine/state.serialization-order
        const ordered = {
            runId: state.runId,
            playbookName: state.playbookName,
            status: state.status,
        };
        // @req FR:playbook-engine/state.error-capture
        // Include error details only when present (failed runs)
        if (state.error) {
            ordered.error = state.error;
        }
        ordered.currentStepName = state.currentStepName;
        ordered.startTime = state.startTime;
        ordered.executionOptions = state.executionOptions;
        // Include playbook definition only in debug mode
        if (isDebug && 'playbook' in state) {
            ordered.playbook = state.playbook;
        }
        ordered.inputs = state.inputs;
        ordered.variables = state.variables;
        ordered.completedSteps = state.completedSteps;
        ordered.checkpointResponses = state.checkpointResponses;
        ordered.logs = state.logs;
        const json = JSON.stringify(ordered, null, 2);
        try {
            // Create directory if it doesn't exist
            await (0, promises_1.mkdir)(this.runsDir, { recursive: true });
            // Use atomic write (temp file + rename)
            await (0, atomic_write_1.atomicWrite)(filePath, json);
        }
        catch (error) {
            throw new state_1.StateError(`Failed to save state for run ${state.runId}`, 'StateSaveFailed', 'Check disk space and file permissions for the .xe/runs directory', error);
        }
    }
    /**
     * Load playbook state from disk
     *
     * @param runId - Run identifier to load
     * @returns Playbook state
     * @throws StateError if load fails or state corrupted
     */
    async load(runId) {
        const filePath = (0, path_1.join)(this.runsDir, `run-${runId}.json`);
        try {
            const json = await (0, promises_1.readFile)(filePath, 'utf8');
            const state = JSON.parse(json);
            // Validate required fields
            if (!state.runId || !state.playbookName) {
                throw new Error('Invalid state structure: missing runId or playbookName');
            }
            // Migrate legacy approvedCheckpoints (string[]) to checkpointResponses (Record)
            const raw = state;
            if (raw.approvedCheckpoints && !state.checkpointResponses) {
                state.checkpointResponses = {};
                for (const name of raw.approvedCheckpoints) {
                    state.checkpointResponses[name] = {
                        selected: 'continue',
                        value: true,
                        hasTextInput: false,
                    };
                }
                delete raw.approvedCheckpoints;
            }
            return state;
        }
        catch (error) {
            const err = error;
            if (err.message.includes('ENOENT')) {
                throw new state_1.StateError(`Failed to load state for run ${runId}. Run not found.`, 'StateLoadFailed', 'Verify the runId is correct and the state file exists in .xe/runs/', err);
            }
            else if (err instanceof SyntaxError) {
                throw new state_1.StateError(`Failed to load state for run ${runId}. File is corrupted (invalid JSON).`, 'StateLoadFailed', 'Restore from backup or delete the corrupted state file', err);
            }
            else {
                throw new state_1.StateError(`Failed to load state for run ${runId}. ${err.message}`, 'StateLoadFailed', 'Check file permissions and disk health', err);
            }
        }
    }
    /**
     * Archive completed run to history directory
     *
     * Moves the state file from active runs to history directory organized by date.
     * Creates .gitignore in history root on first archive.
     *
     * @param runId - Run identifier to archive
     * @throws StateError if archive fails
     */
    async archive(runId) {
        try {
            // Parse date from runId (YYYYMMDD-HHMMSS-nnn)
            const datePart = runId.split('-')[0];
            if (!datePart || datePart.length !== 8) {
                throw new Error(`Invalid runId format: ${runId}. Expected format: YYYYMMDD-HHMMSS-nnn`);
            }
            const year = datePart.substring(0, 4);
            const month = datePart.substring(4, 6);
            const day = datePart.substring(6, 8);
            const historyPath = (0, path_1.join)(this.historyDir, year, month, day);
            const sourcePath = (0, path_1.join)(this.runsDir, `run-${runId}.json`);
            const targetPath = (0, path_1.join)(historyPath, `run-${runId}.json`);
            // Create history directory structure
            await (0, promises_1.mkdir)(historyPath, { recursive: true });
            // @req FR:playbook-definition/persistence.gitignore
            // Create .gitignore in history root if it doesn't exist
            const gitignorePath = (0, path_1.join)(this.historyDir, '.gitignore');
            try {
                await (0, promises_1.stat)(gitignorePath);
            }
            catch {
                // File doesn't exist, create it
                await (0, atomic_write_1.atomicWrite)(gitignorePath, '*\n');
            }
            // Read source and write to target atomically
            const content = await (0, promises_1.readFile)(sourcePath, 'utf8');
            await (0, atomic_write_1.atomicWrite)(targetPath, content);
            // Delete source file
            await (0, promises_1.unlink)(sourcePath);
        }
        catch (error) {
            throw new state_1.StateError(`Failed to archive run ${runId}`, 'StateArchiveFailed', 'Check disk space and permissions for .xe/runs/history/ directory', error);
        }
    }
    /**
     * List all active runs
     *
     * @returns Array of run IDs sorted alphabetically
     */
    async listActiveRuns() {
        try {
            const files = await (0, promises_1.readdir)(this.runsDir);
            const runFiles = files.filter(f => f.startsWith('run-') && f.endsWith('.json'));
            const runIds = runFiles.map(f => f.replace(/^run-/, '').replace(/\.json$/, ''));
            return runIds.sort();
        }
        catch (error) {
            throw new state_1.StateError('Failed to list active runs', 'StateListFailed', 'Check permissions for .xe/runs/ directory', error);
        }
    }
    /**
     * Prune old archived runs
     *
     * Deletes archived runs older than the specified retention period.
     *
     * @param retentionDays - Number of days to retain
     * @returns Number of runs deleted
     */
    async pruneArchive(retentionDays) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - retentionDays);
        let deletedCount = 0;
        // Recursively scan history directories
        async function scanDirectory(dir) {
            let count = 0;
            try {
                const entries = await (0, promises_1.readdir)(dir, { withFileTypes: true });
                for (const entry of entries) {
                    const fullPath = (0, path_1.join)(dir, entry.name);
                    if (entry.isDirectory()) {
                        count += await scanDirectory(fullPath);
                    }
                    else if (entry.name.endsWith('.json')) {
                        const stats = await (0, promises_1.stat)(fullPath);
                        if (stats.mtime < cutoffDate) {
                            await (0, promises_1.unlink)(fullPath);
                            count++;
                        }
                    }
                }
            }
            catch (error) {
                // Continue on errors (directory might not exist yet)
            }
            return count;
        }
        deletedCount = await scanDirectory(this.historyDir);
        return deletedCount;
    }
}
exports.StatePersistence = StatePersistence;
//# sourceMappingURL=state-persistence.js.map
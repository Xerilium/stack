"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.atomicWrite = atomicWrite;
const promises_1 = require("fs/promises");
const path_1 = require("path");
const crypto_1 = require("crypto");
/**
 * Atomically write content to a file
 *
 * Uses the temp file + rename pattern to ensure atomic writes. This prevents
 * file corruption if the process crashes during write, as the original file
 * remains intact until the atomic rename operation completes.
 *
 * @param path - Target file path
 * @param content - Content to write
 * @throws Error if write fails
 *
 * @example
 * ```typescript
 * await atomicWrite('/path/to/file.json', JSON.stringify(data));
 * ```
 */
async function atomicWrite(path, content) {
    // Generate unique temp file path with random hex suffix
    const tempPath = `${path}.tmp-${(0, crypto_1.randomBytes)(8).toString('hex')}`;
    try {
        // Ensure parent directory exists
        await (0, promises_1.mkdir)((0, path_1.dirname)(path), { recursive: true });
        // Write to temp file
        await (0, promises_1.writeFile)(tempPath, content, 'utf8');
        // Atomically rename to target (atomic on POSIX filesystems)
        await (0, promises_1.rename)(tempPath, path);
    }
    catch (error) {
        // Clean up temp file on error (ignore cleanup errors)
        try {
            await (0, promises_1.unlink)(tempPath);
        }
        catch {
            // Ignore cleanup errors
        }
        // Propagate original error
        throw error;
    }
}
//# sourceMappingURL=atomic-write.js.map
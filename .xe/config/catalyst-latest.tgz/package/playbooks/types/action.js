"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaybookActionWithSteps = void 0;
/**
 * Abstract base class for actions that execute nested steps
 *
 * @req FR:playbook-definition/types.step-executor.base-class
 *
 * Actions that need to execute nested steps (control flow, iteration, etc.) should extend
 * this class instead of implementing PlaybookAction directly. The engine provides a
 * StepExecutor implementation via the constructor.
 *
 * **Usage Pattern**:
 * - Extend this class when your action needs to execute other steps
 * - Use `this.stepExecutor.executeSteps()` to execute nested steps
 * - The engine enforces all execution rules automatically
 *
 * **Example Actions**:
 * - `if` - Conditional execution (execute then/else steps based on condition)
 * - `for-each` - Iteration (execute steps for each item in array)
 * - `parallel` - Concurrent execution (future)
 * - `retry` - Retry with backoff (future)
 * - `timeout` - Execution with timeout (future)
 *
 * @template TConfig - The expected configuration structure for this action
 *
 * @see {@link StepExecutor} Interface for executing nested steps
 * @see {@link PlaybookAction} Base action interface
 *
 * @example
 * ```typescript
 * interface IfConfig {
 *   condition: string;  // Template expression
 *   then: PlaybookStep[];
 *   else?: PlaybookStep[];
 * }
 *
 * export class IfAction extends PlaybookActionWithSteps<IfConfig> {
 *   static readonly actionType = 'if';
 *
 *   async execute(config: IfConfig): Promise<PlaybookActionResult> {
 *     const condition = await evaluateTemplate(config.condition);
 *
 *     if (condition) {
 *       const results = await this.stepExecutor.executeSteps(config.then);
 *       return results[results.length - 1] || { code: 'Success' };
 *     } else if (config.else) {
 *       const results = await this.stepExecutor.executeSteps(config.else);
 *       return results[results.length - 1] || { code: 'Success' };
 *     }
 *
 *     return { code: 'Success' };
 *   }
 * }
 * ```
 */
class PlaybookActionWithSteps {
    /**
     * Construct action with step executor callback
     *
     * The engine provides the StepExecutor implementation when instantiating
     * actions that extend this class.
     *
     * @param stepExecutor - Callback for executing nested steps
     */
    constructor(stepExecutor) {
        this.stepExecutor = stepExecutor;
    }
}
exports.PlaybookActionWithSteps = PlaybookActionWithSteps;
//# sourceMappingURL=action.js.map
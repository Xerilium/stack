"use strict";
/**
 * Validation types and interfaces
 *
 * All validation rules must extend this interface and provide a type discriminator.
 * The type property enables TypeScript discriminated unions for type-safe validation.
 *
 * @example
 * ```typescript
 * const rule: ValidationRule = {
 *   type: 'Regex',
 *   pattern: '^[0-9]+$',
 *   message: 'Must contain only digits'
 * };
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValidatorFactory = void 0;
/**
 * Factory for validator registration and execution
 *
 * Manages validator registry using Factory pattern. Built-in validators are
 * pre-registered, and custom validators can be added via register().
 *
 * @req FR:playbook-definition/validation.factory
 *
 * @example
 * ```typescript
 * const factory = new ValidatorFactory();
 * const result = factory.validate('test@example.com', {
 *   type: 'Regex',
 *   pattern: '^[^@]+@[^@]+\\.[^@]+$'
 * });
 * ```
 */
class ValidatorFactory {
    constructor() {
        this.validators = new Map();
        // Pre-register built-in validators
        // TODO: Consider auto-discovery if validators proliferate beyond ~10 types
        // For now, manual registration keeps it simple and explicit
        this.register('Regex', new RegexValidator());
        this.register('StringLength', new StringLengthValidator());
        this.register('NumberRange', new NumberRangeValidator());
        this.register('Custom', new CustomValidator());
    }
    /**
     * Register a validator for a rule type
     *
     * @param type - The rule type (must match ValidationRule.type)
     * @param validator - The validator implementation
     */
    register(type, validator) {
        this.validators.set(type, validator);
    }
    /**
     * Validate a value against a rule
     *
     * @param value - The value to validate
     * @param rule - The validation rule configuration
     * @returns ValidationResult with success status and optional error
     * @throws Error if no validator registered for rule type
     */
    validate(value, rule) {
        const validator = this.validators.get(rule.type);
        if (!validator) {
            throw new Error(`No validator registered for type: ${rule.type}`);
        }
        return validator.validate(value, rule);
    }
    /**
     * Validate a value against multiple rules
     *
     * Validates in order, returning first failure. All rules must pass for success.
     *
     * @param value - The value to validate
     * @param rules - Array of validation rules to apply
     * @returns ValidationResult with success status and optional error
     */
    validateAll(value, rules) {
        for (const rule of rules) {
            const result = this.validate(value, rule);
            if (!result.valid) {
                return result;
            }
        }
        return { valid: true };
    }
}
exports.ValidatorFactory = ValidatorFactory;
/**
 * Regex pattern validator
 */
class RegexValidator {
    validate(value, rule) {
        if (typeof value !== 'string') {
            return {
                valid: false,
                error: {
                    code: rule.code || 'InvalidType',
                    message: rule.message || 'Value must be a string',
                    rule,
                    value,
                },
            };
        }
        const regex = new RegExp(rule.pattern);
        if (!regex.test(value)) {
            return {
                valid: false,
                error: {
                    code: rule.code || 'RegexMismatch',
                    message: rule.message || `Value does not match pattern: ${rule.pattern}`,
                    rule,
                    value,
                },
            };
        }
        return { valid: true };
    }
}
/**
 * String length validator
 */
class StringLengthValidator {
    validate(value, rule) {
        if (typeof value !== 'string') {
            return {
                valid: false,
                error: {
                    code: rule.code || 'InvalidType',
                    message: rule.message || 'Value must be a string',
                    rule,
                    value,
                },
            };
        }
        if (rule.minLength !== undefined && value.length < rule.minLength) {
            return {
                valid: false,
                error: {
                    code: rule.code || 'TooShort',
                    message: rule.message || `Value must be at least ${rule.minLength} characters`,
                    rule,
                    value,
                },
            };
        }
        if (rule.maxLength !== undefined && value.length > rule.maxLength) {
            return {
                valid: false,
                error: {
                    code: rule.code || 'TooLong',
                    message: rule.message || `Value must be at most ${rule.maxLength} characters`,
                    rule,
                    value,
                },
            };
        }
        return { valid: true };
    }
}
/**
 * Number range validator
 */
class NumberRangeValidator {
    validate(value, rule) {
        if (typeof value !== 'number') {
            return {
                valid: false,
                error: {
                    code: rule.code || 'InvalidType',
                    message: rule.message || 'Value must be a number',
                    rule,
                    value,
                },
            };
        }
        if (rule.min !== undefined && value < rule.min) {
            return {
                valid: false,
                error: {
                    code: rule.code || 'TooSmall',
                    message: rule.message || `Value must be at least ${rule.min}`,
                    rule,
                    value,
                },
            };
        }
        if (rule.max !== undefined && value > rule.max) {
            return {
                valid: false,
                error: {
                    code: rule.code || 'TooLarge',
                    message: rule.message || `Value must be at most ${rule.max}`,
                    rule,
                    value,
                },
            };
        }
        return { valid: true };
    }
}
/**
 * Custom script validator
 */
class CustomValidator {
    validate(value, rule) {
        try {
            // Create a function from the script that has access to 'value'
            const fn = new Function('value', `return (${rule.script});`);
            const result = fn(value);
            if (typeof result !== 'boolean') {
                throw new Error('Custom validation script must return a boolean');
            }
            if (!result) {
                return {
                    valid: false,
                    error: {
                        code: rule.code || 'CustomValidationFailed',
                        message: rule.message || 'Custom validation failed',
                        rule,
                        value,
                    },
                };
            }
            return { valid: true };
        }
        catch (err) {
            return {
                valid: false,
                error: {
                    code: rule.code || 'CustomValidationError',
                    message: rule.message || `Custom validation script error: ${err.message}`,
                    rule,
                    value,
                },
            };
        }
    }
}
//# sourceMappingURL=validation.js.map
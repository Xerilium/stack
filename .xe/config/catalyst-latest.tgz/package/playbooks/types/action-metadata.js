"use strict";
/**
 * Action metadata type definitions
 *
 * Defines metadata structure for playbook actions including dependencies,
 * YAML shorthand configuration, and JSON schemas for validation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=action-metadata.js.map
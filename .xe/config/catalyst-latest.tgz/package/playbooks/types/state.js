"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateError = void 0;
const errors_1 = require("../../core/errors");
/**
 * Error class for state persistence operations
 *
 * Thrown when state save, load, or archive operations fail.
 *
 * @example
 * ```typescript
 * throw new StateError(
 *   'Failed to save state for run 20251128-143022-001',
 *   'StateSaveFailed',
 *   'Check disk space and permissions',
 *   originalError
 * );
 * ```
 */
class StateError extends errors_1.CatalystError {
    /**
     * Create a new StateError
     *
     * @param message - Human-readable error message
     * @param code - Error code (e.g., 'StateSaveFailed', 'StateLoadFailed')
     * @param guidance - Actionable guidance for resolving the error
     * @param cause - Original error that caused this error (optional)
     */
    constructor(message, code, guidance, cause) {
        super(message, code, guidance, cause);
    }
}
exports.StateError = StateError;
//# sourceMappingURL=state.js.map
---
name: blueprint
description: Create or update the product blueprint
argument-hint: "[issue]"
allowed-tools: Read, Edit, Write, Glob, Grep, Bash, Task, TodoWrite
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `node "${CLAUDE_PLUGIN_ROOT}/ai/plugin/bootstrap.js"` before continuing.

# Create or update the product blueprint

Execute @node_modules/@xerilium/catalyst/playbooks/start-blueprint.md

Follow instructions in order – do NOT skip steps

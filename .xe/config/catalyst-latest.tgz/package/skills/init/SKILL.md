---
name: init
description: Initialize a Catalyst project
argument-hint: "[description]"
allowed-tools: Read, Edit, Write, Glob, Grep, Bash, Task, TodoWrite
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `node "${CLAUDE_PLUGIN_ROOT}/ai/plugin/bootstrap.js"` before continuing.

# Initialize a Catalyst project

Execute @node_modules/@xerilium/catalyst/playbooks/start-initialization.md

Follow instructions in order – do NOT skip steps

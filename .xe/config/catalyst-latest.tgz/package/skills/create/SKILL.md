---
name: create
description: Create new features or add new capabilities
argument-hint: "[description]"
allowed-tools: Read, Edit, Write, Glob, Grep, Bash, Task, TodoWrite
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `node "${CLAUDE_PLUGIN_ROOT}/ai/plugin/bootstrap.js"` before continuing.

# Create new features or add new capabilities

Execute @node_modules/@xerilium/catalyst/playbooks/create-feature.md

Follow instructions in order – do NOT skip steps

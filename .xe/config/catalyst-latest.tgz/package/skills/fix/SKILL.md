---
name: fix
description: Investigate and fix bugs
argument-hint: "[description]"
allowed-tools: Read, Edit, Write, Glob, Grep, Bash, Task, TodoWrite
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `node "${CLAUDE_PLUGIN_ROOT}/ai/plugin/bootstrap.js"` before continuing.

# Investigate and fix bugs

Execute @node_modules/@xerilium/catalyst/playbooks/repair-feature.md

Follow instructions in order – do NOT skip steps

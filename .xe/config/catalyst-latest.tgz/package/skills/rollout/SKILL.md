---
name: rollout
description: Orient and dispatch any rollout — start, continue, or resume
argument-hint: "[rollout-id or description]"
allowed-tools: Read, Edit, Write, Glob, Grep, Bash, Task, TodoWrite
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `node "${CLAUDE_PLUGIN_ROOT}/ai/plugin/bootstrap.js"` before continuing.

# Orient and dispatch any rollout

Execute @node_modules/@xerilium/catalyst/playbooks/start-rollout.md

Follow instructions in order – do NOT skip steps

---
name: change
description: Update or refactor existing features
argument-hint: "[description]"
allowed-tools: Read, Edit, Write, Glob, Grep, Bash, Task, TodoWrite
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `node "${CLAUDE_PLUGIN_ROOT}/ai/plugin/bootstrap.js"` before continuing.

# Update or refactor existing features

Execute @node_modules/@xerilium/catalyst/playbooks/update-feature.md

Follow instructions in order – do NOT skip steps

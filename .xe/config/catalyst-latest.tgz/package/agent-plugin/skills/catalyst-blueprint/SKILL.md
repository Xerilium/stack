---
name: catalyst-blueprint
description: Create or update the product blueprint
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Create or update the product blueprint

Execute @node_modules/@xerilium/catalyst/playbooks/start-blueprint.md

Follow instructions in order – do NOT skip steps

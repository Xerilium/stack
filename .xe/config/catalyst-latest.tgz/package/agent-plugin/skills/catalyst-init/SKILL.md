---
name: catalyst-init
description: Initialize a Catalyst project
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Initialize a Catalyst project

Execute @node_modules/@xerilium/catalyst/playbooks/start-initialization.md

Follow instructions in order – do NOT skip steps

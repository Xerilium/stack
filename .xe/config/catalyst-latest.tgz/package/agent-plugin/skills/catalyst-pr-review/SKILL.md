---
name: catalyst-pr-review
description: Review a pull request for quality, correctness, and project alignment
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Review Pull Request

Execute @node_modules/@xerilium/catalyst/playbooks/review-pull-request.md

Map inputs:

- First argument → `pr-number`
- `ai-platform` → your AI platform's name (e.g., "Copilot", "Cursor", "Codex")

---
name: catalyst-fix
description: Investigate and fix bugs
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Investigate and fix bugs

Execute @node_modules/@xerilium/catalyst/playbooks/repair-feature.md

Follow instructions in order – do NOT skip steps

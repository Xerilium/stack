---
name: catalyst-change
description: Update or refactor existing features
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Update or refactor existing features

Execute @node_modules/@xerilium/catalyst/playbooks/update-feature.md

Follow instructions in order – do NOT skip steps

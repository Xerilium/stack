---
name: catalyst-pr-update
description: Update a pull request by analyzing feedback, implementing changes, and responding to comments
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Update Pull Request

Execute @node_modules/@xerilium/catalyst/playbooks/update-pull-request.md

Map inputs:

- First argument → `pr-number`
- `ai-platform` → your AI platform's name (e.g., "Copilot", "Cursor", "Codex")

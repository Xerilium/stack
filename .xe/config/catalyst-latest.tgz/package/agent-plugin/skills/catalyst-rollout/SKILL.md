---
name: catalyst-rollout
description: Orient and dispatch any rollout — start, continue, or resume
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Orient and dispatch any rollout

Execute @node_modules/@xerilium/catalyst/playbooks/start-rollout.md

Follow instructions in order – do NOT skip steps

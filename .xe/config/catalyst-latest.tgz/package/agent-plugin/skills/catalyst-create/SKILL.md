---
name: catalyst-create
description: Create new features or add new capabilities
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Create new features or add new capabilities

Execute @node_modules/@xerilium/catalyst/playbooks/create-feature.md

Follow instructions in order – do NOT skip steps

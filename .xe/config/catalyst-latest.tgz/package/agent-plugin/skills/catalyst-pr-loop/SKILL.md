---
name: catalyst-pr-loop
description: Run autonomous review and update rounds on a pull request until findings are resolved
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Loop Pull Request

Execute @node_modules/@xerilium/catalyst/playbooks/loop-pull-request.md

Map inputs:

- First argument → `pr-number`
- Second argument → `max-rounds`
- `ai-platform` → your AI platform's name (e.g., "Copilot", "Cursor", "Codex")

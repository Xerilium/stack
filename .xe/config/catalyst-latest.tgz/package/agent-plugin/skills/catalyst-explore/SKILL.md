---
name: catalyst-explore
description: Investigate, research, or brainstorm ideas
---

> **Setup**: If `node_modules/@xerilium/catalyst/package.json` doesn't exist, run `npx -y -p @xerilium/catalyst catalyst-bootstrap` before continuing.

# Investigate, research, or brainstorm ideas

Execute @node_modules/@xerilium/catalyst/playbooks/explore-feature.md

Follow instructions in order – do NOT skip steps

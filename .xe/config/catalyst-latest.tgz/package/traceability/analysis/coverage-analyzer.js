"use strict";
/**
 * Coverage analyzer for traceability reports.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoverageAnalyzer = void 0;
/**
 * Analyzer that compares requirements against annotations.
 * @req FR:req-traceability/analysis.missing
 * @req FR:req-traceability/analysis.orphan
 * @req FR:req-traceability/analysis.deprecated
 * @req FR:req-traceability/analysis.coverage
 * @req FR:req-traceability/analysis.coverage.code
 * @req FR:req-traceability/analysis.coverage.tests
 * @req FR:req-traceability/analysis.coverage.leaf-only
 * @req FR:req-traceability/priority.reporting
 */
class CoverageAnalyzer {
    /**
     * Analyze coverage of requirements by annotations.
     * @req FR:req-traceability/analysis.coverage
     * @req FR:req-traceability/scan.traceability-mode.disabled
     * @req FR:req-traceability/scan.traceability-mode.required
     */
    analyze(requirements, annotations, featureTraceabilityModes) {
        // Build maps for lookup
        const reqMap = this.buildRequirementMap(requirements);
        const annotationMap = this.buildAnnotationMap(annotations);
        const parentSet = this.buildParentSet(requirements);
        // Analyze each requirement
        const coverageMap = new Map();
        for (const req of requirements) {
            const coverage = this.analyzeRequirement(req, annotationMap.get(req.id.qualified) || []);
            // Mark parent requirements with 'parent' status
            if (parentSet.has(req.id.qualified)) {
                coverage.coverageStatus = 'parent';
            }
            coverageMap.set(req.id.qualified, coverage);
        }
        // Find orphaned annotations
        const orphaned = this.findOrphanedAnnotations(annotations, reqMap);
        // Collect file-level annotations
        // @req FR:req-traceability/annotation.file-level-detection
        const fileLevelAnnotations = annotations
            .filter(a => a.isFileLevel)
            .map(a => ({
            id: a.id.qualified,
            file: a.file,
            line: a.line,
            isTest: a.isTest,
        }));
        // Find test coverage gaps: active leaf requirements without test annotations
        // @req FR:req-traceability/analysis.test-completeness
        const testCoverageGaps = this.findTestCoverageGaps(requirements, coverageMap, parentSet, featureTraceabilityModes);
        // Find code coverage gaps: active leaf requirements without code annotations
        // @req FR:req-traceability/scan.traceability-mode.disabled
        // @req FR:req-traceability/scan.traceability-mode.required
        const codeCoverageGaps = this.findCodeCoverageGaps(requirements, coverageMap, parentSet, featureTraceabilityModes);
        // Calculate summary (excluding parent requirements from coverage metrics)
        const summary = this.calculateSummary(requirements, coverageMap, featureTraceabilityModes);
        return {
            metadata: {
                scanTime: new Date().toISOString(),
                filesScanned: 0, // Set by runner after analysis
                scanDurationMs: 0, // Set by runner after analysis
            },
            requirements: coverageMap,
            orphaned,
            fileLevelAnnotations,
            testCoverageGaps,
            codeCoverageGaps,
            featureTraceabilityModes,
            parseWarnings: [], // Set by runner after analysis
            summary,
        };
    }
    /**
     * Build a map of requirement ID -> RequirementDefinition.
     */
    buildRequirementMap(requirements) {
        const map = new Map();
        for (const req of requirements) {
            map.set(req.id.qualified, req);
        }
        return map;
    }
    /**
     * Build a set of parent requirement IDs (requirements that have children).
     * Parent requirements are excluded from coverage metrics.
     * @req FR:req-traceability/analysis.coverage.leaf-only
     */
    buildParentSet(requirements) {
        const parentSet = new Set();
        // For each requirement, check if any other requirement's path starts with this one + "."
        for (const req of requirements) {
            const reqType = req.id.type;
            const reqScope = req.id.scope;
            const reqPath = req.id.path;
            for (const other of requirements) {
                // Must be same type, same scope, and path must start with our path + "."
                if (other.id.type === reqType &&
                    other.id.scope === reqScope &&
                    other.id.path !== reqPath &&
                    other.id.path.startsWith(reqPath + '.')) {
                    parentSet.add(req.id.qualified);
                    break; // Found at least one child, no need to check more
                }
            }
        }
        return parentSet;
    }
    /**
     * Build a map of requirement ID -> annotations[].
     */
    buildAnnotationMap(annotations) {
        const map = new Map();
        for (const ann of annotations) {
            const key = ann.id.qualified;
            if (!map.has(key)) {
                map.set(key, []);
            }
            map.get(key).push(ann);
        }
        return map;
    }
    /**
     * Analyze a single requirement's coverage.
     * @req FR:req-traceability/analysis.coverage.code
     * @req FR:req-traceability/analysis.coverage.tests
     */
    analyzeRequirement(req, annotations) {
        const implementations = [];
        const tests = [];
        // Separate code and test annotations
        for (const ann of annotations) {
            if (ann.isTest) {
                tests.push({ file: ann.file, line: ann.line });
            }
            else {
                implementations.push({
                    file: ann.file,
                    line: ann.line,
                    partial: ann.isPartial,
                });
            }
        }
        // Determine coverage status
        const status = this.determineCoverageStatus(req, implementations, tests);
        return {
            spec: {
                file: req.specFile,
                line: req.specLine,
                text: req.text,
            },
            state: req.state,
            priority: req.priority,
            implementations,
            tests,
            coverageStatus: status,
        };
    }
    /**
     * Determine the coverage status for a requirement.
     * @req FR:req-traceability/analysis.missing
     * @req FR:req-traceability/analysis.deprecated
     */
    determineCoverageStatus(req, implementations, tests) {
        // Check state first
        if (req.state === 'deferred') {
            return 'deferred';
        }
        if (req.state === 'deprecated') {
            return 'deprecated';
        }
        if (req.state === 'exempt') {
            return 'exempt';
        }
        // Check for tests (highest status)
        if (tests.length > 0) {
            return 'tested';
        }
        // Check for implementations
        if (implementations.length > 0) {
            const hasFullImplementation = implementations.some((impl) => !impl.partial);
            if (hasFullImplementation) {
                return 'implemented';
            }
            return 'implemented-partial';
        }
        // No coverage
        return 'missing';
    }
    /**
     * Find annotations that reference non-existent requirements.
     * @req FR:req-traceability/analysis.orphan
     */
    findOrphanedAnnotations(annotations, reqMap) {
        const orphanMap = new Map();
        for (const ann of annotations) {
            if (!reqMap.has(ann.id.qualified)) {
                const key = ann.id.qualified;
                if (!orphanMap.has(key)) {
                    orphanMap.set(key, []);
                }
                orphanMap.get(key).push(`${ann.file}:${ann.line}`);
            }
        }
        return Array.from(orphanMap.entries()).map(([id, locations]) => ({
            id,
            locations,
        }));
    }
    /**
     * Find active leaf requirements without test annotations.
     * @req FR:req-traceability/analysis.test-completeness
     * @req FR:req-traceability/analysis.convention-tests.test-coverage
     * @req FR:req-traceability/scan.traceability-mode.disabled
     * @req FR:req-traceability/scan.traceability-mode.required
     */
    findTestCoverageGaps(requirements, coverageMap, parentSet, featureTraceabilityModes) {
        const gaps = [];
        for (const req of requirements) {
            // Skip parents and non-active
            if (parentSet.has(req.id.qualified)) {
                continue;
            }
            if (req.state !== 'active') {
                continue;
            }
            // Check traceability mode for this feature
            // @req FR:req-traceability/scan.traceability-mode.disabled.output
            const mode = featureTraceabilityModes?.get(req.id.scope);
            if (mode?.test === 'disable') {
                continue;
            } // Disabled — exclude from report
            // Determine severity — after resolution, values are 'error', 'warning', false, or undefined
            // @req FR:req-traceability/scan.traceability-mode.required.output
            const severity = mode?.test === 'error' ? 'error' : 'warning';
            const coverage = coverageMap.get(req.id.qualified);
            if (!coverage || coverage.tests.length === 0) {
                gaps.push({
                    id: req.id.qualified,
                    priority: req.priority,
                    severity,
                    spec: { file: req.specFile, line: req.specLine, text: req.text },
                });
            }
        }
        return gaps;
    }
    /**
     * Find active leaf requirements without code annotations.
     * @req FR:req-traceability/scan.traceability-mode.disabled
     * @req FR:req-traceability/scan.traceability-mode.disabled.output
     * @req FR:req-traceability/scan.traceability-mode.required
     * @req FR:req-traceability/scan.traceability-mode.required.output
     */
    findCodeCoverageGaps(requirements, coverageMap, parentSet, featureTraceabilityModes) {
        const gaps = [];
        for (const req of requirements) {
            // Skip parents and non-active
            if (parentSet.has(req.id.qualified)) {
                continue;
            }
            if (req.state !== 'active') {
                continue;
            }
            // Check traceability mode for this feature
            const mode = featureTraceabilityModes?.get(req.id.scope);
            if (mode?.code === 'disable') {
                continue;
            } // Disabled — exclude from report
            // Determine severity — after resolution, values are 'error', 'warning', false, or undefined
            const severity = mode?.code === 'error' ? 'error' : 'warning';
            const coverage = coverageMap.get(req.id.qualified);
            if (!coverage || coverage.implementations.length === 0) {
                gaps.push({
                    id: req.id.qualified,
                    priority: req.priority,
                    severity,
                    spec: { file: req.specFile, line: req.specLine, text: req.text },
                });
            }
        }
        return gaps;
    }
    /**
     * Calculate summary statistics.
     * @req FR:req-traceability/analysis.coverage
     * @req FR:req-traceability/analysis.coverage.leaf-only
     * @req FR:req-traceability/priority.reporting
     */
    calculateSummary(requirements, coverageMap, featureTraceabilityModes) {
        let total = 0;
        let active = 0;
        let implemented = 0; // Has code annotations
        let tested = 0; // Has test annotations
        let covered = 0; // Has any annotation (code OR test)
        let uncovered = 0; // No annotations at all
        let deferred = 0;
        let deprecated = 0;
        let exempt = 0;
        // Track counts by priority
        const byPriority = { P1: 0, P2: 0, P3: 0, P4: 0, P5: 0 };
        const coveredByPriority = { P1: 0, P2: 0, P3: 0, P4: 0, P5: 0 };
        for (const req of requirements) {
            const coverage = coverageMap.get(req.id.qualified);
            if (!coverage) {
                continue;
            }
            // Skip parent requirements from coverage metrics (leaf-only)
            if (coverage.coverageStatus === 'parent') {
                continue;
            }
            total++;
            // Track priority counts for active requirements
            const priority = req.priority;
            const isActive = coverage.coverageStatus !== 'deferred' && coverage.coverageStatus !== 'deprecated' && coverage.coverageStatus !== 'exempt';
            if (isActive) {
                active++;
                byPriority[priority]++;
                // Count implemented (has code annotations) - independent of tests
                const hasCodeAnnotations = coverage.implementations.length > 0;
                if (hasCodeAnnotations) {
                    implemented++;
                }
                // Count tested (has test annotations) - independent of code
                const hasTestAnnotations = coverage.tests.length > 0;
                if (hasTestAnnotations) {
                    tested++;
                }
                // Count covered (has ANY annotation) - union
                // @req FR:req-traceability/scan.traceability-mode.disabled.output
                const mode = featureTraceabilityModes?.get(req.id.scope);
                const codeDisabled = mode?.code === 'disable';
                const testDisabled = mode?.test === 'disable';
                // When both code and test are disabled, no annotations are expected — count as covered
                // When only one is disabled, only require annotations for the enabled type
                const codeRequired = !codeDisabled;
                const testRequired = !testDisabled;
                if (!codeRequired && !testRequired) {
                    // Both disabled — always covered
                    covered++;
                    coveredByPriority[priority]++;
                }
                else if (hasCodeAnnotations || hasTestAnnotations) {
                    // At least one annotation exists for an enabled type
                    covered++;
                    coveredByPriority[priority]++;
                }
                else {
                    uncovered++;
                }
            }
            else if (coverage.coverageStatus === 'deferred') {
                deferred++;
            }
            else if (coverage.coverageStatus === 'deprecated') {
                deprecated++;
            }
            else if (coverage.coverageStatus === 'exempt') {
                exempt++;
            }
        }
        // Calculate percentages (avoid division by zero)
        const implementationCoverage = active > 0 ? Math.round((implemented / active) * 100) : 0;
        const testCoverage = active > 0 ? Math.round((tested / active) * 100) : 0;
        const overallCoverage = active > 0 ? Math.round((covered / active) * 100) : 0;
        // Calculate coverage percentage by priority (based on overall coverage)
        const coverageByPriority = {
            P1: byPriority.P1 > 0 ? Math.round((coveredByPriority.P1 / byPriority.P1) * 100) : 0,
            P2: byPriority.P2 > 0 ? Math.round((coveredByPriority.P2 / byPriority.P2) * 100) : 0,
            P3: byPriority.P3 > 0 ? Math.round((coveredByPriority.P3 / byPriority.P3) * 100) : 0,
            P4: byPriority.P4 > 0 ? Math.round((coveredByPriority.P4 / byPriority.P4) * 100) : 0,
            P5: byPriority.P5 > 0 ? Math.round((coveredByPriority.P5 / byPriority.P5) * 100) : 0,
        };
        // Calculate coverage and completeness scores
        // @req FR:req-traceability/report.content.scores.coverage
        // @req FR:req-traceability/report.content.scores.completeness
        const priorityThreshold = 'P3'; // TODO: Read from engineering.md
        const { coverageScore, completenessScore } = this.calculateScores(byPriority, coveredByPriority, priorityThreshold);
        return {
            total,
            active,
            implemented,
            tested,
            covered,
            uncovered,
            deferred,
            deprecated,
            exempt,
            implementationCoverage,
            testCoverage,
            overallCoverage,
            byPriority,
            coverageByPriority,
            coverageScore,
            completenessScore,
            priorityThreshold,
        };
    }
    /**
     * Calculate coverage and completeness scores.
     * @req FR:req-traceability/report.content.scores.coverage
     * @req FR:req-traceability/report.content.scores.completeness
     */
    calculateScores(byPriority, coveredByPriority, threshold) {
        const priorities = ['P1', 'P2', 'P3', 'P4', 'P5'];
        const thresholdIndex = priorities.indexOf(threshold);
        // Full weights by position: P1=5, P2=4, P3=3, P4=2, P5=1
        const fullWeights = {
            P1: 5, P2: 4, P3: 3, P4: 2, P5: 1
        };
        // Coverage score: % of requirements within threshold that are covered
        let withinThresholdTotal = 0;
        let withinThresholdCovered = 0;
        for (let i = 0; i <= thresholdIndex; i++) {
            const pri = priorities[i];
            withinThresholdTotal += byPriority[pri];
            withinThresholdCovered += coveredByPriority[pri];
        }
        const coverageScore = withinThresholdTotal > 0
            ? Math.round((withinThresholdCovered / withinThresholdTotal) * 100)
            : 100; // If no requirements within threshold, consider it 100%
        // Completeness score: weighted coverage across all priorities
        // Within threshold: full weight, Beyond threshold: half weight
        let totalWeight = 0;
        let coveredWeight = 0;
        for (let i = 0; i < priorities.length; i++) {
            const pri = priorities[i];
            const count = byPriority[pri];
            const coveredCount = coveredByPriority[pri];
            const isWithinThreshold = i <= thresholdIndex;
            // Weight per requirement at this priority
            const weight = isWithinThreshold
                ? fullWeights[pri]
                : fullWeights[pri] / 2; // Half weight beyond threshold
            totalWeight += count * weight;
            coveredWeight += coveredCount * weight;
        }
        const completenessScore = totalWeight > 0
            ? Math.round((coveredWeight / totalWeight) * 100)
            : 100; // If no requirements, consider it 100%
        return { coverageScore, completenessScore };
    }
}
exports.CoverageAnalyzer = CoverageAnalyzer;
//# sourceMappingURL=coverage-analyzer.js.map
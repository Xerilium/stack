"use strict";
/**
 * Expands path patterns (mixing directory prefixes and glob patterns) into
 * concrete directory paths usable as scan roots.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.expandPathPatterns = expandPathPatterns;
const glob_1 = require("glob");
/**
 * Resolve a list of path patterns to concrete paths.
 *
 * Entries containing `*` or `?` are expanded via `glob`. Other entries pass
 * through unchanged. Results are deduplicated while preserving first-seen order.
 *
 * @req FR:req-traceability/scan.code
 * @req FR:req-traceability/scan.tests
 */
async function expandPathPatterns(patterns) {
    const seen = new Set();
    const result = [];
    for (const pattern of patterns) {
        if (pattern.includes('*') || pattern.includes('?')) {
            const matches = await (0, glob_1.glob)(pattern);
            for (const match of matches) {
                if (!seen.has(match)) {
                    seen.add(match);
                    result.push(match);
                }
            }
        }
        else {
            if (!seen.has(pattern)) {
                seen.add(pattern);
                result.push(pattern);
            }
        }
    }
    return result;
}
//# sourceMappingURL=path-expander.js.map
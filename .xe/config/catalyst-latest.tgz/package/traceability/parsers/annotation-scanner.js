"use strict";
/**
 * Source code annotation scanner.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnnotationScanner = void 0;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const id_parser_js_1 = require("./id-parser.js");
const gitignore_parser_js_1 = require("./gitignore-parser.js");
/**
 * Path body matched after `{type}:{scope}/`. Loose by design — the captured ID
 * is re-validated by `parseQualifiedId`, which enforces sigil placement rules.
 * Includes `$` and `@` for entity/interface sigils per FR:id.format. Scope
 * accepts `/`-separated kebab segments for nested feature IDs (FR:feature-context/spec.@file.nesting).
 */
const ID_BODY = '[A-Z]+:[a-z0-9-]+(?:\\/[a-z0-9-]+)*\\/[$@a-z0-9.-]+';
/**
 * Regex pattern for `@req` annotations in code.
 * Matches:
 * - `@req FR:{feature}/path.to.req`
 * - `@req FR:{feature}/$entity` (entity FR)
 * - `@req FR:{feature}/path.@interface` (interface FR)
 * - `@req:partial FR:{feature}/path`
 * - `@req FR:{feature}/path1, FR:{feature}/path2` (comma-separated)
 *
 * @req FR:req-traceability/annotation.tag
 * @req FR:req-traceability/annotation.partial
 * @req FR:req-traceability/annotation.language-compat
 * @req FR:req-traceability/id.format.entity
 * @req FR:req-traceability/id.format.interface
 * @req NFR:req-traceability/compat.annotation-format
 */
const CODE_REQ_PATTERN = new RegExp(`@req(:partial)?\\s+(${ID_BODY})`, 'g');
/**
 * Pattern to detect if a line is a comment.
 * Matches lines that start with common comment prefixes (after optional whitespace):
 * - // or /// (JS/TS/C-style)
 * - # (Python/Shell/YAML)
 * - * or /** (JSDoc/block comments)
 * - <!-- (HTML/XML)
 * - ; (INI/assembly)
 * - -- (SQL/Lua)
 */
const COMMENT_LINE_PATTERN = /^\s*(\/\/|\/?\*|#|<!--|;|--)/;
/**
 * Pattern for extracting additional comma-separated IDs after an @req tag.
 * @req FR:req-traceability/id.format.entity
 * @req FR:req-traceability/id.format.interface
 */
const COMMA_SEP_PATTERN = new RegExp(`,\\s*(${ID_BODY})`, 'g');
/**
 * Pattern to detect code constructs that an @req annotation may be associated with.
 * Matches declarations (with optional export/default/abstract/async prefixes):
 * function, class, interface, const, let, var, type (not re-export), enum.
 * Does NOT match `export { }` or `export type { }` re-exports — those are cop-out patterns.
 * @req FR:req-traceability/annotation.file-level-detection
 */
const CODE_CONSTRUCT_PATTERN = /^\s*(export\s+)?(default\s+)?(abstract\s+)?(async\s+)?(function\s|class\s|interface\s|const\s|let\s|var\s|type\s(?!\{)|enum\s)/;
/**
 * Pattern to detect class method declarations.
 * Matches: optional access modifiers (private/protected/public/static/abstract/async/override/readonly)
 * followed by an identifier and `(` or `<` (for generic methods).
 * @req FR:req-traceability/annotation.file-level-detection
 */
const METHOD_CONSTRUCT_PATTERN = /^\s*(private\s+|protected\s+|public\s+|static\s+|abstract\s+|async\s+|override\s+|readonly\s+)*[a-zA-Z_$]\w*\s*[(<]/;
/**
 * Pattern to detect test constructs (describe, it, test) including .skip/.only variants.
 * @req FR:req-traceability/annotation.file-level-detection
 */
const TEST_CONSTRUCT_PATTERN = /^\s*(describe|it|test)\s*(\.\w+\s*)?\(/;
/**
 * Number of lines to look ahead from an annotation to find a code construct.
 * @req FR:req-traceability/annotation.file-level-detection
 */
const FILE_LEVEL_LOOKAHEAD = 3;
/**
 * Scanner for @req annotations in source code files.
 */
class AnnotationScanner {
    /**
     * Scan a single file for @req annotations.
     * @req FR:req-traceability/annotation.single-line
     * @req FR:req-traceability/annotation.block
     * @req FR:req-traceability/annotation.multi-line
     * @req FR:req-traceability/annotation.multi-inline
     * @req FR:req-traceability/annotation.tests
     */
    async scanFile(filePath, isTest) {
        const annotations = [];
        try {
            const content = await fs.readFile(filePath, 'utf-8');
            const lines = content.split('\n');
            // Language-agnostic guard: annotations are only read from comment lines
            // (COMMENT_LINE_PATTERN), so string contents in any language are ignored
            // unless a string line itself looks like a comment. Multi-line string
            // tracking is an opt-in refinement per language, enabled only where the
            // delimiter is unambiguous. JS/TS backticks qualify; elsewhere a backtick
            // means something else (PowerShell escape, shell command substitution,
            // Markdown code), and toggling on it would silently drop every later
            // annotation. Missing a refinement only risks a false positive; a wrong
            // one loses annotations, so default to off.
            const trackTemplateLiterals = this.isJsTsFile(filePath);
            // Track template literal state across lines
            let insideTemplateLiteral = false;
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (trackTemplateLiterals) {
                    // Update template literal state based on backticks in this line
                    // Count unescaped backticks to toggle state
                    const backtickCount = this.countUnescapedBackticks(line);
                    const wasInsideTemplateLiteral = insideTemplateLiteral;
                    // Odd number of backticks toggles the state
                    if (backtickCount % 2 === 1) {
                        insideTemplateLiteral = !insideTemplateLiteral;
                    }
                    // Skip annotation extraction if we're inside a template literal
                    // (either started on previous line, or line starts inside one)
                    if (wasInsideTemplateLiteral) {
                        continue;
                    }
                }
                const lineAnnotations = this.extractAnnotationsFromLine(line, filePath, i + 1, // 1-indexed
                isTest);
                // Determine if this annotation is at file level (no code construct nearby)
                // @req FR:req-traceability/annotation.placement
                if (lineAnnotations.length > 0) {
                    const fileLevel = this.isFileLevelAnnotation(lines, i, isTest);
                    for (const ann of lineAnnotations) {
                        ann.isFileLevel = fileLevel;
                    }
                }
                annotations.push(...lineAnnotations);
            }
        }
        catch (error) {
            // File doesn't exist or can't be read - return empty array
        }
        return annotations;
    }
    /**
     * Count unescaped backticks in a line, ignoring backticks inside
     * string literals ('...', "..."), regex literals (/.../), and
     * single-line comments (//). Properly skips template literal
     * content between backtick pairs to avoid false regex detection.
     * @req FR:req-traceability/scan.code
     */
    countUnescapedBackticks(line) {
        let count = 0;
        let i = 0;
        while (i < line.length) {
            const ch = line[i];
            // Single-line comment — rest of line is comment, no backticks to count
            if (ch === '/' && line[i + 1] === '/') {
                break;
            }
            // Single or double-quoted string — skip to closing quote
            if (ch === "'" || ch === '"') {
                i++;
                while (i < line.length && line[i] !== ch) {
                    if (line[i] === '\\')
                        i++; // skip escaped char
                    i++;
                }
                i++; // skip closing quote
                continue;
            }
            // Regex literal — skip to closing /
            // A `/` starts a regex (not division) when preceded by an operator,
            // keyword, or at line start.
            if (ch === '/' && line[i + 1] !== '*') {
                const before = line.substring(0, i).trimEnd();
                const isRegex = !before || /[=(!&|?:,;{}\[~^+\-*/%<>]$/.test(before)
                    || before.endsWith('return') || before.endsWith('typeof');
                if (isRegex) {
                    i++; // skip opening /
                    while (i < line.length && line[i] !== '/') {
                        if (line[i] === '\\')
                            i++; // skip escaped char
                        i++;
                    }
                    i++; // skip closing /
                    continue;
                }
            }
            // Backtick — count it, then skip template literal content
            // Content between backticks can contain `/` after `}` (e.g., `${x}/`)
            // which the regex heuristic above would misidentify as a regex literal.
            if (ch === '\x60') {
                let backslashCount = 0;
                for (let j = i - 1; j >= 0 && line[j] === '\\'; j--) {
                    backslashCount++;
                }
                if (backslashCount % 2 === 0) {
                    count++;
                    // Skip template literal content to avoid false regex/string detection.
                    // Scan forward for closing backtick, handling ${...} expressions.
                    i++;
                    let braceDepth = 0;
                    while (i < line.length) {
                        if (line[i] === '\\') {
                            i += 2; // skip escaped char
                            continue;
                        }
                        if (braceDepth === 0 && line[i] === '\x60') {
                            // Closing backtick — count it and break
                            count++;
                            break;
                        }
                        if (line[i] === '$' && line[i + 1] === '{') {
                            braceDepth++;
                            i += 2;
                            continue;
                        }
                        if (braceDepth > 0 && line[i] === '}') {
                            braceDepth--;
                        }
                        i++;
                    }
                }
            }
            i++;
        }
        return count;
    }
    /**
     * Scan a directory recursively for @req annotations.
     * Returns both the annotations found and the total number of source files traversed.
     * @req FR:req-traceability/scan.code
     * @req FR:req-traceability/scan.tests
     * @req FR:req-traceability/scan.gitignore
     * @req FR:req-traceability/scan.gitignore.hierarchical
     * @req FR:req-traceability/report.content.metrics.files-scanned
     */
    async scanDirectory(dirPath, options) {
        const annotations = [];
        let filesTraversed = 0;
        try {
            // Load .gitignore patterns from every directory between cwd and the scan
            // dir (inclusive) so root-anchored patterns like src/**/*.js are honored.
            // Per-subdirectory .gitignore files are loaded as we descend (see
            // scanDirectoryRecursive), so only the ancestor chain needs pre-loading here.
            let gitignorePatterns = [];
            if (options.respectGitignore) {
                const cwd = process.cwd();
                const resolvedDir = path.resolve(dirPath);
                // Walk from cwd down to the scan dir, collecting .gitignore files.
                // Each file's patterns are prefixed with that dir's cwd-relative path
                // so they remain cwd-relative in the exclude set.
                let current = cwd;
                while (true) {
                    const rel = path.relative(cwd, current);
                    const patterns = await this.loadGitignorePatterns(current);
                    // Prefix patterns with the directory's relative path (empty string for root)
                    const prefixed = rel
                        ? patterns.map((p) => p.startsWith('**/') ? p : `${rel}/${p}`)
                        : patterns;
                    gitignorePatterns = [...gitignorePatterns, ...prefixed];
                    if (path.resolve(current) === resolvedDir)
                        break;
                    const next = path.join(current, path.relative(current, resolvedDir).split(path.sep)[0]);
                    if (next === current)
                        break;
                    current = next;
                }
            }
            const mergedExclude = [...options.exclude, ...gitignorePatterns];
            const mergedOptions = { ...options, exclude: mergedExclude };
            const counter = { filesTraversed: 0 };
            await this.scanDirectoryRecursive(dirPath, dirPath, mergedOptions, annotations, counter);
            filesTraversed = counter.filesTraversed;
        }
        catch (error) {
            // Directory doesn't exist - return empty result
        }
        return { annotations, filesTraversed };
    }
    /**
     * Load .gitignore patterns from the directory.
     * @req FR:req-traceability/scan.gitignore
     */
    async loadGitignorePatterns(dirPath) {
        const gitignorePath = path.join(dirPath, '.gitignore');
        try {
            const content = await fs.readFile(gitignorePath, 'utf-8');
            return (0, gitignore_parser_js_1.parseGitignore)(content);
        }
        catch {
            // No .gitignore or can't read - return empty
            return [];
        }
    }
    /**
     * Recursively scan directory for files.
     * @req FR:req-traceability/scan.gitignore.hierarchical
     * @req FR:req-traceability/report.content.metrics.files-scanned
     */
    async scanDirectoryRecursive(basePath, currentPath, options, annotations, counter) {
        const entries = await fs.readdir(currentPath, { withFileTypes: true });
        // Pick up any .gitignore in this directory and merge into options for subdirs.
        // Patterns are prefixed with this dir's cwd-relative path so they stay cwd-relative.
        let subdirOptions = options;
        if (options.respectGitignore) {
            const localPatterns = await this.loadGitignorePatterns(currentPath);
            if (localPatterns.length > 0) {
                const rel = path.relative(process.cwd(), currentPath);
                const prefixed = rel
                    ? localPatterns.map((p) => p.startsWith('**/') ? p : `${rel}/${p}`)
                    : localPatterns;
                subdirOptions = { ...options, exclude: [...options.exclude, ...prefixed] };
            }
        }
        const promises = [];
        for (const entry of entries) {
            const fullPath = path.join(currentPath, entry.name);
            const relativePath = path.relative(basePath, fullPath);
            const cwdRelativePath = path.relative(process.cwd(), fullPath);
            // Check exclude patterns against both scan-dir-relative and cwd-relative paths.
            // Gitignore patterns include the scan dir prefix (e.g. src/**/*.js), so they
            // only match against the cwd-relative path.
            if (this.shouldExclude(relativePath, subdirOptions.exclude) ||
                this.shouldExclude(cwdRelativePath, subdirOptions.exclude)) {
                continue;
            }
            if (entry.isDirectory()) {
                promises.push(this.scanDirectoryRecursive(basePath, fullPath, subdirOptions, annotations, counter));
            }
            else if (entry.isFile() && this.isSourceFile(entry.name)) {
                counter.filesTraversed++;
                const isTest = this.isTestFile(fullPath, options.testPaths);
                promises.push(this.scanFile(fullPath, isTest).then((fileAnnotations) => {
                    annotations.push(...fileAnnotations);
                }));
            }
        }
        await Promise.all(promises);
    }
    /**
     * Extract all @req annotations from a single line.
     * Only extracts annotations from comment lines to avoid false positives
     * from string literals containing @req patterns.
     * @req FR:req-traceability/annotation.multi-line
     * @req FR:req-traceability/annotation.multi-inline
     */
    // @req FR:req-traceability/annotation.multi-line
    // @req FR:req-traceability/annotation.multi-inline
    // @req FR:req-traceability/annotation.tests
    extractAnnotationsFromLine(line, filePath, lineNumber, isTest) {
        const annotations = [];
        // Only extract annotations from comment lines to avoid false positives
        // from string literals in test files that contain @req patterns
        if (!COMMENT_LINE_PATTERN.test(line)) {
            return annotations;
        }
        // Skip lines that appear to be inside template literals or string assignments
        // These patterns indicate the line content is a string value, not actual code
        if (this.isInsideStringLiteral(line, filePath)) {
            return annotations;
        }
        // Reset regex lastIndex
        CODE_REQ_PATTERN.lastIndex = 0;
        let match;
        while ((match = CODE_REQ_PATTERN.exec(line)) !== null) {
            // match[1] is the :partial marker (or undefined)
            // match[2] is the first requirement ID
            const isPartial = match[1] === ':partial';
            const idString = match[2];
            const id = (0, id_parser_js_1.parseQualifiedId)(idString);
            if (id) {
                annotations.push({
                    id,
                    file: filePath,
                    line: lineNumber,
                    isPartial,
                    isTest,
                    isFileLevel: false, // Default; overridden by scanFile()
                });
            }
            // Check for comma-separated IDs after this match
            // Get the rest of the line after this match
            const afterMatch = line.substring(match.index + match[0].length);
            COMMA_SEP_PATTERN.lastIndex = 0;
            let commaMatch;
            while ((commaMatch = COMMA_SEP_PATTERN.exec(afterMatch)) !== null) {
                const commaIdString = commaMatch[1];
                const commaId = (0, id_parser_js_1.parseQualifiedId)(commaIdString);
                if (commaId) {
                    annotations.push({
                        id: commaId,
                        file: filePath,
                        line: lineNumber,
                        isPartial: false, // comma-separated IDs are not partial
                        isTest,
                        isFileLevel: false, // Default; overridden by scanFile()
                    });
                }
            }
        }
        return annotations;
    }
    /**
     * Determine if an annotation at the given line index is file-level.
     * If the annotation is inside a JSDoc block, looks for a code construct
     * after the closing `*​/`. Otherwise, looks within FILE_LEVEL_LOOKAHEAD lines.
     * @req FR:req-traceability/annotation.file-level-detection
     * @req FR:req-traceability/analysis.convention-tests.no-file-level
     * @req FR:req-traceability/annotation.placement
     */
    isFileLevelAnnotation(lines, annotationLineIndex, isTest) {
        // Determine if we're inside a JSDoc block by scanning backwards
        const inJsDoc = this.isInsideJsDocBlock(lines, annotationLineIndex);
        if (inJsDoc) {
            // Find the closing */ of the JSDoc block, then look for a construct after it
            let searchStartIndex = annotationLineIndex + 1;
            for (let j = annotationLineIndex + 1; j < lines.length; j++) {
                if (lines[j].trimEnd().endsWith('*/')) {
                    searchStartIndex = j + 1;
                    break;
                }
            }
            // Look for a code construct within the look-ahead window after the JSDoc end
            const endIndex = Math.min(searchStartIndex + FILE_LEVEL_LOOKAHEAD, lines.length);
            for (let j = searchStartIndex; j < endIndex; j++) {
                const trimmed = lines[j].trim();
                if (trimmed === '')
                    continue; // Skip blank lines between JSDoc and construct
                if (this.isCodeConstruct(lines[j], isTest)) {
                    return false;
                }
                // Found non-blank, non-construct line — it's file-level
                return true;
            }
            return true;
        }
        // Non-JSDoc: original behavior — check next N lines strictly
        const endIndex = Math.min(annotationLineIndex + FILE_LEVEL_LOOKAHEAD + 1, lines.length);
        for (let j = annotationLineIndex + 1; j < endIndex; j++) {
            const line = lines[j];
            if (this.isCodeConstruct(line, isTest)) {
                return false;
            }
        }
        return true;
    }
    /**
     * Check if the given line index is inside a JSDoc block.
     * Scans backwards from the line to find an opening `/**` without a closing `*​/`.
     */
    isInsideJsDocBlock(lines, lineIndex) {
        for (let j = lineIndex; j >= 0; j--) {
            const trimmed = lines[j].trim();
            if (trimmed.startsWith('/**')) {
                return true;
            }
            // If we hit a closing */ before finding /**, we're not in a JSDoc
            if (j < lineIndex && trimmed.endsWith('*/')) {
                return false;
            }
        }
        return false;
    }
    /**
     * Check if a line matches any code construct pattern.
     */
    isCodeConstruct(line, isTest) {
        if (CODE_CONSTRUCT_PATTERN.test(line))
            return true;
        if (METHOD_CONSTRUCT_PATTERN.test(line))
            return true;
        if (isTest && TEST_CONSTRUCT_PATTERN.test(line))
            return true;
        return false;
    }
    /**
     * Check if a file should be excluded based on patterns.
     * @req FR:req-traceability/scan.exclude
     */
    shouldExclude(relativePath, excludePatterns) {
        for (const pattern of excludePatterns) {
            if (this.matchGlobPattern(relativePath, pattern)) {
                return true;
            }
        }
        return false;
    }
    /**
     * Simple glob pattern matching.
     * Supports ** for any path and * for any file/folder name.
     */
    matchGlobPattern(filePath, pattern) {
        // Normalize path separators
        const normalizedPath = filePath.replace(/\\/g, '/');
        const normalizedPattern = pattern.replace(/\\/g, '/');
        // Convert glob pattern to regex
        // Use placeholders for ** patterns to avoid interference with * replacement
        let regexPattern = normalizedPattern
            // Escape regex special chars except * and /
            .replace(/[.+?^${}()|[\]]/g, '\\$&')
            // Replace **/ at start or middle with placeholder
            .replace(/\*\*\//g, '\x00STARSTAR_SLASH\x00')
            // Replace /** at end with placeholder
            .replace(/\/\*\*$/g, '\x00SLASH_STARSTAR\x00')
            // Replace remaining ** with placeholder
            .replace(/\*\*/g, '\x00STARSTAR\x00')
            // Replace * with single segment match
            .replace(/\*/g, '[^/]*')
            // Now replace placeholders with actual regex patterns
            .replace(/\x00STARSTAR_SLASH\x00/g, '(?:.*\\/)?')
            .replace(/\x00SLASH_STARSTAR\x00/g, '(?:\\/.*)?')
            .replace(/\x00STARSTAR\x00/g, '.*');
        const regex = new RegExp(`^${regexPattern}$`);
        return regex.test(normalizedPath);
    }
    /**
     * Check if a line appears to be inside a string literal.
     * Detects lines that are part of template literals or string assignments
     * by looking for patterns like backticks, quotes before the @req, or
     * string assignment patterns.
     * Backtick is only treated as a string delimiter for JS/TS files — in other
     * languages (e.g. PowerShell) a backtick before `@req` is not a string marker.
     */
    isInsideStringLiteral(line, filePath) {
        // Check if line contains a backtick before @req (template literal)
        const reqIndex = line.indexOf('@req');
        if (reqIndex === -1)
            return false;
        const beforeReq = line.substring(0, reqIndex);
        const isJsTs = this.isJsTsFile(filePath);
        // If there's a backtick (JS/TS only), single quote, or double quote before
        // @req, this line is likely inside a string literal
        if ((isJsTs && beforeReq.includes('`')) || beforeReq.includes('"') || beforeReq.includes("'")) {
            return true;
        }
        // Check for common string assignment patterns at start of line
        // e.g., "const content = `// @req" or "await fs.writeFile(..., `// @req"
        const quoteClass = isJsTs ? '`\'"' : '\'"';
        const stringAssignmentPattern = new RegExp(`^\\s*(const|let|var|=|,|\\()\\s*.*[${quoteClass}]`);
        if (stringAssignmentPattern.test(beforeReq)) {
            return true;
        }
        return false;
    }
    /**
     * Check if a file is JS/TS-family, where backtick is a string/template-literal
     * delimiter. Other languages (e.g. PowerShell) use backtick for escaping/line
     * continuation, so backtick-based string-literal detection does not apply.
     */
    isJsTsFile(filePath) {
        return /\.(ts|tsx|js|jsx|mjs|cjs)$/i.test(filePath);
    }
    /**
     * Check if a file should be scanned for @req annotations.
     * Uses a denylist of build artifacts, compiled binaries, lockfiles, and media —
     * any file not on the denylist is scanned. Honors the user's `srcDirs`/`exclude`
     * config as the source of truth for what to scan; this filter only skips files
     * whose contents cannot meaningfully contain `@req` annotations.
     * @req FR:req-traceability/scan.code.discovery
     */
    isSourceFile(filename) {
        const lower = filename.toLowerCase();
        // Build artifacts and generated files
        if (lower.endsWith('.d.ts'))
            return false;
        if (lower.endsWith('.min.js') || lower.endsWith('.min.css'))
            return false;
        if (lower.endsWith('.map'))
            return false; // source maps
        const lastDot = lower.lastIndexOf('.');
        if (lastDot === -1 || lastDot === 0) {
            // No extension or dotfile — skip (e.g. .gitignore, LICENSE)
            return false;
        }
        const ext = lower.slice(lastDot + 1);
        // Denylist: extensions whose files cannot meaningfully contain @req annotations.
        // Grouped by category for maintainability.
        const denylist = new Set([
            // Compiled binaries / bytecode
            'exe', 'dll', 'so', 'dylib', 'a', 'o', 'obj', 'lib',
            'class', 'jar', 'war', 'ear',
            'pyc', 'pyo', 'pyd',
            'wasm',
            // Archives
            'zip', 'tar', 'gz', 'tgz', 'bz2', 'xz', '7z', 'rar',
            // Images
            'png', 'jpg', 'jpeg', 'gif', 'bmp', 'ico', 'webp', 'tiff', 'tif', 'svg', 'avif',
            // Fonts
            'woff', 'woff2', 'ttf', 'otf', 'eot',
            // Audio / video
            'mp3', 'mp4', 'wav', 'ogg', 'flac', 'avi', 'mov', 'mkv', 'webm',
            // Documents (binary)
            'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
            // Lockfiles (machine-generated, no human annotations)
            'lock',
            // Datastores / databases
            'db', 'sqlite', 'sqlite3',
        ]);
        return !denylist.has(ext);
    }
    /**
     * Check if a file matches any test path pattern (directory prefix or glob).
     * @req FR:req-traceability/scan.tests
     */
    isTestFile(filePath, testPaths) {
        const normalizedPath = filePath.replace(/\\/g, '/');
        return testPaths.some((pattern) => {
            const normalizedPattern = pattern.replace(/\\/g, '/');
            if (normalizedPattern.includes('*') || normalizedPattern.includes('?')) {
                return this.matchGlobPattern(normalizedPath, normalizedPattern);
            }
            return normalizedPath.includes(normalizedPattern);
        });
    }
}
exports.AnnotationScanner = AnnotationScanner;
//# sourceMappingURL=annotation-scanner.js.map
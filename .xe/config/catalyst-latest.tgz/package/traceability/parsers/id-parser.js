"use strict";
/**
 * Requirement ID parser.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.describeShortIdParseFailure = describeShortIdParseFailure;
exports.parseShortFormId = parseShortFormId;
exports.parseQualifiedId = parseQualifiedId;
exports.parseRequirementId = parseRequirementId;
exports.buildQualifiedId = buildQualifiedId;
exports.isValidRequirementId = isValidRequirementId;
// Valid requirement types
const VALID_TYPES = ['FR', 'NFR', 'REQ'];
// Maximum path depth (5 levels)
const MAX_PATH_DEPTH = 5;
/**
 * Path token: `[a-z0-9][a-z0-9-]*` — kebab-cased segment.
 * Sigils:
 * - `$` allowed only at start of full path (entity FR; FR:req-traceability/id.format.entity)
 * - `@` allowed at start of full path OR immediately after `.` on any nested token (interface FR; FR:req-traceability/id.format.interface)
 * - `$` and `@` are mutually exclusive on the same path
 */
const PATH_PATTERN = '(?:\\$|@)?[a-z0-9][a-z0-9-]*(?:\\.@?[a-z0-9][a-z0-9-]*)*';
/**
 * Regex for short-form ID: FR:path.to.req
 * @req FR:req-traceability/id.format.short
 * @req FR:req-traceability/id.format.entity
 * @req FR:req-traceability/id.format.interface
 */
const SHORT_FORM_PATTERN = new RegExp(`^(FR|NFR|REQ):(${PATH_PATTERN})$`);
/**
 * Scope: one or more kebab-cased segments separated by `/` to support nested feature
 * IDs (FR:feature-context/spec.@file.nesting). Split between scope and path is at the
 * last `/` — path always begins with a kebab token (optionally prefixed by `$`/`@`).
 */
const SCOPE_PATTERN = '[a-z0-9][a-z0-9-]*(?:/[a-z0-9][a-z0-9-]*)*';
/**
 * Regex for qualified ID: `FR:{feature}/path.to.req`
 * @req FR:req-traceability/id.format.full
 * @req FR:req-traceability/id.format.entity
 * @req FR:req-traceability/id.format.interface
 */
const QUALIFIED_PATTERN = new RegExp(`^(FR|NFR|REQ):(${SCOPE_PATTERN})\\/(${PATH_PATTERN})$`);
/**
 * Validates a path and describes why it's invalid, or returns null if valid.
 */
function describePathError(path) {
    // Check for empty path
    if (!path || path.length === 0) {
        return 'empty path';
    }
    // Check for consecutive dots
    if (path.includes('..')) {
        return 'path contains consecutive dots';
    }
    // Check for leading/trailing dots
    if (path.startsWith('.') || path.endsWith('.')) {
        return 'path starts or ends with a dot';
    }
    // Check depth
    const depth = path.split('.').length;
    if (depth > MAX_PATH_DEPTH) {
        return `path depth ${depth} exceeds the maximum of ${MAX_PATH_DEPTH} levels ("${path}")`;
    }
    return null;
}
/**
 * Validates that a path doesn't have invalid patterns.
 */
function isValidPath(path) {
    return describePathError(path) === null;
}
/**
 * Describe why a short-form `type:path` ID failed to parse, for diagnostic
 * warnings. Intended for callers that already matched a requirement-shaped
 * line (e.g. via the spec bold/heading pattern) but got `null` back from
 * `parseShortFormId` — so the caller can report why instead of silently
 * dropping the requirement.
 * @req FR:req-traceability/id.format.short
 */
function describeShortIdParseFailure(typeStr, path) {
    if (!VALID_TYPES.includes(typeStr)) {
        return `unknown requirement type "${typeStr}" (expected FR, NFR, or REQ)`;
    }
    return describePathError(path) ?? 'does not match the expected ID format';
}
/**
 * Parse a short-form requirement ID (e.g., "FR:auth.session").
 * Returns null if the ID is invalid.
 * @req FR:req-traceability/id.format.short
 */
function parseShortFormId(idString) {
    const match = idString.match(SHORT_FORM_PATTERN);
    if (!match) {
        return null;
    }
    const [, typeStr, path] = match;
    const type = typeStr;
    if (!VALID_TYPES.includes(type)) {
        return null;
    }
    if (!isValidPath(path)) {
        return null;
    }
    return {
        type,
        scope: '',
        path,
        qualified: '', // Will be set when scope is known
        short: `${type}:${path}`,
    };
}
/**
 * Parse a qualified requirement ID (e.g., "FR:auth/session.expiry").
 * Returns null if the ID is invalid.
 * @req FR:req-traceability/id.format.full
 */
function parseQualifiedId(idString) {
    const match = idString.match(QUALIFIED_PATTERN);
    if (!match) {
        return null;
    }
    const [, typeStr, scope, path] = match;
    const type = typeStr;
    if (!VALID_TYPES.includes(type)) {
        return null;
    }
    if (!isValidPath(path)) {
        return null;
    }
    return {
        type,
        scope,
        path,
        qualified: `${type}:${scope}/${path}`,
        short: `${type}:${path}`,
    };
}
/**
 * Parse any valid requirement ID (auto-detect format).
 * Returns null if the ID is invalid.
 * @req FR:req-traceability/id.format
 * @req FR:req-traceability/id.format.short
 * @req FR:req-traceability/id.format.full
 */
function parseRequirementId(idString) {
    // Try qualified first (more specific)
    const qualified = parseQualifiedId(idString);
    if (qualified) {
        return qualified;
    }
    // Fall back to short-form
    return parseShortFormId(idString);
}
/**
 * Build a qualified ID from a short-form ID and scope.
 * If the ID already has a scope, returns it unchanged.
 * @req FR:req-traceability/id.format
 */
function buildQualifiedId(id, scope) {
    if (id.scope) {
        // Already has scope, return as-is
        return id;
    }
    return {
        ...id,
        scope,
        qualified: `${id.type}:${scope}/${id.path}`,
    };
}
/**
 * Check if a string is a valid requirement ID.
 * @req FR:req-traceability/id.format
 */
function isValidRequirementId(idString) {
    return parseRequirementId(idString) !== null;
}
//# sourceMappingURL=id-parser.js.map
"use strict";
/**
 * Requirement Traceability - Public API
 *
 * This module provides bidirectional linking between requirements defined
 * in spec files and their implementations in code/tests.
 *
 * @example
 * ```typescript
 * import {
 *   SpecParser,
 *   AnnotationScanner,
 *   CoverageAnalyzer,
 *   generateJsonReport,
 *   generateTerminalReport,
 * } from '@catalyst/traceability';
 *
 * // Parse all specs
 * const specParser = new SpecParser();
 * const requirements = await specParser.parseDirectory('.xe/features/');
 *
 * // Scan source code
 * const scanner = new AnnotationScanner();
 * const { annotations, filesTraversed } = await scanner.scanDirectory('src/', {
 *   exclude: ['** /node_modules/**'],
 *   testPaths: ['tests/', '**\/*.test.*'],
 *   respectGitignore: true,
 * });
 *
 * // Analyze coverage
 * const analyzer = new CoverageAnalyzer();
 * const report = analyzer.analyze(requirements, annotations);
 *
 * // Output
 * console.log(generateTerminalReport(report));
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.runDependencyAnalysis = exports.runTraceabilityAnalysis = exports.checkThresholds = exports.getDefaultScanOptions = exports.loadConfig = exports.generateDependencyMermaidReport = exports.generateDependencyJsonReport = exports.generateDependencyTextReport = exports.truncateList = exports.stripFeaturePrefix = exports.renderSegmentedBar = exports.renderProgressBar = exports.formatFeatureSummary = exports.formatFeatureDetail = exports.formatFeatureSummaryLine = exports.generateTerminalReport = exports.generateJsonReport = exports.DependencyAnalyzer = exports.CoverageAnalyzer = exports.isValidRequirementId = exports.buildQualifiedId = exports.parseQualifiedId = exports.parseShortFormId = exports.parseRequirementId = exports.DependencyScanner = exports.AnnotationScanner = exports.SpecParser = void 0;
// Parsers
var spec_parser_js_1 = require("./parsers/spec-parser.js");
Object.defineProperty(exports, "SpecParser", { enumerable: true, get: function () { return spec_parser_js_1.SpecParser; } });
var annotation_scanner_js_1 = require("./parsers/annotation-scanner.js");
Object.defineProperty(exports, "AnnotationScanner", { enumerable: true, get: function () { return annotation_scanner_js_1.AnnotationScanner; } });
var dependency_scanner_js_1 = require("./parsers/dependency-scanner.js");
Object.defineProperty(exports, "DependencyScanner", { enumerable: true, get: function () { return dependency_scanner_js_1.DependencyScanner; } });
var id_parser_js_1 = require("./parsers/id-parser.js");
Object.defineProperty(exports, "parseRequirementId", { enumerable: true, get: function () { return id_parser_js_1.parseRequirementId; } });
Object.defineProperty(exports, "parseShortFormId", { enumerable: true, get: function () { return id_parser_js_1.parseShortFormId; } });
Object.defineProperty(exports, "parseQualifiedId", { enumerable: true, get: function () { return id_parser_js_1.parseQualifiedId; } });
Object.defineProperty(exports, "buildQualifiedId", { enumerable: true, get: function () { return id_parser_js_1.buildQualifiedId; } });
Object.defineProperty(exports, "isValidRequirementId", { enumerable: true, get: function () { return id_parser_js_1.isValidRequirementId; } });
// Analysis
var coverage_analyzer_js_1 = require("./analysis/coverage-analyzer.js");
Object.defineProperty(exports, "CoverageAnalyzer", { enumerable: true, get: function () { return coverage_analyzer_js_1.CoverageAnalyzer; } });
var dependency_analyzer_js_1 = require("./analysis/dependency-analyzer.js");
Object.defineProperty(exports, "DependencyAnalyzer", { enumerable: true, get: function () { return dependency_analyzer_js_1.DependencyAnalyzer; } });
// Reports
var json_reporter_js_1 = require("./reports/json-reporter.js");
Object.defineProperty(exports, "generateJsonReport", { enumerable: true, get: function () { return json_reporter_js_1.generateJsonReport; } });
var terminal_reporter_js_1 = require("./reports/terminal-reporter.js");
Object.defineProperty(exports, "generateTerminalReport", { enumerable: true, get: function () { return terminal_reporter_js_1.generateTerminalReport; } });
Object.defineProperty(exports, "formatFeatureSummaryLine", { enumerable: true, get: function () { return terminal_reporter_js_1.formatFeatureSummaryLine; } });
Object.defineProperty(exports, "formatFeatureDetail", { enumerable: true, get: function () { return terminal_reporter_js_1.formatFeatureDetail; } });
Object.defineProperty(exports, "formatFeatureSummary", { enumerable: true, get: function () { return terminal_reporter_js_1.formatFeatureSummary; } });
Object.defineProperty(exports, "renderProgressBar", { enumerable: true, get: function () { return terminal_reporter_js_1.renderProgressBar; } });
Object.defineProperty(exports, "renderSegmentedBar", { enumerable: true, get: function () { return terminal_reporter_js_1.renderSegmentedBar; } });
Object.defineProperty(exports, "stripFeaturePrefix", { enumerable: true, get: function () { return terminal_reporter_js_1.stripFeaturePrefix; } });
Object.defineProperty(exports, "truncateList", { enumerable: true, get: function () { return terminal_reporter_js_1.truncateList; } });
var dependency_reporter_js_1 = require("./reports/dependency-reporter.js");
Object.defineProperty(exports, "generateDependencyTextReport", { enumerable: true, get: function () { return dependency_reporter_js_1.generateDependencyTextReport; } });
Object.defineProperty(exports, "generateDependencyJsonReport", { enumerable: true, get: function () { return dependency_reporter_js_1.generateDependencyJsonReport; } });
Object.defineProperty(exports, "generateDependencyMermaidReport", { enumerable: true, get: function () { return dependency_reporter_js_1.generateDependencyMermaidReport; } });
// Config
var traceability_config_js_1 = require("./config/traceability-config.js");
Object.defineProperty(exports, "loadConfig", { enumerable: true, get: function () { return traceability_config_js_1.loadConfig; } });
Object.defineProperty(exports, "getDefaultScanOptions", { enumerable: true, get: function () { return traceability_config_js_1.getDefaultScanOptions; } });
Object.defineProperty(exports, "checkThresholds", { enumerable: true, get: function () { return traceability_config_js_1.checkThresholds; } });
// Runner (high-level API)
var runner_js_1 = require("./runner.js");
Object.defineProperty(exports, "runTraceabilityAnalysis", { enumerable: true, get: function () { return runner_js_1.runTraceabilityAnalysis; } });
Object.defineProperty(exports, "runDependencyAnalysis", { enumerable: true, get: function () { return runner_js_1.runDependencyAnalysis; } });
//# sourceMappingURL=index.js.map
"use strict";
/**
 * Traceability runner - High-level API for running traceability analysis.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.runTraceabilityAnalysis = runTraceabilityAnalysis;
exports.runDependencyAnalysis = runDependencyAnalysis;
const fs = __importStar(require("fs"));
const spec_parser_js_1 = require("./parsers/spec-parser.js");
const annotation_scanner_js_1 = require("./parsers/annotation-scanner.js");
const path_expander_js_1 = require("./parsers/path-expander.js");
const coverage_analyzer_js_1 = require("./analysis/coverage-analyzer.js");
const dependency_scanner_js_1 = require("./parsers/dependency-scanner.js");
const dependency_analyzer_js_1 = require("./analysis/dependency-analyzer.js");
const traceability_config_js_1 = require("./config/traceability-config.js");
const PRIORITY_ORDER = ['P1', 'P2', 'P3', 'P4', 'P5'];
/**
 * Check if a priority meets the minimum threshold.
 * @req FR:req-traceability/priority.filtering
 */
function meetsPriorityThreshold(priority, minPriority) {
    return PRIORITY_ORDER.indexOf(priority) <= PRIORITY_ORDER.indexOf(minPriority);
}
/**
 * List every feature ID under `featuresDir` recursively — a feature dir is any
 * directory containing `spec.md`; ID = path relative to `featuresDir` joined
 * with `/`. Honors FR:feature-context/spec.@file.nesting.
 */
function listFeatureIds(featuresDir) {
    const normalized = featuresDir.endsWith("/")
        ? featuresDir.slice(0, -1)
        : featuresDir;
    const found = [];
    const walk = (currentDir) => {
        for (const dirent of fs.readdirSync(currentDir, { withFileTypes: true })) {
            if (!dirent.isDirectory()) {
                continue;
            }
            const childDir = `${currentDir}/${dirent.name}`;
            if (fs.existsSync(`${childDir}/spec.md`)) {
                found.push(childDir.slice(normalized.length + 1).replace(/\\/g, "/"));
            }
            else {
                walk(childDir);
            }
        }
    };
    walk(normalized);
    return found;
}
/**
 * Run traceability analysis with the given options.
 *
 * This is the primary high-level API for running traceability analysis.
 * It handles:
 * - Parsing spec files from features/initiatives
 * - Scanning source code for @req annotations
 * - Analyzing coverage and generating a report
 *
 * @param options - Configuration options for the analysis
 * @returns The traceability report and metadata
 *
 * @example
 * ```typescript
 * // Run analysis for all features
 * const result = await runTraceabilityAnalysis();
 * console.log(result.report.summary);
 *
 * // Run analysis for a single feature
 * const result = await runTraceabilityAnalysis({
 *   featureFilter: 'ai-provider-claude',
 * });
 *
 * // Run with custom priority threshold
 * const result = await runTraceabilityAnalysis({
 *   minPriority: 'S2',
 * });
 * ```
 *
 * @req FR:req-traceability/scan.code
 * @req FR:req-traceability/scan.tests
 * @req FR:req-traceability/scan.features
 * @req FR:req-traceability/scan.feature-filter
 * @req FR:req-traceability/priority.filtering
 * @req FR:req-traceability/analysis.coverage
 * @req FR:req-traceability/report.output
 */
async function runTraceabilityAnalysis(options = {}) {
    // Load project config and merge with defaults
    const projectConfig = await (0, traceability_config_js_1.loadConfig)(process.cwd());
    const { featureFilter, minPriority, xeRoot = '.xe', codePaths = projectConfig.scan.codePaths, excludePatterns = projectConfig.scan.exclude, testPaths = projectConfig.scan.testPaths, respectGitignore = projectConfig.scan.respectGitignore, } = options;
    // Determine feature directory
    const featuresDir = `${xeRoot}/features/`;
    const featureDir = featureFilter
        ? `${featuresDir}${featureFilter}/`
        : featuresDir;
    // When filtering to a specific feature, check if its directory exists.
    // If missing, proceed with an empty requirement set so that any @req annotations
    // referencing the feature surface as orphans rather than hiding behind a hard error.
    // @req FR:req-traceability/analysis.orphan
    // @req FR:req-traceability/analysis.orphan.missing-feature
    let featureMissingInfo;
    if (featureFilter && !fs.existsSync(featureDir)) {
        const availableFeatures = fs.existsSync(featuresDir)
            ? listFeatureIds(featuresDir).sort()
            : [];
        featureMissingInfo = { availableFeatures };
    }
    // Track scan timing
    const scanStart = Date.now();
    // Parse specs from features (and initiatives if not filtering)
    const specParser = new spec_parser_js_1.SpecParser();
    let requirements;
    if (featureFilter) {
        // For single feature, parse spec.md directly (if dir exists). Pass the
        // featureFilter as scope so nested IDs (e.g., `client/activity`) qualify
        // requirements correctly instead of falling back to the leaf dir name.
        // FR:feature-context/spec.@file.nesting
        requirements = featureMissingInfo
            ? []
            : await specParser.parseFile(`${featureDir}spec.md`, featureFilter);
    }
    else {
        // For all features, scan directories
        requirements = await specParser.parseDirectory(featuresDir);
        // Also check initiatives if they exist
        const initiativesDir = `${xeRoot}/initiatives/`;
        try {
            if (fs.existsSync(initiativesDir)) {
                const initiativeReqs = await specParser.parseDirectory(initiativesDir);
                requirements.push(...initiativeReqs);
            }
        }
        catch {
            // No initiatives directory or parse error, that's fine
        }
    }
    // Filter requirements by priority if specified
    // @req FR:req-traceability/priority.filtering
    if (minPriority) {
        requirements = requirements.filter((r) => meetsPriorityThreshold(r.priority, minPriority));
    }
    const scanOpts = { exclude: excludePatterns, codePaths, testPaths, respectGitignore };
    // Scan source code for @req annotations
    // @req FR:req-traceability/scan.code
    const scanner = new annotation_scanner_js_1.AnnotationScanner();
    let annotations = [];
    let totalFilesTraversed = 0;
    const resolvedCodePaths = await (0, path_expander_js_1.expandPathPatterns)(codePaths);
    for (const dir of resolvedCodePaths) {
        const result = await scanner.scanDirectory(dir, scanOpts);
        annotations.push(...result.annotations);
        totalFilesTraversed += result.filesTraversed;
    }
    // Scan test directories for @req annotations
    // @req FR:req-traceability/scan.tests
    const resolvedTestPaths = await (0, path_expander_js_1.expandPathPatterns)(testPaths);
    for (const dir of resolvedTestPaths) {
        const result = await scanner.scanDirectory(dir, scanOpts);
        annotations.push(...result.annotations);
        totalFilesTraversed += result.filesTraversed;
    }
    // Filter annotations to only those referencing the filtered feature
    if (featureFilter) {
        annotations = annotations.filter((a) => a.id.scope === featureFilter);
    }
    // Resolve per-feature traceability modes
    // @req FR:req-traceability/scan.traceability-mode.precedence
    const featureTraceabilityModes = await resolveFeatureTraceabilityModes(specParser, featuresDir, featureFilter, projectConfig.traceabilityModes);
    // Analyze coverage
    const analyzer = new coverage_analyzer_js_1.CoverageAnalyzer();
    const report = analyzer.analyze(requirements, annotations, featureTraceabilityModes);
    // Populate scan metadata (CoverageAnalyzer leaves these as 0)
    // @req FR:req-traceability/report.content.metrics.files-scanned
    report.metadata.filesScanned = totalFilesTraversed;
    report.metadata.scanDurationMs = Date.now() - scanStart;
    // Surface spec lines that looked like requirements but had a malformed ID,
    // so they don't silently vanish from coverage (@req FR:req-traceability/id.format)
    report.parseWarnings = specParser.warnings;
    // Check thresholds (only when not filtering to a single feature)
    const thresholdsMet = !!featureFilter ||
        requirements.length === 0 ||
        report.summary.implementationCoverage >= 50;
    // When the feature dir was missing, search existing features for FR path matches
    // to suggest a rename candidate.
    // @req FR:req-traceability/analysis.orphan
    let renameCandidates;
    if (featureMissingInfo && featureFilter) {
        renameCandidates = await findRenameCandidates(featureFilter, report.orphaned.map((o) => o.id), featuresDir, featureMissingInfo.availableFeatures);
    }
    // Build summary message
    const summaryMessage = buildSummaryMessage(report, featureFilter, featureMissingInfo, renameCandidates);
    return {
        report,
        thresholdsMet,
        summaryMessage,
        ...(featureMissingInfo && {
            missingFeature: {
                availableFeatures: featureMissingInfo.availableFeatures,
                renameCandidates: renameCandidates ?? [],
            },
        }),
    };
}
/**
 * Resolve traceability modes for all features in scope.
 * Combines frontmatter settings with config file settings using precedence chain.
 * @req FR:req-traceability/scan.traceability-mode.precedence
 */
async function resolveFeatureTraceabilityModes(specParser, featuresDir, featureFilter, configModes) {
    // Parse frontmatter from spec files
    let frontmatterMap;
    if (featureFilter) {
        const metadata = await specParser.parseFeatureMetadata(`${featuresDir}${featureFilter}/spec.md`);
        frontmatterMap = new Map([[featureFilter, metadata]]);
    }
    else {
        frontmatterMap = await specParser.parseDirectoryMetadata(featuresDir);
    }
    // If no frontmatter and no config modes, return undefined (default behavior)
    if (frontmatterMap.size === 0 && !configModes) {
        return undefined;
    }
    // Resolve modes per feature
    const resolvedModes = new Map();
    // Process features with frontmatter
    for (const [featureId, metadata] of frontmatterMap) {
        const mode = (0, traceability_config_js_1.resolveTraceabilityMode)(featureId, metadata, configModes);
        if (mode) {
            resolvedModes.set(featureId, mode);
        }
    }
    // Process features from config that don't have frontmatter
    if (configModes?.features) {
        for (const featureId of Object.keys(configModes.features)) {
            if (!resolvedModes.has(featureId)) {
                const mode = (0, traceability_config_js_1.resolveTraceabilityMode)(featureId, undefined, configModes);
                if (mode) {
                    resolvedModes.set(featureId, mode);
                }
            }
        }
    }
    return resolvedModes.size > 0 ? resolvedModes : undefined;
}
/**
 * Run cross-feature dependency analysis.
 *
 * Scans spec files for blockquote @req links, builds a dependency graph,
 * and validates consistency with frontmatter dependencies.
 *
 * Separate from runTraceabilityAnalysis to keep dependency tracking
 * decoupled from coverage analysis.
 *
 * @req FR:req-traceability/deps.scan
 * @req FR:req-traceability/deps.no-coverage
 */
async function runDependencyAnalysis(options = {}) {
    const { xeRoot = '.xe' } = options;
    const featuresDir = `${xeRoot}/features/`;
    const scanner = new dependency_scanner_js_1.DependencyScanner();
    const analyzer = new dependency_analyzer_js_1.DependencyAnalyzer();
    const features = await scanner.scanDirectory(featuresDir);
    // Always analyze all features so the reverse graph is complete.
    // Filtering is done at the report/CLI layer, not here.
    return analyzer.analyze(features);
}
/**
 * Search existing features for likely rename candidates given a missing feature ID.
 *
 * Two signals, ordered by confidence:
 * 1. FR-path match (ranked first): extract dot-path portions from orphaned annotation IDs
 *    (e.g. "init.pwsh") and grep each existing feature's spec.md for that substring.
 *    Catches renames where the feature name changed but the FR paths stayed the same.
 * 2. Token match (ranked second): split the queried feature ID by "-" and find existing
 *    features whose name contains any of those tokens (e.g. "deployment" → "devops-deployment").
 *
 * @req FR:req-traceability/analysis.orphan
 * @req FR:req-traceability/analysis.orphan.rename-hint
 */
async function findRenameCandidates(missingFeatureId, orphanedIds, featuresDir, availableFeatures) {
    if (availableFeatures.length === 0) {
        return [];
    }
    // Signal 1: FR-path fragment match in spec files — ranked first (strongest signal)
    const frPathMatches = new Set();
    if (orphanedIds.length > 0) {
        const pathFragments = orphanedIds
            .map((id) => {
            // Split scope from path at the LAST `/` so nested scopes (e.g.,
            // `client/activity/recent.track`) yield `recent.track`, not `activity/recent.track`.
            // FR:feature-context/spec.@file.nesting + FR:req-traceability/id.format scope rule.
            const slashIdx = id.lastIndexOf('/');
            return slashIdx !== -1 ? id.slice(slashIdx + 1) : null;
        })
            .filter((p) => p !== null && p.length > 0);
        if (pathFragments.length > 0) {
            const fsPromises = await Promise.resolve().then(() => __importStar(require('fs/promises')));
            for (const featureId of availableFeatures) {
                try {
                    const content = await fsPromises.readFile(`${featuresDir}${featureId}/spec.md`, 'utf-8');
                    if (pathFragments.some((fragment) => content.includes(fragment))) {
                        frPathMatches.add(featureId);
                    }
                }
                catch {
                    // Spec unreadable — skip
                }
            }
        }
    }
    // Signal 2: token-based name match — ranked after FR-path matches.
    // Match at token boundaries only (split by "-") to avoid substring false positives
    // like "ai" matching "traceability" inside "cli-engine".
    const tokenMatches = new Set();
    const tokens = missingFeatureId.split('-').filter((t) => t.length > 1);
    for (const featureId of availableFeatures) {
        const featureTokens = new Set(featureId.split('-'));
        if (!frPathMatches.has(featureId) && tokens.some((token) => featureTokens.has(token))) {
            tokenMatches.add(featureId);
        }
    }
    return [...Array.from(frPathMatches).sort(), ...Array.from(tokenMatches).sort()];
}
/**
 * Build a human-readable summary message.
 * When featureMissingInfo is provided, includes a note that the feature was not found
 * along with available features and any rename candidates found via path-fragment search.
 * @req FR:req-traceability/analysis.orphan
 */
function buildSummaryMessage(report, featureFilter, featureMissingInfo, renameCandidates) {
    const { summary } = report;
    const lines = [];
    if (featureFilter) {
        lines.push(`Traceability: ${featureFilter}`);
    }
    else {
        lines.push('Traceability Summary');
    }
    if (featureMissingInfo) {
        lines.push(`  Feature directory not found: "${featureFilter}"`);
        if (featureMissingInfo.availableFeatures.length > 0) {
            lines.push(`  Available features: ${featureMissingInfo.availableFeatures.join(', ')}`);
        }
        if (report.orphaned.length > 0) {
            lines.push(`  ${report.orphaned.length} stale annotation(s) found — feature may have been renamed`);
            if (renameCandidates && renameCandidates.length > 0) {
                lines.push(`  Possible rename target(s): ${renameCandidates.join(', ')}`);
            }
        }
        return lines.join('\n');
    }
    lines.push(`  Requirements: ${summary.total} total, ${summary.active} active`);
    lines.push(`  Implementation: ${summary.implementationCoverage}%`);
    lines.push(`  Test coverage: ${summary.testCoverage}%`);
    if (summary.uncovered > 0) {
        lines.push(`  Uncovered: ${summary.uncovered} requirements`);
    }
    if (report.orphaned.length > 0) {
        lines.push(`  Orphaned annotations: ${report.orphaned.length}`);
    }
    return lines.join('\n');
}
//# sourceMappingURL=runner.js.map
"use strict";
/**
 * Reporters for cross-feature dependency analysis.
 *
 * Supports three output formats:
 * - Text: Human-readable terminal output with color
 * - JSON: Machine-readable structured data
 * - Mermaid: Graph visualization definition
 *
 * @req FR:req-traceability/deps.output
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateDependencyTextReport = generateDependencyTextReport;
exports.generateDependencyJsonReport = generateDependencyJsonReport;
exports.generateDependencyMermaidReport = generateDependencyMermaidReport;
const picocolors_1 = __importDefault(require("picocolors"));
/**
 * Generate human-readable text report of dependency analysis.
 * @req FR:req-traceability/deps.output.text
 */
function generateDependencyTextReport(report, options) {
    if (options?.reverse) {
        return generateReverseTextReport(report, options);
    }
    const lines = [];
    // Filter features if requested (supports wildcards like *-context)
    const features = options?.feature
        ? filterByFeature(report.features, options.feature, (f) => f.featureId)
        : report.features;
    // Filter to features with dependencies
    const withDeps = features.filter((f) => f.dependencies.length > 0);
    // Validation warnings (checked before early return so they always appear)
    const featureValidations = options?.feature
        ? filterByFeature(report.validations, options.feature, (v) => v.featureId)
        : report.validations;
    if (withDeps.length === 0 && featureValidations.length === 0) {
        lines.push('No dependencies found.');
        return lines.join('\n');
    }
    let totalLinks = 0;
    let totalTargets = 0;
    for (const feature of withDeps) {
        // Count unique target features and unique requirement links
        const targetFeatures = new Set(feature.dependencies.map((d) => d.targetFeature));
        const uniqueLinks = deduplicateDeps(feature.dependencies);
        totalLinks += uniqueLinks.length;
        totalTargets += targetFeatures.size;
        // Header: feature name + summary stats
        const stats = picocolors_1.default.dim(`🔗 ${targetFeatures.size} feature${targetFeatures.size !== 1 ? 's' : ''} · ${uniqueLinks.length} req${uniqueLinks.length !== 1 ? 's' : ''}`);
        lines.push(`${picocolors_1.default.bold(feature.featureId)}  ${stats}`);
        lines.push(picocolors_1.default.dim('─'.repeat(50)));
        // Group deduplicated dependencies by target feature
        const byTarget = new Map();
        for (const dep of uniqueLinks) {
            const existing = byTarget.get(dep.targetFeature) ?? [];
            existing.push({ sourceFR: dep.sourceFR, targetType: dep.targetType, targetFR: dep.targetFR });
            byTarget.set(dep.targetFeature, existing);
        }
        // Parse all source FRs for alignment calculation
        const parsedSources = uniqueLinks.map((d) => parseSourceFR(d.sourceFR, feature.featureId));
        const maxVisibleLen = Math.max(...parsedSources.map((s) => s.prefix.length + s.path.length));
        for (const [targetFeature, deps] of byTarget) {
            lines.push('');
            lines.push(`${picocolors_1.default.cyan('→')} ${picocolors_1.default.cyan(targetFeature)}`);
            for (const dep of deps) {
                const { prefix, path } = parseSourceFR(dep.sourceFR, feature.featureId);
                const visibleLen = prefix.length + path.length;
                const padding = ' '.repeat(maxVisibleLen - visibleLen);
                const styledSource = prefix ? picocolors_1.default.dim(prefix) + path : path;
                lines.push(`  ${styledSource}${padding} ${picocolors_1.default.dim('→')} ${picocolors_1.default.dim(dep.targetType + ':' + targetFeature + '/')}${dep.targetFR}`);
            }
        }
        lines.push('');
    }
    if (featureValidations.length > 0) {
        lines.push(picocolors_1.default.red('Errors'));
        lines.push(picocolors_1.default.dim('─'.repeat(50)));
        for (const v of featureValidations) {
            lines.push(`  ${picocolors_1.default.red('✗')} ${v.featureId}: ${v.message}`);
        }
        lines.push('');
    }
    // Summary
    const errorCount = featureValidations.length;
    const healthSymbol = errorCount === 0 ? picocolors_1.default.green('✓') : picocolors_1.default.red('✗');
    const summaryParts = [
        `${withDeps.length} feature${withDeps.length !== 1 ? 's' : ''}`,
        `${totalLinks} link${totalLinks !== 1 ? 's' : ''}`,
    ];
    if (errorCount > 0) {
        summaryParts.push(picocolors_1.default.red(`${errorCount} error${errorCount !== 1 ? 's' : ''}`));
    }
    lines.push(`${healthSymbol} ${summaryParts.join(picocolors_1.default.dim('  ·  '))}`);
    lines.push('');
    return lines.join('\n').trimEnd();
}
/**
 * Generate reverse dependency text report.
 * @req FR:req-traceability/deps.reverse
 */
function generateReverseTextReport(report, options) {
    const lines = [];
    const reverseGraph = report.reverseGraph;
    // Filter reverse graph entries by feature pattern (supports wildcards)
    const entries = options?.feature
        ? [...reverseGraph.entries()].filter(([f]) => matchesFeatureFilter(f, options.feature))
        : [...reverseGraph.entries()];
    if (entries.length === 0) {
        const label = options?.feature ?? 'Any feature';
        lines.push(`${label} has no reverse dependencies.`);
        return lines.join('\n');
    }
    for (const [feature, dependents] of entries) {
        const stats = picocolors_1.default.dim(`🔗 ${dependents.length} dependent${dependents.length !== 1 ? 's' : ''}`);
        lines.push(`${picocolors_1.default.bold(feature)}  ${stats}`);
        lines.push(picocolors_1.default.dim('─'.repeat(50)));
        lines.push('');
        for (const dep of dependents) {
            lines.push(`${picocolors_1.default.cyan('←')} ${picocolors_1.default.cyan(dep)}`);
        }
        lines.push('');
    }
    return lines.join('\n').trimEnd();
}
// ── Helpers ──────────────────────────────────────────────────
/**
 * Parse a source FR ID into its display-ready parts.
 * Strips the feature scope but preserves the FR/NFR type prefix.
 * Returns { prefix, path } where prefix is "FR:" or "NFR:" or "",
 * and path is the requirement path without feature scope.
 */
function parseSourceFR(frId, featureId) {
    // Try scoped prefixes first: FR:{feature}/ or NFR:{feature}/
    for (const type of ['NFR', 'FR']) {
        const scoped = `${type}:${featureId}/`;
        if (frId.startsWith(scoped)) {
            return { prefix: `${type}:`, path: frId.slice(scoped.length) };
        }
    }
    // Bare prefix without feature scope
    if (frId.startsWith('NFR:'))
        return { prefix: 'NFR:', path: frId.slice(4) };
    if (frId.startsWith('FR:'))
        return { prefix: 'FR:', path: frId.slice(3) };
    return { prefix: '', path: frId };
}
/**
 * Test whether a feature ID matches a filter pattern.
 * Supports `*` wildcards (e.g., `*-context` matches `feature-context`).
 * A plain string without wildcards requires an exact match.
 * @req FR:req-traceability/deps.filter
 */
function matchesFeatureFilter(featureId, pattern) {
    if (!pattern.includes('*'))
        return featureId === pattern;
    const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp('^' + escaped.replace(/\*/g, '.*') + '$');
    return regex.test(featureId);
}
/**
 * Filter an array of items by feature ID using a pattern that may contain wildcards.
 * @req FR:req-traceability/deps.filter
 */
function filterByFeature(items, pattern, getId) {
    return items.filter((item) => matchesFeatureFilter(getId(item), pattern));
}
/**
 * Deduplicate dependency links by unique (sourceFR, targetFeature, targetType, targetFR) tuple.
 * @req FR:req-traceability/deps.scan.dedupe
 */
function deduplicateDeps(deps) {
    const seen = new Set();
    const result = [];
    for (const dep of deps) {
        const key = `${dep.sourceFR}|${dep.targetFeature}|${dep.targetType}:${dep.targetFR}`;
        if (!seen.has(key)) {
            seen.add(key);
            result.push(dep);
        }
    }
    return result;
}
/**
 * Generate JSON report of dependency analysis.
 * @req FR:req-traceability/deps.output.json
 */
function generateDependencyJsonReport(report) {
    const output = {
        features: report.features.map((f) => ({
            featureId: f.featureId,
            frontmatterDeps: f.frontmatterDeps,
            dependencies: f.dependencies.map((d) => ({
                sourceFR: d.sourceFR,
                targetFeature: d.targetFeature,
                targetType: d.targetType,
                targetFR: d.targetFR,
                specFile: d.specFile,
                specLine: d.specLine,
            })),
        })),
        validations: report.validations,
        graph: Object.fromEntries(report.graph),
        reverseGraph: Object.fromEntries(report.reverseGraph),
    };
    return JSON.stringify(output, null, 2);
}
/**
 * Generate Mermaid graph definition for dependency visualization.
 * @req FR:req-traceability/deps.output.mermaid
 */
function generateDependencyMermaidReport(report, options) {
    const lines = ['graph LR'];
    const graph = report.graph;
    for (const [source, targets] of graph) {
        if (options?.feature && !matchesFeatureFilter(source, options.feature)) {
            continue;
        }
        for (const target of targets) {
            lines.push(`  ${source} --> ${target}`);
        }
    }
    return lines.join('\n');
}
//# sourceMappingURL=dependency-reporter.js.map
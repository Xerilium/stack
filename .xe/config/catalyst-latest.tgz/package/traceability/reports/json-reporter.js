"use strict";
/**
 * JSON report generator.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateJsonReport = generateJsonReport;
/**
 * Generate a JSON report from traceability data.
 * @req FR:req-traceability/report.output.json
 * @req FR:req-traceability/report.content.spec-text
 * @req FR:req-traceability/report.content.metrics
 * @req FR:req-traceability/priority.reporting
 */
function generateJsonReport(report) {
    // Convert Maps to plain objects for JSON serialization
    const requirementsObj = {};
    for (const [key, value] of report.requirements.entries()) {
        requirementsObj[key] = value;
    }
    // Convert featureTraceabilityModes Map to object
    let featureTraceabilityModesObj;
    if (report.featureTraceabilityModes) {
        featureTraceabilityModesObj = {};
        for (const [key, value] of report.featureTraceabilityModes.entries()) {
            featureTraceabilityModesObj[key] = value;
        }
    }
    const jsonOutput = {
        metadata: report.metadata,
        requirements: requirementsObj,
        orphaned: report.orphaned,
        fileLevelAnnotations: report.fileLevelAnnotations,
        testCoverageGaps: report.testCoverageGaps,
        codeCoverageGaps: report.codeCoverageGaps,
        featureTraceabilityModes: featureTraceabilityModesObj,
        parseWarnings: report.parseWarnings,
        summary: report.summary,
    };
    return JSON.stringify(jsonOutput, null, 2);
}
//# sourceMappingURL=json-reporter.js.map
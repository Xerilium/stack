"use strict";
/**
 * Types for traceability reports and coverage analysis.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=report.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTraceabilityModeValue = parseTraceabilityModeValue;
const VALID_MODE_VALUES = new Set(['error', 'warning', 'inherit', 'disable']);
/**
 * Parse a raw traceability mode value.
 * Returns the value if valid, undefined otherwise.
 */
function parseTraceabilityModeValue(value) {
    return typeof value === 'string' && VALID_MODE_VALUES.has(value)
        ? value
        : undefined;
}
//# sourceMappingURL=traceability-mode.js.map
"use strict";
/**
 * Types for cross-feature dependency tracking.
 * @req FR:req-traceability/deps.scan
 * @req FR:req-traceability/deps.frontmatter-validation
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=dependency.js.map
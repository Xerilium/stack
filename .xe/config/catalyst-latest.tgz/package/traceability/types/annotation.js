"use strict";
/**
 * Types for code annotations and scanning options.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=annotation.js.map
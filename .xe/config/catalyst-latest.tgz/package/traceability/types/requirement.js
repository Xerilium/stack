"use strict";
/**
 * Types for requirement identifiers and definitions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=requirement.js.map
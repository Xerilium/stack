"use strict";
/**
 * Configuration loading for traceability scanner.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadConfig = loadConfig;
exports.getDefaultScanOptions = getDefaultScanOptions;
exports.resolveTraceabilityMode = resolveTraceabilityMode;
exports.checkThresholds = checkThresholds;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const index_js_1 = require("../types/index.js");
/**
 * Default configuration values.
 * @req FR:req-traceability/scan.code
 * @req FR:req-traceability/scan.tests
 * @req FR:req-traceability/scan.exclude
 * @req FR:req-traceability/scan.gitignore
 */
const DEFAULT_CONFIG = {
    scan: {
        exclude: [
            '**/node_modules/**',
            '**/dist/**',
            '**/build/**',
            '**/.git/**',
            '**/coverage/**',
        ],
        codePaths: ['src/'],
        testPaths: ['tests/', '__tests__/', 'test/', '**/*.test.*', '**/*.spec.*'],
        respectGitignore: true,
    },
    thresholds: {},
    featureDirs: ['.xe/features/', '.xe/initiatives/'],
};
/**
 * Load traceability configuration from project.
 * @req FR:req-traceability/scan.@config
 * @req FR:req-traceability/scan.input
 * @req FR:req-traceability/scan.code
 * @req FR:req-traceability/scan.tests
 * @req FR:req-traceability/scan.exclude
 * @req FR:req-traceability/scan.gitignore
 * @req FR:req-traceability/integration.thresholds
 */
async function loadConfig(projectRoot) {
    const configPath = path.join(projectRoot, '.xe', 'config', 'catalyst.json');
    try {
        const content = await fs.readFile(configPath, 'utf-8');
        const json = JSON.parse(content);
        // Merge with defaults
        const config = mergeConfig(DEFAULT_CONFIG, json.traceability || {});
        // Parse traceability mode settings
        // @req FR:req-traceability/scan.traceability-mode.config
        // @req FR:req-traceability/scan.traceability-mode.config.input
        const traceSection = json.traceability;
        if (traceSection) {
            const modes = parseTraceabilityModes(traceSection);
            if (modes) {
                config.traceabilityModes = modes;
            }
        }
        return config;
    }
    catch (error) {
        // Config doesn't exist or is invalid - use defaults
        return DEFAULT_CONFIG;
    }
}
/**
 * Merge user config with defaults.
 * Reads new JSON shape: paths.code, paths.test, paths.exclude, gitignore.
 */
function mergeConfig(defaults, userConfig) {
    const paths = userConfig.paths;
    return {
        scan: {
            exclude: paths?.exclude || defaults.scan.exclude,
            codePaths: paths?.code || defaults.scan.codePaths,
            testPaths: paths?.test || defaults.scan.testPaths,
            respectGitignore: typeof userConfig.gitignore === 'boolean'
                ? userConfig.gitignore
                : defaults.scan.respectGitignore,
        },
        thresholds: {
            ...defaults.thresholds,
            ...(userConfig.thresholds ?? {}),
        },
        featureDirs: userConfig.featureDirs || defaults.featureDirs,
    };
}
/**
 * Get default scan options.
 */
function getDefaultScanOptions() {
    return { ...DEFAULT_CONFIG.scan };
}
/**
 * Parse traceability mode settings from catalyst.json traceability section.
 * @req FR:req-traceability/scan.traceability-mode.config.input
 * @req FR:req-traceability/scan.traceability-mode.config.output
 */
function parseTraceabilityModes(traceSection) {
    const defaultMode = parseTraceabilityModeObj(traceSection.default);
    const featuresObj = traceSection.features;
    let features;
    if (featuresObj && typeof featuresObj === 'object') {
        features = {};
        for (const [key, val] of Object.entries(featuresObj)) {
            const mode = parseTraceabilityModeObj(val);
            if (mode) {
                features[key] = mode;
            }
        }
        if (Object.keys(features).length === 0) {
            features = undefined;
        }
    }
    if (!defaultMode && !features) {
        return undefined;
    }
    const config = {};
    if (defaultMode) {
        config.default = defaultMode;
    }
    if (features) {
        config.features = features;
    }
    return config;
}
/**
 * Parse a single traceability mode object.
 */
function parseTraceabilityModeObj(obj) {
    if (!obj || typeof obj !== 'object') {
        return undefined;
    }
    const record = obj;
    const mode = {};
    let hasField = false;
    const parsedCode = (0, index_js_1.parseTraceabilityModeValue)(record.code);
    if (parsedCode !== undefined) {
        mode.code = parsedCode;
        hasField = true;
    }
    const parsedTest = (0, index_js_1.parseTraceabilityModeValue)(record.test);
    if (parsedTest !== undefined) {
        mode.test = parsedTest;
        hasField = true;
    }
    return hasField ? mode : undefined;
}
/**
 * Apply a traceability mode layer value onto a current resolved value.
 *
 * - `'error'` or `'warning'`: explicit severity, overwrites parent
 * - `'inherit'`: enabled — inherit parent's severity if set, otherwise stay `'inherit'`
 * - `'disable'`: disabled, overwrites parent
 * - `undefined`: not set, keep parent value
 */
function applyTraceabilityLayer(current, layer) {
    if (layer === undefined) {
        return current;
    }
    if (layer === 'error' || layer === 'warning') {
        return layer;
    }
    if (layer === 'inherit') {
        return (current === 'error' || current === 'warning') ? current : 'inherit';
    }
    // layer === 'disable': disabled overrides everything
    return 'disable';
}
/**
 * Post-process: resolve bare `'inherit'` (no parent set a severity) to system default.
 */
function finalizeTraceabilityValue(value) {
    return value === 'inherit' ? 'warning' : value;
}
/**
 * Test whether a config feature key (which may contain `*` wildcards) matches a feature ID.
 * @req FR:req-traceability/scan.traceability-mode.config.wildcard
 */
function matchesWildcard(pattern, featureId) {
    const regexStr = '^' + pattern.split('*').map(s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$';
    return new RegExp(regexStr).test(featureId);
}
/**
 * Resolve traceability mode for a specific feature using precedence chain:
 * spec.md frontmatter > catalyst.json exact feature match > wildcard matches (last wins) > catalyst.json default > system default
 *
 * After resolution, `'inherit'` is replaced by the inherited severity or `'warning'` (system default).
 * Consumers see only `'error'`, `'warning'`, `'disable'`, or `undefined` — never raw `'inherit'`.
 *
 * @req FR:req-traceability/scan.traceability-mode.precedence
 * @req FR:req-traceability/scan.traceability-mode.config.wildcard
 */
function resolveTraceabilityMode(featureId, frontmatter, config) {
    const configDefault = config?.default;
    const configFeature = config?.features?.[featureId];
    const fmMode = frontmatter?.traceability;
    // Collect wildcard matches (last defined wins)
    const wildcardMatches = [];
    if (config?.features) {
        for (const [key, mode] of Object.entries(config.features)) {
            if (key !== featureId && key.includes('*') && matchesWildcard(key, featureId)) {
                wildcardMatches.push(mode);
            }
        }
    }
    // If nothing is set anywhere, return undefined
    if (!configDefault && !configFeature && wildcardMatches.length === 0 && !fmMode) {
        return undefined;
    }
    // Layer: config default → wildcard matches (in order) → exact feature → frontmatter
    let code = applyTraceabilityLayer(undefined, configDefault?.code);
    let test = applyTraceabilityLayer(undefined, configDefault?.test);
    for (const wm of wildcardMatches) {
        code = applyTraceabilityLayer(code, wm.code);
        test = applyTraceabilityLayer(test, wm.test);
    }
    code = applyTraceabilityLayer(code, configFeature?.code);
    test = applyTraceabilityLayer(test, configFeature?.test);
    code = applyTraceabilityLayer(code, fmMode?.code);
    test = applyTraceabilityLayer(test, fmMode?.test);
    // Post-process: resolve bare `'inherit'` to system default severity
    code = finalizeTraceabilityValue(code);
    test = finalizeTraceabilityValue(test);
    const resolved = {};
    if (code !== undefined) {
        resolved.code = code;
    }
    if (test !== undefined) {
        resolved.test = test;
    }
    return resolved;
}
/**
 * Check if coverage meets thresholds.
 * Returns array of threshold violations.
 * @req FR:req-traceability/integration.thresholds
 */
function checkThresholds(implementationCoverage, testCoverage, thresholds) {
    const violations = [];
    if (thresholds.implementation !== undefined &&
        implementationCoverage < thresholds.implementation) {
        violations.push(`Implementation coverage ${implementationCoverage}% is below threshold ${thresholds.implementation}%`);
    }
    if (thresholds.test !== undefined &&
        testCoverage < thresholds.test) {
        violations.push(`Test coverage ${testCoverage}% is below threshold ${thresholds.test}%`);
    }
    return violations;
}
//# sourceMappingURL=traceability-config.js.map
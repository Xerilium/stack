"use strict";
/**
 * Type definitions for AI provider interface
 *
 * Defines the contract for AI platform implementations and the data structures
 * used for request/response communication.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
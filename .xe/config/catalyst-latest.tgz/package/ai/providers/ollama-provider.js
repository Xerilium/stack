"use strict";
/**
 * Ollama AI provider implementation
 *
 * Integrates with local Ollama server for offline AI execution.
 * No authentication required (headless by nature).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OllamaProvider = void 0;
const ollama_1 = require("ollama");
const errors_1 = require("../../core/errors");
/**
 * Ollama AI provider
 *
 * @req FR:ai-provider-ollama/ollama.interface
 * @req FR:ai-provider-ollama/ollama.sdk
 */
class OllamaProvider {
    /**
     * @req FR:ai-provider-ollama/ollama.server.url
     * @req NFR:ai-provider-ollama/ollama.performance.instantiation
     */
    constructor() {
        /** @req FR:ai-provider-ollama/ollama.interface */
        this.name = 'ollama';
        /** @req FR:ai-provider/provider.interface */
        this.displayName = 'Ollama';
        /** @req FR:ai-provider-ollama/ollama.interface */
        this.capabilities = ['headless'];
        // Get server URL from environment or use default
        // @req FR:ai-provider-ollama/ollama.server.url
        const host = process.env.OLLAMA_HOST || 'http://localhost:11434';
        this.client = new ollama_1.Ollama({ host });
    }
    /**
     * Execute an AI prompt using Ollama
     *
     * @req FR:ai-provider-ollama/ollama.execute
     * @req FR:ai-provider-ollama/ollama.models
     */
    async execute(request) {
        // Resolve model: use requested model, or discover the first installed model
        // @req FR:ai-provider-ollama/ollama.models
        const model = request.model || await this.getDefaultModel();
        // Build messages array
        // @req FR:ai-provider-ollama/ollama.execute
        const messages = [
            { role: 'system', content: request.systemPrompt },
            { role: 'user', content: request.prompt }
        ];
        // Build chat options
        const chatParams = {
            messages,
            model
        };
        // Set maxTokens if provided
        // @req FR:ai-provider-ollama/ollama.execute
        if (request.maxTokens) {
            chatParams.options = { num_predict: request.maxTokens };
        }
        // Pass abort signal
        // @req FR:ai-provider-ollama/ollama.execute
        if (request.abortSignal) {
            chatParams.signal = request.abortSignal;
        }
        // Create timeout promise for inactivity timeout
        // @req FR:ai-provider-ollama/ollama.execute
        let timeoutId;
        const timeoutPromise = new Promise((_, reject) => {
            timeoutId = setTimeout(() => {
                reject(new errors_1.CatalystError('Ollama request timed out due to inactivity', 'AIProviderTimeout', 'The request took too long. Try again or increase the timeout.'));
            }, request.inactivityTimeout);
        });
        try {
            // Race the API call against the timeout
            // @req FR:ai-provider-ollama/ollama.execute
            const response = await Promise.race([
                this.client.chat(chatParams),
                timeoutPromise
            ]);
            if (timeoutId)
                clearTimeout(timeoutId);
            // Extract content from response
            const content = response.message?.content || '';
            // Extract usage stats
            // @req FR:ai-provider-ollama/ollama.usage.tokens
            const inputTokens = response.prompt_eval_count || 0;
            const outputTokens = response.eval_count || 0;
            const usage = {
                inputTokens,
                outputTokens,
                totalTokens: inputTokens + outputTokens
            };
            // @req FR:ai-provider-ollama/ollama.models
            return {
                content,
                model: response.model,
                usage
            };
        }
        catch (error) {
            if (timeoutId)
                clearTimeout(timeoutId);
            this.handleError(error, request);
        }
    }
    /**
     * Check if Ollama server is available
     *
     * @req FR:ai-provider-ollama/ollama.server.available
     * @req NFR:ai-provider-ollama/ollama.performance.server-check
     */
    async isAvailable() {
        try {
            // @req FR:ai-provider-ollama/ollama.server.available
            await this.client.list();
            return true;
        }
        catch {
            return false;
        }
    }
    /**
     * Verify Ollama server is running
     *
     * @req FR:ai-provider-ollama/ollama.server.signin
     */
    async signIn() {
        try {
            // @req FR:ai-provider-ollama/ollama.server.signin
            await this.client.list();
        }
        catch (error) {
            // @req FR:ai-provider-ollama/ollama.errors.server
            throw new errors_1.CatalystError('Ollama server is not reachable', 'AIProviderUnavailable', 'Start Ollama with `ollama serve` or check OLLAMA_HOST environment variable.');
        }
    }
    /**
     * Get the first available model from the Ollama server
     *
     * @req FR:ai-provider-ollama/ollama.models
     */
    async getDefaultModel() {
        try {
            const { models } = await this.client.list();
            if (models.length > 0) {
                return models[0].name;
            }
        }
        catch {
            // Fall through to error
        }
        throw new errors_1.CatalystError('No Ollama models installed', 'AIProviderInvalidModel', 'Run `ollama pull llama3.2` (or another model) to get started.');
    }
    /**
     * Handle and transform errors
     *
     * @req FR:ai-provider-ollama/ollama.errors
     * @req FR:ai-provider-ollama/ollama.errors.server
     * @req FR:ai-provider-ollama/ollama.errors.model
     */
    handleError(error, request) {
        // @req FR:ai-provider-ollama/ollama.errors
        if (error instanceof errors_1.CatalystError) {
            throw error;
        }
        const err = error;
        // Handle connection errors
        // @req FR:ai-provider-ollama/ollama.errors.server
        if (err.code === 'ECONNREFUSED' || err.message?.includes('ECONNREFUSED')) {
            throw new errors_1.CatalystError('Ollama server is not reachable', 'AIProviderUnavailable', 'Start Ollama with `ollama serve` or check OLLAMA_HOST environment variable.');
        }
        // Handle model not found errors
        // @req FR:ai-provider-ollama/ollama.errors.model
        if (err.message?.includes('not found')) {
            const modelName = request.model || 'unknown';
            throw new errors_1.CatalystError(`Ollama model "${modelName}" not found`, 'AIProviderInvalidModel', `Run \`ollama pull ${modelName}\` to download the model.`);
        }
        // Generic error
        // @req FR:ai-provider-ollama/ollama.errors
        const message = error instanceof Error ? error.message : 'Unknown error';
        throw new errors_1.CatalystError(`Ollama error: ${message}`, 'AIProviderError', 'Check that Ollama is running and try again.');
    }
}
exports.OllamaProvider = OllamaProvider;
//# sourceMappingURL=ollama-provider.js.map
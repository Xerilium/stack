"use strict";
/**
 * Claude AI provider implementation
 *
 * Integrates with Anthropic's Claude AI using the official SDK.
 * Supports API key authentication for headless execution.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClaudeProvider = void 0;
const sdk_1 = __importDefault(require("@anthropic-ai/sdk"));
const errors_1 = require("../../core/errors");
const errors_2 = require("../errors");
/**
 * Claude AI provider
 *
 * @req FR:ai-provider-claude/claude.interface
 * @req FR:ai-provider-claude/claude.sdk
 */
class ClaudeProvider {
    constructor() {
        /** @req FR:ai-provider-claude/claude.interface */
        this.name = 'claude';
        /** @req FR:ai-provider/provider.interface */
        this.displayName = 'Claude';
        /** @req FR:ai-provider-claude/claude.interface */
        this.capabilities = ['headless'];
        this.client = null;
    }
    /**
     * Get or create the Anthropic client
     * @req FR:ai-provider-claude/claude.sdk
     */
    getClient() {
        if (!this.client) {
            const apiKey = process.env.ANTHROPIC_API_KEY;
            if (!apiKey) {
                throw errors_2.AIProviderErrors.unavailable('claude', 'Claude provider is not available. Set ANTHROPIC_API_KEY environment variable.');
            }
            this.client = new sdk_1.default({ apiKey });
        }
        return this.client;
    }
    /**
     * Execute an AI prompt using Claude
     *
     * @req FR:ai-provider-claude/claude.execute
     * @req FR:ai-provider-claude/claude.models
     */
    async execute(request) {
        // Check availability first
        if (!(await this.isAvailable())) {
            throw errors_2.AIProviderErrors.unavailable('claude', 'Claude provider is not available. Set ANTHROPIC_API_KEY environment variable.');
        }
        const client = this.getClient();
        // Build request parameters
        /** @req FR:ai-provider-claude/claude.execute */
        /** @req FR:ai-provider-claude/claude.models */
        const params = {
            system: request.systemPrompt,
            messages: [{ role: 'user', content: request.prompt }],
            max_tokens: request.maxTokens || 4096,
            model: (request.model || 'claude-sonnet-4-20250514')
        };
        // Build request options
        /** @req FR:ai-provider-claude/claude.execute */
        const options = {
            timeout: request.inactivityTimeout
        };
        // Handle abort signal
        /** @req FR:ai-provider-claude/claude.execute */
        if (request.abortSignal) {
            options.signal = request.abortSignal;
        }
        try {
            /** @req FR:ai-provider-claude/claude.sdk */
            const response = await client.messages.create(params, options);
            // Extract content from text blocks
            /** @req FR:ai-provider-claude/claude.execute */
            const content = response.content
                .filter((block) => block.type === 'text')
                .map((block) => block.text)
                .join('');
            // Extract usage stats
            /** @req FR:ai-provider-claude/claude.usage.tokens */
            const usage = {
                inputTokens: response.usage.input_tokens,
                outputTokens: response.usage.output_tokens,
                totalTokens: response.usage.input_tokens + response.usage.output_tokens
            };
            /** @req FR:ai-provider-claude/claude.execute */
            return {
                content,
                model: response.model,
                usage,
                metadata: {
                    id: response.id,
                    stopReason: response.stop_reason
                }
            };
        }
        catch (error) {
            /** @req FR:ai-provider-claude/claude.errors */
            this.handleError(error, request);
        }
    }
    /**
     * Check if Claude provider is available
     *
     * @req FR:ai-provider-claude/claude.auth.available
     * @req FR:ai-provider-claude/claude.auth.api-key
     */
    async isAvailable() {
        // Check API key
        return !!process.env.ANTHROPIC_API_KEY;
    }
    /**
     * Interactive sign-in flow
     *
     * Claude provider uses API key authentication only and does not support
     * interactive sign-in for headless execution.
     *
     * @req FR:ai-provider-claude/claude.auth.signin
     */
    async signIn() {
        throw errors_2.AIProviderErrors.unavailable('claude', 'Claude provider does not support interactive sign-in. Set ANTHROPIC_API_KEY environment variable.');
    }
    /**
     * Handle and transform errors
     *
     * @req FR:ai-provider-claude/claude.errors
     * @req FR:ai-provider-claude/claude.errors.auth
     * @req FR:ai-provider-claude/claude.errors.rate-limit
     * @req FR:ai-provider-claude/claude.errors.model
     */
    handleError(error, request) {
        if (error instanceof errors_1.CatalystError) {
            throw error;
        }
        // Handle abort errors first (no status code)
        /** @req FR:ai-provider-claude/claude.execute */
        if (error instanceof Error && error.name === 'AbortError') {
            throw new errors_1.CatalystError('Claude request was cancelled', 'AIProviderCancelled', 'The request was aborted.');
        }
        // Handle connection/timeout errors by name (no HTTP status)
        /** @req FR:ai-provider-claude/claude.execute */
        if (error instanceof Error && error.name === 'APIConnectionTimeoutError') {
            throw new errors_1.CatalystError('Claude request timeout', 'AIProviderTimeout', 'The request took too long. Try again or increase the timeout.');
        }
        /** @req FR:ai-provider-claude/claude.errors */
        if (error instanceof Error && error.name === 'APIConnectionError') {
            throw new errors_1.CatalystError(`Claude API connection error: ${error.message}`, 'AIProviderConnectionError', 'Check your network connection and try again.');
        }
        // Handle HTTP status-based errors via duck typing for testability
        // (instanceof checks on Anthropic SDK classes can fail in Jest due to module isolation)
        const err = error;
        /** @req FR:ai-provider-claude/claude.errors.auth */
        if (err.status === 401) {
            throw new errors_1.CatalystError('Claude authentication failed: Invalid API key', 'AIProviderUnavailable', 'Check your ANTHROPIC_API_KEY environment variable is valid.');
        }
        /** @req FR:ai-provider-claude/claude.errors.rate-limit */
        if (err.status === 429) {
            throw new errors_1.CatalystError('Claude rate limit exceeded', 'AIProviderRateLimited', 'Please wait and retry your request.');
        }
        /** @req FR:ai-provider-claude/claude.errors.model */
        if (err.status === 404) {
            throw new errors_1.CatalystError(`Invalid Claude model: ${request.model || 'unknown'}`, 'AIProviderInvalidModel', 'Check that the model name is valid.');
        }
        // Generic error
        /** @req FR:ai-provider-claude/claude.errors */
        const message = error instanceof Error ? error.message : 'Unknown error';
        throw new errors_1.CatalystError(`Claude API error: ${message}`, 'AIProviderError', 'Check the API status and try again.');
    }
}
exports.ClaudeProvider = ClaudeProvider;
//# sourceMappingURL=claude-provider.js.map
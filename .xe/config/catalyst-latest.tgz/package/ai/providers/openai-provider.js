"use strict";
/**
 * OpenAI AI provider implementation
 *
 * Integrates with OpenAI's GPT models using the official SDK.
 * Supports API key authentication for headless execution.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAIProvider = void 0;
const openai_1 = __importDefault(require("openai"));
const errors_1 = require("../../core/errors");
const errors_2 = require("../errors");
/**
 * OpenAI AI provider
 *
 * @req FR:ai-provider-openai/openai.interface
 * @req FR:ai-provider-openai/openai.sdk
 */
class OpenAIProvider {
    constructor() {
        /** @req FR:ai-provider-openai/openai.interface */
        this.name = 'openai';
        /** @req FR:ai-provider/provider.interface */
        this.displayName = 'OpenAI';
        /** @req FR:ai-provider-openai/openai.interface */
        this.capabilities = ['headless'];
        this.client = null;
    }
    /**
     * Get or create the OpenAI client
     *
     * @req FR:ai-provider-openai/openai.sdk
     * @req FR:ai-provider-openai/openai.auth.api-key
     */
    getClient() {
        if (!this.client) {
            const apiKey = process.env.OPENAI_API_KEY;
            if (!apiKey) {
                throw errors_2.AIProviderErrors.unavailable('openai', 'OpenAI provider is not available. Set OPENAI_API_KEY environment variable.');
            }
            this.client = new openai_1.default({ apiKey });
        }
        return this.client;
    }
    /**
     * Execute an AI prompt using OpenAI
     *
     * @req FR:ai-provider-openai/openai.execute
     * @req FR:ai-provider-openai/openai.models
     */
    async execute(request) {
        // Check availability first
        if (!(await this.isAvailable())) {
            throw errors_2.AIProviderErrors.unavailable('openai', 'OpenAI provider is not available. Set OPENAI_API_KEY environment variable.');
        }
        const client = this.getClient();
        // Build messages array
        /** @req FR:ai-provider-openai/openai.execute */
        const messages = [
            { role: 'system', content: request.systemPrompt },
            { role: 'user', content: request.prompt }
        ];
        // Build request parameters
        /** @req FR:ai-provider-openai/openai.models */
        const params = {
            messages,
            model: request.model || 'gpt-4o'
        };
        // Add max_tokens if specified
        /** @req FR:ai-provider-openai/openai.execute */
        if (request.maxTokens) {
            params.max_tokens = request.maxTokens;
        }
        try {
            /** @req FR:ai-provider-openai/openai.sdk */
            /** @req FR:ai-provider-openai/openai.execute */
            const response = await client.chat.completions.create(params, {
                signal: request.abortSignal
            });
            // Extract content from response
            /** @req FR:ai-provider-openai/openai.execute */
            const content = response.choices[0]?.message?.content || '';
            // Extract usage stats
            /** @req FR:ai-provider-openai/openai.usage.tokens */
            let usage;
            if (response.usage) {
                usage = {
                    inputTokens: response.usage.prompt_tokens,
                    outputTokens: response.usage.completion_tokens,
                    totalTokens: response.usage.total_tokens
                };
            }
            /** @req FR:ai-provider-openai/openai.execute */
            return {
                content,
                model: response.model,
                usage
            };
        }
        catch (error) {
            this.handleError(error, request);
        }
    }
    /**
     * Check if OpenAI provider is available
     *
     * @req FR:ai-provider-openai/openai.auth.available
     */
    async isAvailable() {
        return !!process.env.OPENAI_API_KEY;
    }
    /**
     * Interactive sign-in flow
     *
     * OpenAI provider uses API key authentication only and does not support
     * interactive sign-in.
     *
     * @req FR:ai-provider-openai/openai.auth.signin
     */
    async signIn() {
        throw new errors_1.CatalystError('OpenAI provider requires an API key', 'AIProviderUnavailable', 'Set OPENAI_API_KEY environment variable. Get an API key at https://platform.openai.com/api-keys');
    }
    /**
     * Handle and transform errors
     *
     * @req FR:ai-provider-openai/openai.errors
     */
    handleError(error, request) {
        if (error instanceof errors_1.CatalystError) {
            throw error;
        }
        const err = error;
        // Handle abort errors
        /** @req FR:ai-provider-openai/openai.execute */
        if (err.name === 'AbortError') {
            throw new errors_1.CatalystError('OpenAI request was cancelled', 'AIProviderCancelled', 'The request was aborted.');
        }
        // Handle authentication errors
        /** @req FR:ai-provider-openai/openai.errors.auth */
        if (err.status === 401) {
            throw new errors_1.CatalystError('OpenAI authentication failed: Invalid API key', 'AIProviderUnavailable', 'Check your OPENAI_API_KEY environment variable is valid.');
        }
        // Handle rate limit errors
        /** @req FR:ai-provider-openai/openai.errors.rate-limit */
        if (err.status === 429) {
            const retryAfter = err.headers?.['retry-after'];
            const guidance = retryAfter
                ? `Rate limit exceeded. Retry after ${retryAfter} seconds.`
                : 'Rate limit exceeded. Please wait and retry your request.';
            throw new errors_1.CatalystError('OpenAI rate limit exceeded', 'AIProviderRateLimited', guidance);
        }
        // Handle model not found errors
        /** @req FR:ai-provider-openai/openai.errors.model */
        if (err.status === 404) {
            throw new errors_1.CatalystError(`Invalid OpenAI model: ${request.model || 'unknown'}`, 'AIProviderInvalidModel', 'Check that the model name is valid (e.g., gpt-4, gpt-4-turbo, gpt-3.5-turbo).');
        }
        // Generic error
        /** @req FR:ai-provider-openai/openai.errors */
        const message = error instanceof Error ? error.message : 'Unknown error';
        throw new errors_1.CatalystError(`OpenAI API error: ${message}`, 'AIProviderError', 'Check the API status and try again.');
    }
}
exports.OpenAIProvider = OpenAIProvider;
//# sourceMappingURL=openai-provider.js.map
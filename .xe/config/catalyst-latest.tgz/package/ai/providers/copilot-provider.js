"use strict";
/**
 * GitHub Copilot AI provider implementation
 *
 * Provides integration with GitHub Copilot via the GitHub CLI with Copilot extension.
 * This provider is interactive-only and requires GitHub authentication.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CopilotProvider = void 0;
const child_process_1 = require("child_process");
const errors_1 = require("../../core/errors");
/**
 * GitHub Copilot provider implementation
 *
 * Uses GitHub CLI with Copilot extension for AI interactions.
 * Requires GitHub authentication and active Copilot subscription.
 *
 * @example
 * ```typescript
 * const provider = new CopilotProvider();
 *
 * // Check availability
 * if (await provider.isAvailable()) {
 *   // Execute prompt
 *   const response = await provider.execute({
 *     systemPrompt: 'You are a code assistant',
 *     prompt: 'Write a hello world function',
 *     inactivityTimeout: 60000
 *   });
 *   console.log(response.content);
 * }
 * ```
 *
 * @req FR:ai-provider-copilot/copilot
 * @req FR:ai-provider-copilot/copilot.interface
 */
class CopilotProvider {
    constructor() {
        /**
         * @req FR:ai-provider-copilot/copilot.interface
         */
        this.name = 'copilot';
        /** @req FR:ai-provider/provider.interface */
        this.displayName = 'Copilot';
        /**
         * @req FR:ai-provider-copilot/copilot.interface
         */
        this.capabilities = [];
    }
    /**
     * Check if GitHub CLI is available
     *
     * @returns Promise resolving to true if gh command exists
     * @req FR:ai-provider-copilot/copilot.auth.available
     * @req FR:ai-provider-copilot/copilot.errors.cli-missing
     */
    async checkCliExists() {
        return new Promise((resolve) => {
            const proc = (0, child_process_1.spawn)('gh', ['--version']);
            proc.on('error', (err) => {
                if (err.code === 'ENOENT') {
                    resolve(false);
                }
                else {
                    resolve(false);
                }
            });
            proc.on('close', (code) => {
                resolve(code === 0);
            });
        });
    }
    /**
     * Check if user is authenticated with GitHub CLI
     *
     * @returns Promise resolving to true if authenticated
     * @req FR:ai-provider-copilot/copilot.auth.github
     * @req FR:ai-provider-copilot/copilot.auth.available
     * @req FR:ai-provider-copilot/copilot.errors.auth
     */
    async checkAuthenticated() {
        return new Promise((resolve) => {
            const proc = (0, child_process_1.spawn)('gh', ['auth', 'status']);
            proc.on('error', () => {
                resolve(false);
            });
            proc.on('close', (code) => {
                resolve(code === 0);
            });
        });
    }
    /**
     * Check if Copilot extension is installed
     *
     * @returns Promise resolving to true if extension is installed
     * @req FR:ai-provider-copilot/copilot.auth.github
     * @req FR:ai-provider-copilot/copilot.auth.available
     * @req FR:ai-provider-copilot/copilot.errors.extension-missing
     */
    async checkExtensionInstalled() {
        return new Promise((resolve) => {
            const proc = (0, child_process_1.spawn)('gh', ['extension', 'list']);
            let stdout = '';
            proc.stdout.on('data', (data) => {
                stdout += data.toString();
            });
            proc.on('error', () => {
                resolve(false);
            });
            proc.on('close', (code) => {
                if (code === 0) {
                    resolve(stdout.includes('gh-copilot') || stdout.includes('copilot'));
                }
                else {
                    resolve(false);
                }
            });
        });
    }
    /**
     * Check if user has Copilot access (subscription)
     *
     * @returns Promise resolving to true if user has Copilot access
     * @req FR:ai-provider-copilot/copilot.auth.github
     * @req FR:ai-provider-copilot/copilot.auth.available
     * @req FR:ai-provider-copilot/copilot.errors.no-access
     */
    async checkCopilotAccess() {
        return new Promise((resolve) => {
            // Try a minimal copilot command to verify access
            const proc = (0, child_process_1.spawn)('gh', ['copilot', '--version']);
            proc.on('error', () => {
                resolve(false);
            });
            proc.on('close', (code) => {
                resolve(code === 0);
            });
        });
    }
    /**
     * Check if provider is available
     *
     * Verifies that:
     * - GitHub CLI is installed
     * - User is authenticated
     * - Copilot extension is installed
     * - User has Copilot subscription access
     *
     * @returns Promise resolving to true if all checks pass
     * @req FR:ai-provider-copilot/copilot.auth.available
     */
    async isAvailable() {
        // Check CLI exists
        if (!(await this.checkCliExists())) {
            return false;
        }
        // Check authentication
        if (!(await this.checkAuthenticated())) {
            return false;
        }
        // Check extension
        if (!(await this.checkExtensionInstalled())) {
            return false;
        }
        // Check Copilot access
        if (!(await this.checkCopilotAccess())) {
            return false;
        }
        return true;
    }
    /**
     * Interactive sign-in flow
     *
     * Guides user through required setup:
     * - Installing GitHub CLI
     * - Authenticating with GitHub
     * - Installing Copilot extension
     * - Verifying Copilot subscription
     *
     * @throws CatalystError if any prerequisite is missing
     * @req FR:ai-provider-copilot/copilot.auth.signin
     * @req FR:ai-provider-copilot/copilot.errors.cli-missing
     * @req FR:ai-provider-copilot/copilot.errors.auth
     * @req FR:ai-provider-copilot/copilot.errors.extension-missing
     * @req FR:ai-provider-copilot/copilot.errors.no-access
     */
    async signIn() {
        // Check CLI exists
        if (!(await this.checkCliExists())) {
            throw new errors_1.CatalystError('GitHub CLI not found', 'AIProviderUnavailable', 'Install GitHub CLI from https://cli.github.com');
        }
        // Check authentication
        if (!(await this.checkAuthenticated())) {
            throw new errors_1.CatalystError('Not authenticated with GitHub', 'AIProviderUnavailable', 'Run: gh auth login');
        }
        // Check extension
        if (!(await this.checkExtensionInstalled())) {
            throw new errors_1.CatalystError('Copilot extension not installed', 'AIProviderUnavailable', 'Run: gh extension install github/gh-copilot');
        }
        // Check Copilot access
        if (!(await this.checkCopilotAccess())) {
            throw new errors_1.CatalystError('No Copilot subscription detected', 'AIProviderUnavailable', 'GitHub Copilot requires an active subscription');
        }
        // All checks passed
    }
    /**
     * Execute an AI prompt via GitHub Copilot CLI
     *
     * Spawns a `gh copilot` process and communicates via stdin/stdout.
     * Supports inactivity timeout and abort signal for cancellation.
     *
     * @param request - The AI request containing prompts and configuration
     * @returns Promise resolving to the AI response
     * @throws CatalystError on execution errors or timeout
     * @req FR:ai-provider-copilot/copilot.execute
     * @req FR:ai-provider-copilot/copilot.cli
     * @req FR:ai-provider-copilot/copilot.models
     * @req FR:ai-provider-copilot/copilot.usage.tokens
     * @req FR:ai-provider-copilot/copilot.errors.cli-missing
     */
    async execute(request) {
        return new Promise((resolve, reject) => {
            // Combine system prompt and user prompt
            const combinedPrompt = `${request.systemPrompt}\n\n${request.prompt}`;
            // Spawn gh copilot process
            const proc = (0, child_process_1.spawn)('gh', ['copilot', 'suggest'], {
                stdio: ['pipe', 'pipe', 'pipe']
            });
            let stdout = '';
            let stderr = '';
            let timeoutId = null;
            let inactivityTimeoutId = null;
            // Cleanup function
            const cleanup = () => {
                if (timeoutId)
                    clearTimeout(timeoutId);
                if (inactivityTimeoutId)
                    clearTimeout(inactivityTimeoutId);
                if (request.abortSignal) {
                    request.abortSignal.removeEventListener('abort', handleAbort);
                }
            };
            // Handle abort signal
            const handleAbort = () => {
                cleanup();
                proc.kill();
                reject(new errors_1.CatalystError('Copilot execution aborted', 'AIProviderAborted', 'Request was cancelled'));
            };
            // Setup abort signal listener
            if (request.abortSignal) {
                if (request.abortSignal.aborted) {
                    handleAbort();
                    return;
                }
                request.abortSignal.addEventListener('abort', handleAbort);
            }
            // Setup inactivity timeout
            const resetInactivityTimeout = () => {
                if (inactivityTimeoutId) {
                    clearTimeout(inactivityTimeoutId);
                }
                inactivityTimeoutId = setTimeout(() => {
                    cleanup();
                    proc.kill();
                    reject(new errors_1.CatalystError('Copilot execution timed out due to inactivity', 'AIProviderTimeout', 'No response received within timeout period'));
                }, request.inactivityTimeout);
            };
            resetInactivityTimeout();
            // Handle process errors
            proc.on('error', (err) => {
                cleanup();
                if (err.code === 'ENOENT') {
                    reject(new errors_1.CatalystError('GitHub CLI not found', 'AIProviderUnavailable', 'Install GitHub CLI from https://cli.github.com'));
                }
                else {
                    reject(new errors_1.CatalystError(`Failed to execute Copilot CLI: ${err.message}`, 'AIProviderError', 'Check GitHub CLI installation and permissions'));
                }
            });
            // Collect stdout
            proc.stdout.on('data', (data) => {
                resetInactivityTimeout();
                stdout += data.toString();
            });
            // Collect stderr
            proc.stderr.on('data', (data) => {
                resetInactivityTimeout();
                stderr += data.toString();
            });
            // Handle process completion
            proc.on('close', (code) => {
                cleanup();
                if (code !== 0) {
                    reject(new errors_1.CatalystError(`Copilot CLI exited with code ${code}`, 'AIProviderError', stderr || 'Unknown error occurred'));
                    return;
                }
                // Return response
                resolve({
                    content: stdout.trim(),
                    model: 'copilot',
                    usage: undefined // @req FR:ai-provider-copilot/copilot.usage.tokens - CLI doesn't expose token counts
                });
            });
            // Write prompt to stdin
            proc.stdin.write(combinedPrompt);
            proc.stdin.end();
        });
    }
}
exports.CopilotProvider = CopilotProvider;
//# sourceMappingURL=copilot-provider.js.map
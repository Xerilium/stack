"use strict";
/**
 * AI provider factory
 *
 * Creates AI provider instances by name from a build-time generated catalog.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMockProvider = getMockProvider;
exports.resetMockProvider = resetMockProvider;
exports.createAIProvider = createAIProvider;
exports.getAvailableAIProviders = getAvailableAIProviders;
exports.getHeadlessProviders = getHeadlessProviders;
const errors_1 = require("../errors");
const mock_provider_1 = require("./mock-provider");
const provider_catalog_1 = require("./provider-catalog");
/**
 * Singleton mock provider instance for testing
 *
 * Using a singleton allows tests to configure the mock before
 * the action creates the provider, and then verify calls afterward.
 *
 * @req FR:ai-provider/mock.testing
 */
let mockProviderInstance = null;
/**
 * Get or create the singleton mock provider instance
 *
 * @returns The shared MockAIProvider instance
 * @req FR:ai-provider/mock.testing
 */
function getMockProvider() {
    if (!mockProviderInstance) {
        mockProviderInstance = new mock_provider_1.MockAIProvider();
    }
    return mockProviderInstance;
}
/**
 * Reset the mock provider singleton
 *
 * Call this in test afterEach to ensure clean state between tests.
 *
 * @req FR:ai-provider/mock.testing
 */
function resetMockProvider() {
    if (mockProviderInstance) {
        mockProviderInstance.reset();
    }
}
/**
 * Create an AI provider instance by name
 *
 * @param name - Provider identifier (e.g., 'claude', 'mock')
 * @returns Instantiated AIProvider ready for use
 * @throws CatalystError with code 'AIProviderNotFound' if provider is not in catalog
 *
 * @example
 * ```typescript
 * // Get mock provider for testing
 * const provider = createAIProvider('mock');
 *
 * // Use provider
 * const response = await provider.execute(request);
 * ```
 *
 * @req FR:ai-provider/factory
 * @req FR:ai-provider/factory.create
 */
function createAIProvider(name) {
    // Return singleton for mock provider
    if (name === 'mock') {
        return getMockProvider();
    }
    const ProviderClass = provider_catalog_1.PROVIDER_CATALOG[name];
    if (!ProviderClass) {
        throw errors_1.AIProviderErrors.notFound(name, Object.keys(provider_catalog_1.PROVIDER_CATALOG));
    }
    return new ProviderClass();
}
/**
 * Get list of available provider names
 *
 * @returns Array of provider identifiers that can be passed to createAIProvider()
 *
 * @example
 * ```typescript
 * const available = getAvailableAIProviders();
 * // ['mock'] - additional providers added by their features
 * ```
 *
 * @req FR:ai-provider/factory.list
 */
function getAvailableAIProviders() {
    return Object.keys(provider_catalog_1.PROVIDER_CATALOG);
}
/**
 * Get list of providers that support headless execution
 *
 * @returns Array of provider names with 'headless' capability
 *
 * @example
 * ```typescript
 * const headless = getHeadlessProviders();
 * // ['mock', 'claude', 'gemini', 'openai', 'ollama']
 * ```
 *
 * @req FR:ai-provider/factory.headless
 */
function getHeadlessProviders() {
    return Object.entries(provider_catalog_1.PROVIDER_CATALOG)
        .filter(([, ProviderClass]) => {
        const instance = new ProviderClass();
        return instance.capabilities.includes('headless');
    })
        .map(([name]) => name);
}
//# sourceMappingURL=factory.js.map
"use strict";
/**
 * AI Provider exports
 *
 * Re-exports provider implementations and factory functions.
 * Types and errors are now at the src/ai/ level.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIProviderErrors = exports.resetMockProvider = exports.getMockProvider = exports.getHeadlessProviders = exports.getAvailableAIProviders = exports.createAIProvider = exports.MockAIProvider = void 0;
// Mock provider
// @req FR:ai-provider/mock.provider
// @req FR:ai-provider/mock.testing
var mock_provider_1 = require("./mock-provider");
Object.defineProperty(exports, "MockAIProvider", { enumerable: true, get: function () { return mock_provider_1.MockAIProvider; } });
// Factory functions
// @req FR:ai-provider/factory.create
// @req FR:ai-provider/factory.list
// @req FR:ai-provider/factory.headless
var factory_1 = require("./factory");
Object.defineProperty(exports, "createAIProvider", { enumerable: true, get: function () { return factory_1.createAIProvider; } });
Object.defineProperty(exports, "getAvailableAIProviders", { enumerable: true, get: function () { return factory_1.getAvailableAIProviders; } });
Object.defineProperty(exports, "getHeadlessProviders", { enumerable: true, get: function () { return factory_1.getHeadlessProviders; } });
Object.defineProperty(exports, "getMockProvider", { enumerable: true, get: function () { return factory_1.getMockProvider; } });
Object.defineProperty(exports, "resetMockProvider", { enumerable: true, get: function () { return factory_1.resetMockProvider; } });
// Errors (re-exported from parent)
// @req FR:ai-provider/errors.not-found
// @req FR:ai-provider/errors.unavailable
var errors_1 = require("../errors");
Object.defineProperty(exports, "AIProviderErrors", { enumerable: true, get: function () { return errors_1.AIProviderErrors; } });
//# sourceMappingURL=index.js.map
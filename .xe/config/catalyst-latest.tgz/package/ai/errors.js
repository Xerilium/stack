"use strict";
/**
 * Error factory functions for AI providers
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIProviderErrors = void 0;
const errors_1 = require("../core/errors");
/**
 * Error factories for AI providers
 *
 * @req FR:ai-provider/errors
 * @req FR:ai-provider/errors.not-found
 * @req FR:ai-provider/errors.unavailable
 */
exports.AIProviderErrors = {
    /**
     * Provider not found error
     */
    notFound: (name, available) => {
        return new errors_1.CatalystError(`AI provider "${name}" not found`, 'AIProviderNotFound', `Available providers: ${available.join(', ')}`);
    },
    /**
     * Provider not available (credentials, etc.)
     */
    unavailable: (name, reason) => {
        return new errors_1.CatalystError(`AI provider "${name}" is not available: ${reason}`, 'AIProviderUnavailable', 'Run provider sign-in or check credentials');
    }
};
//# sourceMappingURL=errors.js.map
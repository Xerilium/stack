"use strict";
/**
 * Catalyst CLI entry point
 * @req FR:cli.entry
 * @req FR:cli.help
 * @req FR:cli.version
 * @req FR:cli.verbosity
 * @req FR:cli.global
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const commander_1 = require("commander");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const run_1 = require("./commands/run");
const traceability_1 = require("./commands/traceability");
const deps_1 = require("./commands/deps");
const index_1 = require("./commands/index");
const dynamic_1 = require("./commands/dynamic");
const errors_1 = require("./utils/errors");
const output_1 = require("./utils/output");
const errors_2 = require("../core/errors");
const logging_1 = require("../core/logging");
/**
 * Get package version from package.json
 */
function getVersion() {
    try {
        // Candidate package.json locations:
        // - `../package.json` — installed tarball (cli/ lives at package root)
        // - `../../package.json` — dist/cli/ during local build
        // - `../../../package.json` — src/cli/ during dev (tsconfig outDir=./src)
        const locations = [
            path.join(__dirname, '..', 'package.json'),
            path.join(__dirname, '..', '..', 'package.json'),
            path.join(__dirname, '..', '..', '..', 'package.json'),
        ];
        for (const loc of locations) {
            if (fs.existsSync(loc)) {
                const pkg = JSON.parse(fs.readFileSync(loc, 'utf-8'));
                if (pkg.name === '@xerilium/catalyst' && pkg.version) {
                    return pkg.version;
                }
            }
        }
        return '0.0.0';
    }
    catch {
        return '0.0.0';
    }
}
/**
 * Create and configure the CLI program
 * @req FR:cli.entry
 * @req FR:cli.help
 * @req FR:cli.version
 */
function createProgram(logLevel, playbookLogger) {
    const program = new commander_1.Command();
    program
        .name('catalyst')
        .description('Catalyst AI execution framework')
        .version(getVersion(), '--version', 'Display version number')
        .option('-q, --quiet', 'Suppress all output except errors')
        .option('--json', 'Output in compact JSON format (for piping)')
        .option('-v, --verbose', 'Enable verbose output (-v info, -vv verbose, -vvv debug, -vvvv trace)')
        .option('--debug', 'Enable debug output (same as -vvv)')
        .option('--diagnostics', 'Include framework instrumentation logs (suppressed by default)')
        .addHelpText('beforeAll', (0, output_1.generateBanner)());
    // Run command
    // @req FR:run.execute
    program
        .command('run <playbook-id>')
        .description('Execute a playbook by ID')
        .option('-i, --input <key=value>', 'Playbook input (repeatable)', collect, [])
        .option('-q, --quiet', 'Suppress all output except errors')
        .option('--what-if', 'Preview playbook steps without executing')
        .action(async (playbookId, options) => {
        // Inherit global options from parent
        const parentOpts = program.opts();
        if (parentOpts.quiet) {
            options.quiet = true;
        }
        if (parentOpts.json) {
            options.json = true;
        }
        if (logLevel !== undefined && logLevel >= logging_1.LogLevel.debug) {
            options.debug = true;
        }
        await (0, run_1.runCommand)(playbookId, options, playbookLogger);
    });
    // Traceability command
    // @req FR:cli-engine/traceability.execute
    program
        .command('traceability [feature]')
        .description('Run requirement traceability analysis')
        .option('--min-priority <priority>', 'Minimum priority level (P1-P5)')
        .action(async (feature, options) => {
        // Inherit global options from parent
        // @req FR:cli-engine/traceability.output
        const parentOpts = program.opts();
        if (parentOpts.quiet) {
            options.quiet = true;
        }
        if (parentOpts.json) {
            options.json = true;
        }
        if (parentOpts.verbose) {
            options.verbose = true;
        }
        await (0, traceability_1.traceabilityCommand)(feature, options);
    });
    // Deps command
    // @req FR:cli-engine/deps.execute
    // @req FR:req-traceability/deps.output.command
    program
        .command('deps [feature]')
        .description('Show cross-feature dependency graph')
        .option('--format <format>', 'Output format: text, json, mermaid', 'text')
        .option('--reverse', 'Show reverse dependencies')
        .action(async (feature, options) => {
        const parentOpts = program.opts();
        if (parentOpts.json) {
            options.format = 'json';
        }
        await (0, deps_1.depsCommand)(feature, options);
    });
    // Index command
    // @req FR:cli-engine/index.execute
    program
        .command('index')
        .description('Generate .xe/features/README.md from spec frontmatter')
        .action(async (options) => {
        const parentOpts = program.opts();
        if (parentOpts.quiet)
            options.quiet = true;
        await (0, index_1.indexCommand)(options);
    });
    // Register dynamic commands from cli-commands directory
    // @req FR:cli.dynamic
    (0, dynamic_1.registerDynamicCommands)(program, logLevel, playbookLogger);
    // Show help if no command provided
    program.action(() => {
        program.help();
    });
    return program;
}
/**
 * Collect multiple values for repeatable options
 */
function collect(value, previous) {
    return previous.concat([value]);
}
/**
 * Determine log level from CLI arguments
 * @req FR:cli.verbosity
 *
 * -v    = info (level 1) - info, warnings, errors
 * -vv   = verbose (level 2) - step flow
 * -vvv  = debug (level 3) - interpolation details
 * -vvvv = trace (level 4) - everything
 */
function getLogLevelFromArgs(args) {
    // Check for --quiet first (takes precedence)
    if (args.includes('-q') || args.includes('--quiet')) {
        return logging_1.LogLevel.error;
    }
    // Check for --debug flag
    if (args.includes('--debug')) {
        return logging_1.LogLevel.debug;
    }
    // Count -v flags
    let verboseCount = 0;
    for (const arg of args) {
        if (arg === '-v' || arg === '--verbose') {
            verboseCount = 1;
        }
        else if (arg.startsWith('-v') && !arg.startsWith('--')) {
            // Handle -vv, -vvv, -vvvv
            const vCount = (arg.match(/v/g) || []).length;
            verboseCount = Math.max(verboseCount, vCount);
        }
    }
    // Map count to level
    switch (verboseCount) {
        case 0:
            return logging_1.LogLevel.error; // Default: errors only
        case 1:
            return logging_1.LogLevel.info;
        case 2:
            return logging_1.LogLevel.verbose;
        case 3:
            return logging_1.LogLevel.debug;
        default:
            return logging_1.LogLevel.trace; // 4+
    }
}
/**
 * Detect whether framework diagnostic logs should be surfaced.
 * @req FR:cli.global
 */
function getDiagnosticsFromArgs(args) {
    if (args.includes('--diagnostics'))
        return true;
    const env = process.env.CATALYST_DIAGNOSTICS;
    return env === '1' || env === 'true';
}
/**
 * Main CLI entry point
 * @req FR:cli.entry
 * @req FR:cli.global
 */
async function main(args) {
    // Resolve log level from CLI arguments
    const logLevel = getLogLevelFromArgs(args);
    const diagnostics = getDiagnosticsFromArgs(args);
    // Framework logger: surfaces only when --diagnostics (or CATALYST_DIAGNOSTICS) is set.
    // Otherwise silent so playbook log output isn't lost in framework noise.
    const frameworkLogger = new logging_1.ConsoleLogger(diagnostics ? logLevel : logging_1.LogLevel.silent);
    logging_1.LogManager.setFramework(frameworkLogger);
    // Playbook logger: user-facing output (log actions + CLI status messages) at -v level.
    const playbookLogger = new logging_1.ConsoleLogger(logLevel);
    const logger = playbookLogger;
    const program = createProgram(logLevel, playbookLogger);
    try {
        // Establish the playbook logger as the active scope for all CLI command
        // handlers so user-facing output (CLI status + playbook log actions)
        // resolves via LogManager.current(). Framework-internal code calls
        // LogManager.framework() to bypass this scope.
        await logging_1.LogManager.scope(playbookLogger, () => program.parseAsync(args, { from: 'user' }));
        // Explicit exit on success — without this, idle HTTP keep-alive sockets
        // and stdin handles can delay process exit by 5-15 seconds.
        // Flush stdout before exiting to avoid truncating output.
        if (process.stdout.writableEnded) {
            process.exit(0);
        }
        else {
            process.stdout.write('', () => process.exit(0));
        }
    }
    catch (error) {
        if (error instanceof errors_2.CatalystError) {
            logger.error('CLI', 'Main', (0, errors_1.formatError)(error));
            process.exit((0, errors_1.getExitCode)(error));
        }
        // Unknown error
        if (error instanceof Error) {
            logger.error('CLI', 'Main', `Unexpected error: ${error.message}`);
            logger.debug('CLI', 'Main', 'Stack trace', { stack: error.stack });
        }
        else {
            logger.error('CLI', 'Main', `Unexpected error: ${String(error)}`);
        }
        process.exit(1);
    }
}
// Default export for bin/catalyst.js
exports.default = main;
//# sourceMappingURL=index.js.map
"use strict";
/**
 * CLI type definitions
 * @req FR:cli.entry
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map
"use strict";
/**
 * CLI output formatting utilities
 * @req FR:cli.banner
 * @req NFR:ux.colors
 * @req NFR:ux.progress
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateBanner = generateBanner;
exports.shouldUseColors = shouldUseColors;
exports.formatSuccess = formatSuccess;
exports.formatInfo = formatInfo;
exports.formatWarning = formatWarning;
exports.formatErrorMessage = formatErrorMessage;
exports.formatDim = formatDim;
exports.formatBold = formatBold;
exports.isTTY = isTTY;
const picocolors_1 = __importDefault(require("picocolors"));
/**
 * Generate the ASCII art banner with Xerilium branding
 * Features periodic table element (Xe, atomic number 42) with optional blue/purple/pink gradient
 * @req FR:cli.banner
 */
function generateBanner() {
    // 256-color helpers - picocolors doesn't support 256-color, use raw ANSI with pc.isColorSupported
    const fg = (n) => picocolors_1.default.isColorSupported ? `\x1b[38;5;${n}m` : '';
    const reset = picocolors_1.default.isColorSupported ? '\x1b[0m' : '';
    // Gradient colors: dark blue (18, 19) → purple (54, 55, 56) → pink-purple (92)
    // Accent color (128) for "42" and "Xe", text gradient (213 → 33)
    const lines = [
        ``,
        `  ${fg(18)}╭──────────╮${reset}   ${fg(213)} ___       _        _           _${reset}`,
        `  ${fg(19)}│ ${fg(128)}42       ${fg(19)}│${reset}   ${fg(177)}/ __| __ _| |_ __ _| |_   _ ___| |_${reset}`,
        `  ${fg(54)}│          ${fg(54)}│${reset}  ${fg(141)}| |   / _\` | __/ _\` | | | | / __| __|${reset}`,
        `  ${fg(55)}│    ${fg(128)}Xe    ${fg(55)}│${reset}  ${fg(105)}| |__| (_| | || (_| | | |_| \\__ \\ |_${reset}`,
        `  ${fg(56)}│          ${fg(56)}│${reset}   ${fg(69)}\\____\\__,_|\\__\\__,_|_|\\__, |___/\\__|${reset}`,
        `  ${fg(92)}╰──────────╯${reset}                          ${fg(33)}|__/${reset}`,
        ``,
    ];
    return lines.join('\n') + '\n';
}
/**
 * Check if colors should be used in output.
 * @req NFR:ux.colors
 */
function shouldUseColors() {
    // NO_COLOR spec: any presence (including empty string) disables colors.
    // Checked at call time so runtime env changes are honored, regardless of
    // picocolors' load-time caching of isColorSupported.
    if ('NO_COLOR' in process.env)
        return false;
    return picocolors_1.default.isColorSupported;
}
/**
 * Format a success message
 */
function formatSuccess(message) {
    return picocolors_1.default.green(`✓ ${message}`);
}
/**
 * Format an info message
 */
function formatInfo(message) {
    return picocolors_1.default.cyan(`→ ${message}`);
}
/**
 * Format a warning message
 */
function formatWarning(message) {
    return picocolors_1.default.yellow(`⚠ ${message}`);
}
/**
 * Format an error message
 */
function formatErrorMessage(message) {
    return picocolors_1.default.red(`✗ ${message}`);
}
/**
 * Format dim/secondary text
 */
function formatDim(text) {
    return picocolors_1.default.dim(text);
}
/**
 * Format bold text
 */
function formatBold(text) {
    return picocolors_1.default.bold(text);
}
/**
 * Check if output is a TTY (for progress indicators)
 * @req NFR:ux.progress
 */
function isTTY() {
    return process.stdout.isTTY === true;
}
//# sourceMappingURL=output.js.map
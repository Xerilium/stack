"use strict";
/**
 * CLI error handling utilities
 * @req FR:errors.PlaybookNotFound
 * @req FR:errors.InvalidInput
 * @req FR:errors.MissingPlaybookId
 * @req FR:errors.PlaybookExecutionFailed
 * @req FR:exit.codes
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPlaybookNotFoundError = createPlaybookNotFoundError;
exports.createInvalidInputError = createInvalidInputError;
exports.createMissingPlaybookIdError = createMissingPlaybookIdError;
exports.createPlaybookExecutionFailedError = createPlaybookExecutionFailedError;
exports.createInvalidPriorityError = createInvalidPriorityError;
exports.createTraceabilityAnalysisFailedError = createTraceabilityAnalysisFailedError;
exports.formatError = formatError;
exports.getExitCode = getExitCode;
const errors_1 = require("../../core/errors");
/**
 * Exit codes mapping for CLI errors
 * @req FR:exit.codes
 */
const EXIT_CODES = {
    // General errors (exit code 1)
    PlaybookNotFound: 1,
    PlaybookExecutionFailed: 1,
    TraceabilityAnalysisFailed: 1,
    // Usage errors (exit code 2)
    InvalidInput: 2,
    MissingPlaybookId: 2,
    InvalidPriority: 2
};
/**
 * Create a PlaybookNotFound error
 * @req FR:errors.PlaybookNotFound
 */
function createPlaybookNotFoundError(playbookId) {
    return new errors_1.CatalystError(`Playbook "${playbookId}" not found`, 'PlaybookNotFound', `Check playbook ID or specify the full path. Run 'catalyst run --help' to see discovery paths.`);
}
/**
 * Create an InvalidInput error
 * @req FR:errors.InvalidInput
 */
function createInvalidInputError(value) {
    return new errors_1.CatalystError(`Invalid input format: "${value}"`, 'InvalidInput', `Playbook inputs must be in key=value format. Example: --input name=value`);
}
/**
 * Create a MissingPlaybookId error
 * @req FR:errors.MissingPlaybookId
 */
function createMissingPlaybookIdError() {
    return new errors_1.CatalystError('No playbook ID provided', 'MissingPlaybookId', `Usage: catalyst run <playbook-id> [--input key=value...]`);
}
/**
 * Create a PlaybookExecutionFailed error
 * @req FR:errors.PlaybookExecutionFailed
 */
function createPlaybookExecutionFailedError(playbookId, reason, cause) {
    return new errors_1.CatalystError(`Playbook "${playbookId}" failed: ${reason}`, 'PlaybookExecutionFailed', 'Check playbook output above for details.', cause);
}
/**
 * Create an InvalidPriority error
 * @req FR:cli-engine/traceability.priority
 */
function createInvalidPriorityError(priority) {
    return new errors_1.CatalystError(`Invalid priority: "${priority}"`, 'InvalidPriority', 'Priority must be one of: P1, P2, P3, P4, P5');
}
/**
 * Create a TraceabilityAnalysisFailed error
 * @req FR:cli-engine/traceability.execute
 */
function createTraceabilityAnalysisFailedError(reason, cause) {
    return new errors_1.CatalystError(`Traceability analysis failed: ${reason}`, 'TraceabilityAnalysisFailed', 'Check output above for details.', cause);
}
/**
 * Build error chain entries from outer to inner
 * Returns array of { message, code, guidance } for each error in chain
 */
function collectErrorChain(error) {
    const chain = [];
    let current = error;
    while (current) {
        if (current instanceof errors_1.CatalystError) {
            chain.push({ message: current.message, code: current.code, guidance: current.guidance });
        }
        current = current.cause;
    }
    return chain;
}
/**
 * Format a CatalystError for terminal output
 * Shows stack-trace style error chain with each error on its own line
 * @req FR:errors.format
 */
function formatError(error) {
    const chain = collectErrorChain(error);
    const lines = [];
    // First error (outermost) - full message with code
    lines.push(`${chain[0].message} (${chain[0].code})`);
    // Nested errors - indented with "Caused by:" prefix
    for (let i = 1; i < chain.length; i++) {
        const indent = '  '.repeat(i);
        lines.push(`${indent}↳ ${chain[i].message} (${chain[i].code})`);
    }
    // Add guidance from innermost error (most specific details like stdout/stderr)
    // Fall back to outermost if there's only one error
    const innermostGuidance = chain[chain.length - 1].guidance;
    lines.push('');
    lines.push(innermostGuidance);
    return lines.join('\n');
}
/**
 * Get the exit code for a CatalystError
 * @req FR:exit.codes
 */
function getExitCode(error) {
    return EXIT_CODES[error.code] ?? 1;
}
//# sourceMappingURL=errors.js.map
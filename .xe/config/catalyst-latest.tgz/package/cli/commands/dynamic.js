"use strict";
/**
 * Dynamic command discovery and registration
 * @req FR:cli.dynamic
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveCommandsDir = resolveCommandsDir;
exports.discoverCommands = discoverCommands;
exports.registerDynamicCommands = registerDynamicCommands;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const run_1 = require("./run");
const logging_1 = require("../../core/logging");
/**
 * Resolve the cli-commands directory path
 * Tries multiple locations to support both development and installed scenarios
 * @req FR:cli.dynamic
 */
function resolveCommandsDir() {
    // Try multiple locations
    const locations = [
        path.join(__dirname, '..', '..', 'resources', 'cli-commands'), // From dist/cli/commands/
        path.join(__dirname, '..', '..', '..', 'src', 'resources', 'cli-commands') // From src/cli/commands/
    ];
    for (const loc of locations) {
        if (fs.existsSync(loc)) {
            return loc;
        }
    }
    // Return first location as default (even if it doesn't exist)
    return locations[0];
}
/**
 * Discover command playbooks in the given directory
 * @req FR:cli.dynamic
 */
function discoverCommands(dir) {
    if (!fs.existsSync(dir)) {
        return [];
    }
    const files = fs.readdirSync(dir);
    const commands = [];
    for (const file of files) {
        const ext = path.extname(file);
        if (ext === '.yaml' || ext === '.yml') {
            const name = path.basename(file, ext);
            commands.push({
                name,
                path: path.join(dir, file)
            });
        }
    }
    return commands;
}
/**
 * Collect multiple values for repeatable options
 */
function collect(value, previous) {
    return previous.concat([value]);
}
/**
 * Register dynamic commands with the CLI program
 * @req FR:cli.dynamic
 */
function registerDynamicCommands(program, logLevel, playbookLogger) {
    const commandsDir = resolveCommandsDir();
    const commands = discoverCommands(commandsDir);
    for (const cmd of commands) {
        program
            .command(cmd.name)
            .description(`Execute ${cmd.name} playbook`)
            .option('-i, --input <key=value>', 'Playbook input (repeatable)', collect, [])
            .option('-q, --quiet', 'Suppress all output except errors')
            .option('--what-if', 'Preview playbook steps without executing')
            .action(async (options) => {
            // Inherit global options from parent
            const parentOpts = program.opts();
            if (parentOpts.quiet) {
                options.quiet = true;
            }
            if (parentOpts.json) {
                options.json = true;
            }
            if (logLevel !== undefined && logLevel >= logging_1.LogLevel.debug) {
                options.debug = true;
            }
            // Run command with full path to playbook file
            await (0, run_1.runCommand)(cmd.path, options, playbookLogger);
        });
    }
}
//# sourceMappingURL=dynamic.js.map
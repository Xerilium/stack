"use strict";
/**
 * Traceability command implementation
 * @req FR:cli-engine/traceability.execute
 * @req FR:cli-engine/traceability.output
 * @req FR:cli-engine/traceability.priority
 * @req FR:cli-engine/traceability.thresholds
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseFeatureArgument = parseFeatureArgument;
exports.validatePriority = validatePriority;
exports.resolveFeatureFilters = resolveFeatureFilters;
exports.traceabilityCommand = traceabilityCommand;
const fs = __importStar(require("fs"));
const picocolors_1 = __importDefault(require("picocolors"));
const errors_1 = require("../utils/errors");
const logging_1 = require("../../core/logging");
const index_js_1 = require("../../traceability/index.js");
const VALID_PRIORITIES = ["P1", "P2", "P3", "P4", "P5"];
/**
 * Parse a feature argument, extracting the feature ID from a path if needed.
 *
 * Accepts plain IDs ("ai-provider") or paths (".xe/features/ai-provider/spec.md")
 * and extracts the feature ID portion.
 *
 * @req FR:cli-engine/traceability.execute
 */
function parseFeatureArgument(arg) {
    if (!arg) {
        return undefined;
    }
    // If it looks like a spec.md path, strip the `.xe/features/` prefix, drop a
    // trailing `/spec.md` and any trailing slash, leaving the (possibly nested)
    // feature ID. Honors FR:feature-context/spec.@file.nesting.
    if (arg.includes("/")) {
        const featuresPrefix = arg.match(/^(?:.*\/)?\.xe\/features\/(.+)$/);
        if (featuresPrefix) {
            return featuresPrefix[1].replace(/\/spec\.md$/, "").replace(/\/$/, "");
        }
    }
    return arg;
}
/**
 * Validate and normalize a priority string to a RequirementPriority.
 *
 * @req FR:cli-engine/traceability.priority
 */
function validatePriority(priority) {
    const normalized = priority.toUpperCase();
    if (!VALID_PRIORITIES.includes(normalized)) {
        throw (0, errors_1.createInvalidPriorityError)(priority);
    }
    return normalized;
}
/**
 * Resolve a feature filter pattern to matching feature IDs.
 *
 * Supports wildcard patterns (e.g., "ai-provider*") by matching against
 * feature directories in .xe/features/. Returns undefined for no filter
 * (all features), or an array of matching feature IDs.
 *
 * @req FR:cli-engine/traceability.execute
 */
function resolveFeatureFilters(pattern, featuresDir = ".xe/features") {
    if (!pattern) {
        return undefined;
    }
    // No wildcard — return as single-element array
    if (!pattern.includes("*") && !pattern.includes("?")) {
        return [pattern];
    }
    // Convert glob pattern to regex
    const regexStr = "^" + pattern.replace(/\*/g, ".*").replace(/\?/g, ".") + "$";
    const regex = new RegExp(regexStr);
    // Scan features directory for matches (recursive — feature dirs are any dir
    // containing a spec.md, at any depth; FR:feature-context/spec.@file.nesting).
    if (!fs.existsSync(featuresDir)) {
        return [pattern]; // Let the runner handle the error
    }
    const allFeatures = listFeatures(featuresDir);
    const entries = allFeatures.filter((id) => regex.test(id));
    if (entries.length === 0) {
        throw (0, errors_1.createTraceabilityAnalysisFailedError)(`No features matching pattern "${pattern}"\nAvailable features: ${allFeatures.sort().join(", ")}`);
    }
    return entries.sort();
}
/**
 * Walk `featuresDir` recursively and return every feature ID — a feature dir
 * is any directory containing `spec.md`; the ID is its path relative to
 * `featuresDir` joined with `/`. Honors FR:feature-context/spec.@file.nesting.
 */
function listFeatures(featuresDir) {
    const found = [];
    const walk = (currentDir) => {
        for (const dirent of fs.readdirSync(currentDir, { withFileTypes: true })) {
            if (!dirent.isDirectory()) {
                continue;
            }
            const childDir = `${currentDir}/${dirent.name}`;
            if (fs.existsSync(`${childDir}/spec.md`)) {
                found.push(childDir.slice(featuresDir.length + 1).replace(/\\/g, "/"));
            }
            else {
                walk(childDir);
            }
        }
    };
    walk(featuresDir);
    return found;
}
/**
 * Execute the traceability command.
 *
 * Runs traceability analysis and outputs a report in the requested format.
 * Exits with code 1 if coverage thresholds are not met.
 *
 * @req FR:cli-engine/traceability.execute
 * @req FR:cli-engine/traceability.output
 * @req FR:cli-engine/traceability.thresholds
 */
async function traceabilityCommand(featureArg, options) {
    const logger = logging_1.LogManager.current();
    // Parse feature argument and resolve wildcards
    const parsedFeature = parseFeatureArgument(featureArg);
    const featureFilters = resolveFeatureFilters(parsedFeature);
    // Validate priority if provided
    let minPriority;
    if (options.minPriority) {
        minPriority = validatePriority(options.minPriority);
    }
    // No filter or single feature — run once
    if (!featureFilters || featureFilters.length <= 1) {
        const featureFilter = featureFilters?.[0];
        logger.info("CLI", "Traceability", `Running traceability analysis${featureFilter ? ` for ${featureFilter}` : ""}...`);
        await runSingleFeature(featureFilter, minPriority, options);
        return;
    }
    // Multiple features from wildcard — collect-then-compose
    // @req FR:cli-engine/traceability.output
    logger.info("CLI", "Traceability", `Running traceability analysis for ${featureFilters.length} features matching "${parsedFeature}"...`);
    await runMultipleFeatures(featureFilters, minPriority, options, parsedFeature);
}
/**
 * Run traceability analysis for a single feature and output the report.
 * @req FR:cli-engine/traceability.output
 */
async function runSingleFeature(featureFilter, minPriority, options) {
    const result = await runAnalysis(featureFilter, minPriority);
    if (!options.quiet) {
        if (options.json) {
            console.log((0, index_js_1.generateJsonReport)(result.report));
        }
        else {
            // When the feature directory doesn't exist, show a self-contained error block
            // and skip the normal coverage report (0-req metrics are misleading).
            // @req FR:req-traceability/analysis.orphan
            if (result.missingFeature) {
                const { availableFeatures, renameCandidates } = result.missingFeature;
                const sep = picocolors_1.default.dim("─".repeat(60));
                console.log(`  ${sep}`);
                console.log(picocolors_1.default.red(`  ✗ Feature not found: "${featureFilter}"`));
                if (renameCandidates.length > 0) {
                    console.log(picocolors_1.default.dim(`  Did you mean: ${renameCandidates.join(", ")}`));
                }
                else if (availableFeatures.length > 0) {
                    console.log(picocolors_1.default.dim(`  Available features: ${availableFeatures.join(", ")}`));
                }
                if (result.report.orphaned.length > 0) {
                    console.log("");
                    console.log(picocolors_1.default.red(`  ${result.report.orphaned.length} stale annotation(s) referencing "${featureFilter}"`));
                    for (const o of result.report.orphaned) {
                        for (const loc of o.locations) {
                            console.log(picocolors_1.default.dim(`    ${loc} — ${o.id}`));
                        }
                    }
                }
                console.log(`  ${sep}`);
                return;
            }
            const termOptions = {
                verbose: options.verbose,
                featureName: featureFilter,
            };
            console.log((0, index_js_1.generateTerminalReport)(result.report, termOptions));
        }
    }
    // @req FR:cli-engine/traceability.thresholds
    if (!result.thresholdsMet) {
        process.exit(1);
    }
}
/**
 * Run traceability analysis for multiple features and output aggregate report.
 * @req FR:cli-engine/traceability.output
 */
async function runMultipleFeatures(featureFilters, minPriority, options, filterPattern) {
    const logger = logging_1.LogManager.current();
    const results = [];
    let anyThresholdFailed = false;
    // Collect all results
    for (const featureName of featureFilters) {
        try {
            const result = await runAnalysis(featureName, minPriority);
            results.push({
                featureName,
                report: result.report,
                thresholdsMet: result.thresholdsMet,
            });
            if (!result.thresholdsMet) {
                anyThresholdFailed = true;
            }
        }
        catch (error) {
            const reason = error instanceof Error ? error.message : String(error);
            logger.error("CLI", "Traceability", `Failed for ${featureName}: ${reason}`);
            anyThresholdFailed = true;
        }
    }
    // Output composed report
    if (!options.quiet && results.length > 0) {
        if (options.json) {
            // JSON mode: output all reports as a single valid JSON array
            // @req FR:req-traceability/report.output.json
            const jsonReports = results.map((result) => JSON.parse((0, index_js_1.generateJsonReport)(result.report)));
            console.log(JSON.stringify(jsonReports, null, 2));
        }
        else {
            outputMultiFeatureReport(results, options, filterPattern);
        }
    }
    if (anyThresholdFailed) {
        process.exit(1);
    }
}
/**
 * Compose and output the multi-feature terminal report.
 *
 * Layout:
 * 1. Per-feature detail sections (only for features with issues)
 * 2. Double separator
 * 3. Feature summary table (one line per feature)
 * 4. Single separator
 * 5. Aggregate metrics line
 * 6. Combined scan metadata
 *
 * @req FR:cli-engine/traceability.output
 */
function outputMultiFeatureReport(results, options, filterPattern) {
    const termOptions = { verbose: options.verbose };
    const maxNameWidth = Math.max(24, ...results.map((r) => r.featureName.length)) + 2;
    const lines = [];
    // Layer 2: Feature detail for each feature with issues
    for (const result of results) {
        const detail = (0, index_js_1.formatFeatureDetail)(result.report, result.featureName, {
            ...termOptions,
            featureName: result.featureName,
        });
        if (detail) {
            lines.push(detail);
        }
    }
    // Layer 3: Aggregate summary
    const doubleSep = picocolors_1.default.dim("═".repeat(60));
    lines.push(`  ${doubleSep}`);
    // Separate healthy and unhealthy features
    const unhealthy = results.filter((r) => {
        const s = r.report.summary;
        return (s.uncovered > 0 ||
            r.report.codeCoverageGaps.length > 0 ||
            r.report.testCoverageGaps.length > 0);
    });
    const healthy = results.filter((r) => {
        const s = r.report.summary;
        return (s.uncovered === 0 &&
            r.report.codeCoverageGaps.length === 0 &&
            r.report.testCoverageGaps.length === 0);
    });
    // Feature summary table: unhealthy features listed individually
    for (const result of unhealthy) {
        lines.push((0, index_js_1.formatFeatureSummaryLine)(result.report, result.featureName, maxNameWidth, termOptions));
    }
    // Healthy features collapsed into a single line
    if (healthy.length > 0) {
        const healthyReqs = healthy.reduce((sum, r) => sum + r.report.summary.active, 0);
        lines.push(`  ${picocolors_1.default.green("✓")} ${picocolors_1.default.dim(`${healthy.length} features   ${healthyReqs} reqs   all at 100% coverage`)}`);
    }
    // Single separator
    const singleSep = picocolors_1.default.dim("─".repeat(60));
    lines.push(`  ${singleSep}`);
    // Aggregate metrics
    const totalFeatures = results.length;
    const totalReqs = results.reduce((sum, r) => sum + r.report.summary.active, 0);
    const totalImpl = results.reduce((sum, r) => sum + r.report.summary.implemented, 0);
    const totalTested = results.reduce((sum, r) => sum + r.report.summary.tested, 0);
    const totalCovered = results.reduce((sum, r) => sum + r.report.summary.covered, 0);
    const totalUncovered = results.reduce((sum, r) => sum + r.report.summary.uncovered, 0);
    const totalCodeGaps = results.reduce((sum, r) => sum + r.report.codeCoverageGaps.length, 0);
    const totalTestGaps = results.reduce((sum, r) => sum + r.report.testCoverageGaps.length, 0);
    const totalOrphaned = results.reduce((sum, r) => sum + r.report.orphaned.length, 0);
    const totalDeferred = results.reduce((sum, r) => sum + r.report.summary.deferred, 0);
    const totalDeprecated = results.reduce((sum, r) => sum + r.report.summary.deprecated, 0);
    const totalCoveredWeight = results.reduce((sum, r) => sum + r.report.summary.coverageScore * r.report.summary.active, 0);
    const totalCompWeight = results.reduce((sum, r) => sum + r.report.summary.completenessScore * r.report.summary.active, 0);
    const weightedCoverage = totalReqs > 0 ? Math.round(totalCoveredWeight / totalReqs) : 100;
    const weightedCompleteness = totalReqs > 0 ? Math.round(totalCompWeight / totalReqs) : 100;
    const implPct = totalReqs > 0 ? Math.round((totalImpl / totalReqs) * 100) : 0;
    const testPct = totalReqs > 0 ? Math.round((totalTested / totalReqs) * 100) : 0;
    // Bar segments: green = both code+test, yellow = one only, red = uncovered
    const both = totalImpl + totalTested - totalCovered;
    const partial = totalCovered - both;
    const greenPct = totalReqs > 0 ? (both / totalReqs) * 100 : 0;
    const yellowPct = totalReqs > 0 ? (partial / totalReqs) * 100 : 0;
    const redPct = totalReqs > 0 ? (totalUncovered / totalReqs) * 100 : 0;
    const barWidth = 38;
    const pctColWidth = 4;
    const lineWidth = 60;
    // Row 1: Header (left) + completeness (right, dim)
    const isGlobAll = !filterPattern || filterPattern === "*";
    const headerName = isGlobAll ? "All features" : filterPattern;
    const headerVisible = `${headerName} (${totalFeatures})`;
    const compText = `${weightedCompleteness}% completeness`;
    const headerPad = Math.max(0, lineWidth - headerVisible.length - compText.length);
    lines.push(`  ${picocolors_1.default.bold(headerName)} ${picocolors_1.default.dim(`(${totalFeatures})`)}${" ".repeat(headerPad)}${picocolors_1.default.dim(compText)}`);
    lines.push("");
    // Row 2: "NN% coverage" + padding + "XXX requirements" (total width = barWidth) + deferred
    const covPct = `${weightedCoverage}%`.padStart(pctColWidth);
    const covLabel = `${covPct} coverage`;
    const reqText = `${totalReqs} requirements`;
    const reqPad = barWidth - covLabel.length - reqText.length;
    const deferredNum = totalDeferred > 0 ? String(totalDeferred) : "";
    const deferredText = deferredNum
        ? `   ${picocolors_1.default.dim("·")}   ${picocolors_1.default.dim(deferredNum)} ${picocolors_1.default.dim("deferred")}`
        : "";
    lines.push(`  ${covLabel}${" ".repeat(Math.max(0, reqPad))}${reqText}${deferredText}`);
    // Row 3: Bar (same width as row 2, left-aligned) + deprecated
    const covBar = (0, index_js_1.renderSegmentedBar)(greenPct, yellowPct, redPct, barWidth);
    const deprecatedNum = totalDeprecated > 0 ? String(totalDeprecated) : "";
    const deprecatedText = deprecatedNum
        ? `   ${picocolors_1.default.dim("·")}   ${picocolors_1.default.dim(deprecatedNum)} ${picocolors_1.default.dim("deprecated")}`
        : "";
    lines.push(`  ${covBar}${deprecatedText}`);
    // Row 4: Code % → gaps + uncovered
    const codePct = `${implPct}%`.padStart(pctColWidth);
    const codeGaps = totalCodeGaps;
    const codeArrow = codeGaps > 0 ? picocolors_1.default.dim("→") : " ";
    const codeGapNum = codeGaps > 0 ? String(codeGaps) : "";
    const codeGapText = codeGapNum ? ` ${codeGapNum} ${picocolors_1.default.dim("gaps")}` : "";
    const uncoveredNum = totalUncovered > 0 ? String(totalUncovered) : "";
    const uncoveredText = uncoveredNum
        ? `  ${picocolors_1.default.dim("·")}  ${picocolors_1.default.dim(uncoveredNum)} ${picocolors_1.default.dim("uncovered")}`
        : "";
    lines.push(`  ${codePct} code ${codeArrow}${codeGapText}${uncoveredText}`);
    // Row 5: Test % → gaps + orphaned
    const testPctFormatted = `${testPct}%`.padStart(pctColWidth);
    const testGaps = totalTestGaps;
    const testArrow = testGaps > 0 ? picocolors_1.default.dim("→") : " ";
    const testGapNum = testGaps > 0 ? String(testGaps) : "";
    const testGapText = testGapNum ? ` ${testGapNum} ${picocolors_1.default.dim("gaps")}` : "";
    const orphanedNum = totalOrphaned > 0 ? String(totalOrphaned) : "";
    const orphanedText = orphanedNum
        ? `  ${picocolors_1.default.dim("·")}  ${picocolors_1.default.dim(orphanedNum)} ${picocolors_1.default.dim("orphaned")}`
        : "";
    lines.push(`  ${testPctFormatted} test ${testArrow}${testGapText}${orphanedText}`);
    // Combined scan metadata
    const totalFiles = results.reduce((sum, r) => sum + r.report.metadata.filesScanned, 0);
    const totalDuration = results.reduce((sum, r) => sum + r.report.metadata.scanDurationMs, 0);
    const durationSec = (totalDuration / 1000).toFixed(1);
    lines.push("");
    lines.push(`  ${picocolors_1.default.dim(`Scanned ${totalFiles} files in ${durationSec}s`)}`);
    console.log(lines.join("\n"));
}
/**
 * Run traceability analysis and return the result.
 * Wraps the runner with proper error handling.
 */
async function runAnalysis(featureFilter, minPriority) {
    try {
        return await (0, index_js_1.runTraceabilityAnalysis)({
            featureFilter,
            minPriority,
        });
    }
    catch (error) {
        const reason = error instanceof Error ? error.message : String(error);
        throw (0, errors_1.createTraceabilityAnalysisFailedError)(reason, error instanceof Error ? error : undefined);
    }
}
//# sourceMappingURL=traceability.js.map
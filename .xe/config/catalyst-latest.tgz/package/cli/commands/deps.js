"use strict";
/**
 * Deps command implementation — cross-feature dependency analysis.
 * @req FR:cli-engine/deps.execute
 * @req FR:cli-engine/deps.output
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.depsCommand = depsCommand;
const logging_1 = require("../../core/logging");
const runner_js_1 = require("../../traceability/runner.js");
const dependency_reporter_js_1 = require("../../traceability/reports/dependency-reporter.js");
/**
 * Execute the deps command.
 *
 * Runs dependency analysis and outputs the result in the requested format.
 *
 * @req FR:cli-engine/deps.execute
 */
async function depsCommand(featureArg, options) {
    const logger = logging_1.LogManager.current();
    logger.info('CLI', 'Deps', `Analyzing dependencies${featureArg ? ` for ${featureArg}` : ''}...`);
    const report = await (0, runner_js_1.runDependencyAnalysis)();
    const format = options.format ?? 'text';
    const reportOptions = {
        reverse: options.reverse,
        feature: featureArg,
    };
    switch (format) {
        case 'json':
            // @req FR:cli-engine/deps.output
            console.log((0, dependency_reporter_js_1.generateDependencyJsonReport)(report));
            break;
        case 'mermaid':
            // @req FR:cli-engine/deps.output
            console.log((0, dependency_reporter_js_1.generateDependencyMermaidReport)(report, reportOptions));
            break;
        default:
            // @req FR:cli-engine/deps.output
            console.log((0, dependency_reporter_js_1.generateDependencyTextReport)(report, reportOptions));
            break;
    }
    // Exit non-zero if validation errors exist (standard linter/checker pattern)
    if (report.validations.length > 0) {
        process.exit(1);
    }
}
//# sourceMappingURL=deps.js.map